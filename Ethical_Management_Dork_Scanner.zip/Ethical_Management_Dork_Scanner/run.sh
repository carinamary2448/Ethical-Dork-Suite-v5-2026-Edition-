#!/usr/bin/env bash
set -euo pipefail

echo "============================================================"
echo " Ethical Dork Suite — v5 (2026 Edition)"
echo "============================================================"
echo

# Resolve python3 binary
PYTHON=""
for candidate in python3 python3.12 python3.11 python3.10; do
    if command -v "$candidate" &>/dev/null; then
        PYTHON="$candidate"
        break
    fi
done

if [ -z "$PYTHON" ]; then
    echo "[ERROR] Python 3.10+ not found. Install it with your package manager:"
    echo "        Ubuntu/Debian: sudo apt install python3 python3-pip"
    echo "        macOS:         brew install python"
    exit 1
fi

echo "[INFO] Using $($PYTHON --version)"

# Install / upgrade dependencies
echo "[INFO] Checking dependencies (first run may take a moment)..."
"$PYTHON" -m pip install -q --upgrade pip
"$PYTHON" -m pip install -q -r requirements.txt || \
    echo "[WARN] Some packages may have failed — attempting to continue."

echo "[INFO] Launching application..."
echo
"$PYTHON" ethical_dork_suite.py
