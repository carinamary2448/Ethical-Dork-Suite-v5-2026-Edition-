"""
ethical_dork_suite.py — v5 (2026 Edition)
A single-file Tkinter GUI application: Ethical Dork Management & Scanner Suite.
WARNING: For authorized security testing and defensive research ONLY.
Audit logs: ./data/audit_log.txt   Results DB: ./data/results.db

Dependencies (pip install -r requirements.txt):
  requests beautifulsoup4 lxml pysocks
  selenium>=4.18 webdriver-manager>=4.0
  psutil matplotlib faker pyyaml

Key changes in v5:
  - 4 new search engines: AOL, Yahoo Japan, Mojeek, Qwant (BS4 + Selenium)
  - Engine checkboxes wrap dynamically — no row overflow on 13 engines
  - Persistent Selenium profiles (data/selenium_profiles/{browser}/) so
    clear_selenium_data() actually deletes real on-disk cookies/localStorage
  - clear_selenium_data() guards against running scan, reports bytes freed
  - CAPTCHA detection system: detects reCAPTCHA/hCaptcha/generic triggers
  - CAPTCHA modes: Manual pause-popup, 2captcha API, AntiCaptcha API, hCaptcha bypass
  - New dedicated "Selenium Controls" LabelFrame with per-mode delay spinboxes,
    API key field (show/hide), auto-visible-on-CAPTCHA toggle
  - Thread fixes: validate_proxies uses ThreadPoolExecutor; domain-to-IP uses
    threading.Events (not plain bools); domain-to-IP concurrent resolution;
    named threads throughout; no duplicate scanner thread start; port scanner
    uses single persistent executor; gc.collect removed from hot path
  - Dead globals removed: global_unique_urls, scanned_urls, vuln_urls
  - DorkScanner.results/vuln lists removed — all state lives in result_store
  - All engine BS4 scrapers use session with retry adapter (not bare requests.get)
  - add_date_to_url only logs "not supported" for engines that explicitly handle it
  - apply_live_filter uses result_store connection (WAL-safe, no raw sqlite3.connect)
  - export_audit_log flushes handler before copying
  - _make_driver surfaces errors to UI on unknown browser
  - Proxy section redesigned: live pool summary (alive/dead/untested/protocols),
    rotation counter, active proxy label — all unified in one box
  - Progress panel: proxy rotations counter replaces raw URL label
  - Per-engine result counters shown as pills below progress bar
  - Port scanner: configurable timeout spinbox; single executor per scan
  - Settings.yaml: all new keys read (thread_cap, captcha_*, selenium_delay_*)
  - run.bat / run.sh version string updated to v5
  - All previous fixes and features retained
"""
import os, sys, json, time, random, shutil, sqlite3, threading, re, socket
import logging as _logging
from queue import Queue, Empty
from datetime import datetime, timedelta, UTC
from urllib.parse import quote_plus, urlparse, parse_qs, unquote
from concurrent.futures import ThreadPoolExecutor, as_completed, wait, FIRST_COMPLETED
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
import requests
from bs4 import BeautifulSoup
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

# ── Optional deps ─────────────────────────────────────────────────────────────
try:
    import psutil
except Exception:
    psutil = None

try:
    from selenium import webdriver
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.webdriver.chrome.service  import Service as ChromeService
    from selenium.webdriver.firefox.service import Service as FirefoxService
    from selenium.webdriver.edge.service    import Service as EdgeService
    from webdriver_manager.chrome import ChromeDriverManager
    try:
        from webdriver_manager.firefox   import GeckoDriverManager
    except Exception:
        GeckoDriverManager = None
    try:
        from webdriver_manager.microsoft import EdgeChromiumDriverManager
    except Exception:
        EdgeChromiumDriverManager = None
    SELENIUM_AVAILABLE = True
except Exception:
    SELENIUM_AVAILABLE = False

# ── Paths ─────────────────────────────────────────────────────────────────────
BASE_DIR     = os.path.abspath(os.path.dirname(__file__))
DATA_DIR     = os.path.join(BASE_DIR, "data")
EXPORT_DIR   = os.path.join(DATA_DIR, "exports")
CACHE_DB     = os.path.join(DATA_DIR, "cache.db")
AUDIT_LOG    = os.path.join(DATA_DIR, "audit_log.txt")
PROXIES_FILE = os.path.join(DATA_DIR, "proxies.txt")
SETTINGS_FILE= os.path.join(BASE_DIR, "config", "settings.yaml")
SEL_PROFILES = os.path.join(DATA_DIR, "selenium_profiles")
for _d in (DATA_DIR, EXPORT_DIR, os.path.join(BASE_DIR, "config"),
           SEL_PROFILES,
           os.path.join(SEL_PROFILES, "chrome"),
           os.path.join(SEL_PROFILES, "firefox"),
           os.path.join(SEL_PROFILES, "edge")):
    os.makedirs(_d, exist_ok=True)

# ── Settings ──────────────────────────────────────────────────────────────────
_SETTINGS_DEFAULTS = {
    "max_memory_mb": 500, "batch_size": 500, "dedupe_mode": "auto",
    "engines": ["bing", "duckduckgo"], "delay_min": 1, "delay_max": 2,
    "thread_cap": 8,
    "captcha_detection": True, "captcha_mode": "manual",
    "captcha_retry_delay": 10, "captcha_max_wait": 60,
    "captcha_auto_visible": True,
    "selenium_delay_min": 2, "selenium_delay_max": 4,
    "port_timeout": 1,
    "proxy_require_https": True,
    "proxy_min_https_checks": 1,
}

def _load_settings():
    try:
        import yaml
        if not os.path.exists(SETTINGS_FILE):
            return dict(_SETTINGS_DEFAULTS)
        with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
        merged = dict(_SETTINGS_DEFAULTS)
        merged.update({k: v for k, v in data.items() if v is not None})
        return merged
    except ImportError:
        return dict(_SETTINGS_DEFAULTS)
    except Exception as e:
        print(f"[settings] {e}; using defaults.")
        return dict(_SETTINGS_DEFAULTS)

APP_SETTINGS = _load_settings()

# ── User-agent pool ───────────────────────────────────────────────────────────
DEFAULT_USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_4) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Safari/605.1.15",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36",
]

# All engines — 13 total (9 original + 4 new)
BS_ENGINES = [
    "bing", "duckduckgo", "brave", "yandex", "ask",
    "yahoo", "ecosia", "startpage", "google",
    "aol", "yahoojapan", "mojeek", "qwant",
]

# Engine tier system — drives BS4-only routing:
#   bs4      = static HTML, requests always works reliably
#   hybrid   = BS4 sometimes works; Selenium significantly better
#   selenium = JS SPA, BS4 always empty — requires Selenium
ENGINE_TIERS = {
    "bing":       "bs4",
    "duckduckgo": "bs4",
    "yahoo":      "bs4",
    "ask":        "bs4",
    "yandex":     "bs4",
    "ecosia":     "bs4",
    "aol":        "bs4",
    "yahoojapan": "bs4",
    "mojeek":     "bs4",
    "startpage":  "hybrid",
    "brave":      "selenium",   # FIX: full React SPA — BS4 always returns empty
    "qwant":      "selenium",
    "google":     "selenium",
}
# Engines that are useless in BS4-only mode — skip them, don't waste threads
_SELENIUM_ONLY_ENGINES = {e for e, t in ENGINE_TIERS.items() if t == "selenium"}

# ── Vuln patterns ─────────────────────────────────────────────────────────────
VULN_PATTERNS = [
    r"\?id=", r"\?file=", r"\?cmd=", r"\?exec=", r"\?cat=",
    r"\?user=", r"\?pass=", r"\?dir=", r"\?page=", r"\?path=",
    r"\?search=", r"\?query=", r"\?input=", r"\?data=", r"\?action=",
    r"\?url=", r"\?redirect=", r"\?view=", r"\?lang=", r"\?template=",
    r"\.php\?", r"\.asp\?", r"\.aspx\?", r"\.jsp\?", r"\.cfm\?", r"\.cgi\?",
    r"login\.php", r"admin\.php", r"index\.php", r"upload\.php",
    r"shell\.php", r"config\.php", r"wp-login\.php", r"phpmyadmin",
    r"\?[^=]+=.+&",
    r"/\d+/", r"/\d+$",
    r"/api/", r"/rest/", r"/v\d+/",
    r"union[+%20]+select", r"sleep\(\d", r"benchmark\(\d",
    r"1=1", r"'--", r"%27--", r"%22", r"xp_cmdshell",
    r"\.\./", r"%2e%2e%2f", r"etc/passwd",
    r"\?[^=]+=",
]
COMPILED_VULN_PATTERNS = [re.compile(p, re.IGNORECASE) for p in VULN_PATTERNS]

# ── Thread-safe globals ───────────────────────────────────────────────────────
_scan_running_event      = threading.Event()
_scan_paused_event       = threading.Event()
_port_scan_running_event = threading.Event()
# Domain-to-IP now uses Events for true thread safety (was plain bool)
_domain_ip_running_event = threading.Event()
_domain_ip_paused_event  = threading.Event()

class _EventBoolProxy:
    def __init__(self, e): self._e = e
    def __bool__(self): return self._e.is_set()
    def __repr__(self): return repr(self._e.is_set())

SCAN_RUNNING      = _EventBoolProxy(_scan_running_event)
SCAN_PAUSED       = _EventBoolProxy(_scan_paused_event)
PORT_SCAN_RUNNING = _EventBoolProxy(_port_scan_running_event)
DOMAIN_IP_RUNNING = _EventBoolProxy(_domain_ip_running_event)
DOMAIN_IP_PAUSED  = _EventBoolProxy(_domain_ip_paused_event)

def _set_scan_running(v):       _scan_running_event.set()       if v else _scan_running_event.clear()
def _set_scan_paused(v):        _scan_paused_event.set()        if v else _scan_paused_event.clear()
def _set_port_scan_running(v):  _port_scan_running_event.set()  if v else _port_scan_running_event.clear()
def _set_domain_ip_running(v):  _domain_ip_running_event.set()  if v else _domain_ip_running_event.clear()
def _set_domain_ip_paused(v):   _domain_ip_paused_event.set()   if v else _domain_ip_paused_event.clear()

result_queue = Queue(maxsize=5000)
log_queue    = Queue(maxsize=1000)

# Shared cross-scanner URL dedup set (BUG 24/27/43).
# Guards against the same URL being re-queued by different DorkScanner instances
# (different dorks or different threads scanning the same dork).
_global_seen_urls      = set()
_global_seen_urls_lock = threading.Lock()

# ── Buffered audit logger ─────────────────────────────────────────────────────
_audit_handler      = None
_audit_handler_lock = threading.Lock()

def _get_audit_logger():
    """Return the 'audit' logger, creating its FileHandler once (thread-safe)."""
    global _audit_handler
    # Fast path — handler already set up.
    if _audit_handler is not None:
        return _logging.getLogger("audit")
    with _audit_handler_lock:
        # Re-check inside lock to guard against concurrent first calls.
        if _audit_handler is None:
            handler = _logging.FileHandler(AUDIT_LOG, encoding="utf-8", delay=True)
            handler.setFormatter(_logging.Formatter("%(message)s"))
            lg = _logging.getLogger("audit")
            lg.addHandler(handler)
            lg.setLevel(_logging.DEBUG)
            _audit_handler = handler   # publish only after fully configured
    return _logging.getLogger("audit")

# Keep the old name as an alias so any remaining call-sites still work.
_get_audit_handler = _get_audit_logger

def log_event(msg):
    ts   = datetime.now(UTC).isoformat()
    line = f"{ts}  {msg}"
    try:
        log_queue.put_nowait(line)
    except Exception:
        # Queue full — try a short blocking put so we don't lose the message
        try:
            log_queue.put(line, timeout=0.1)
        except Exception:
            pass  # truly unavoidable drop; still written to file below
    try: _get_audit_logger().info(line)
    except Exception: pass

# ── Export helper ─────────────────────────────────────────────────────────────
def save_export(filename_base, data, fmt="json", extract_key=None):
    os.makedirs(EXPORT_DIR, exist_ok=True)
    ts = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    if fmt == "json":
        path = os.path.join(EXPORT_DIR, f"{filename_base}_{ts}.json")
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
    else:
        path = os.path.join(EXPORT_DIR, f"{filename_base}_{ts}.txt")
        with open(path, "w", encoding="utf-8") as f:
            if isinstance(data, (list, tuple)):
                # Fix: materialise to list once so we can safely index [0]
                # without consuming a generator, and guard the isinstance check
                # so a non-dict sequence doesn't raise TypeError.
                data_list = list(data)
                if extract_key and data_list and isinstance(data_list[0], dict):
                    f.write("\n".join(str(d[extract_key]) for d in data_list))
                else:
                    f.write("\n".join(str(d) for d in data_list))
            else:
                f.write(str(data))
    return path

# ═══════════════════════════════════════════════════════════════════════════════
# PROXY MANAGER
# ═══════════════════════════════════════════════════════════════════════════════
class ProxyManager:
    def __init__(self):
        self.proxies = []
        self.lock    = threading.Lock()

    def load_from_file(self, path=PROXIES_FILE):
        if not os.path.exists(path):
            return
        with open(path, "r", encoding="utf-8") as f:
            lines = [l.strip() for l in f if l.strip()]
        loaded, has_auth = [], False
        for raw in lines:
            parsed = self._parse_proxy_line(raw)
            if parsed:
                if "@" in raw:
                    has_auth = True
                    parsed["has_credentials"] = True
                loaded.append(parsed)
        with self.lock:
            self.proxies = loaded
        if has_auth:
            log_event("WARNING: proxy credentials stored in plaintext. Avoid sensitive passwords.")
        log_event(f"Loaded {len(loaded)} proxies from file.")

    def _parse_proxy_line(self, raw):
        p = raw.strip()
        proto, auth = "http", None
        for prefix, scheme in [("socks5h://", "socks5"), ("socks5://", "socks5"),
                                ("socks4a://", "socks4"), ("socks4://", "socks4"),
                                ("https://", "https"), ("http://", "http")]:
            if p.startswith(prefix):
                proto = scheme; host = p[len(prefix):]
                break
        else:
            host = p
        if "@" in host:
            auth, host = host.split("@", 1)
        if ":" not in host:
            return None
        ip, port = host.rsplit(":", 1)
        # Fix #4: always store a fully-qualified URL so requests/validation
        # never receives a schemeless "ip:port" string.
        if auth is not None:
            raw_norm = f"{proto}://{auth}@{ip}:{port}"
        else:
            raw_norm = f"{proto}://{ip}:{port}"
        return {"raw": raw_norm, "proto": proto, "ip": ip, "port": port,
                "last_checked": None, "alive": False, "rtime": None,
                "supports_https": False, "https_ok_count": 0,
                "fail_count": 0, "cooldown_until": 0.0}

    def validate_proxies(self, max_workers=30, timeout=7, progress_callback=None,
                         stop_event=None):
        """Multi-URL fallback validation with stop-event support.
        Fast HTTP checks first so dead proxies fail quickly without burning
        through two HTTPS timeouts. HTTPS checks follow so alive proxies
        still get supports_https flagged. No single-point-of-failure.
        """
        if not self.proxies:
            return
        with self.lock:
            items = list(self.proxies)
        total      = len(items)
        completed  = [0]
        counter_lk = threading.Lock()
        out        = []
        out_lk     = threading.Lock()

        # Fast HTTP checks first — dead proxies fail here without waiting through
        # 2x slow HTTPS timeouts (was the main cause of sluggish validation).
        # HTTPS tests come after so alive proxies still get supports_https flagged.
        _HTTP_URLS  = [
            ("http://ip-api.com/json",       False),
            ("http://checkip.amazonaws.com", False),
            ("http://httpbin.org/ip",        False),
            ("http://ifconfig.me/ip",        False),
        ]
        _HTTPS_URLS = [
            ("https://example.com",                  True),
            ("https://www.google.com/generate_204",  True),
        ]

        def worker(entry):
            if stop_event and stop_event.is_set():
                return
            proxy_url = entry["raw"]
            proxies   = {"http": proxy_url, "https": proxy_url}
            alive, rtime, supports_https = False, None, False

            # Phase 1: fast HTTP check — confirm proxy is alive at all
            for turl, is_https in _HTTP_URLS:
                if stop_event and stop_event.is_set():
                    break
                try:
                    t0 = time.time()
                    r  = requests.get(turl, proxies=proxies, timeout=timeout)
                    if r.status_code in (200, 204):
                        alive = True
                        rtime = time.time() - t0
                        break
                except Exception:
                    continue

            # Phase 2: HTTPS check — only if proxy passed phase 1
            if alive and not (stop_event and stop_event.is_set()):
                for turl, is_https in _HTTPS_URLS:
                    if stop_event and stop_event.is_set():
                        break
                    try:
                        # verify=False: proxy may present a self-signed cert on
                        # the CONNECT tunnel. We just want to know if the proxy
                        # can route HTTPS at all, not verify the cert chain.
                        requests.get(turl, proxies=proxies, timeout=timeout,
                                     verify=False)
                        supports_https = True
                        break
                    except Exception:
                        continue

            entry["alive"]          = alive
            entry["last_checked"]   = datetime.now(UTC).isoformat()
            entry["rtime"]          = rtime
            entry["supports_https"] = supports_https
            # Accumulate HTTPS ok count — preserve history across re-validation runs
            if supports_https:
                entry["https_ok_count"] = int(entry.get("https_ok_count") or 0) + 1
            # (leave https_ok_count unchanged when supports_https is False)
            entry["fail_count"]     = 0
            entry["cooldown_until"] = 0.0
            with out_lk:
                out.append(entry)
            # Increment counter then release lock before callback —
            # avoids serialising all UI updates through the lock at high thread counts
            with counter_lk:
                completed[0] += 1
                cur = completed[0]
            if progress_callback:
                progress_callback(cur, total, entry)

        with ThreadPoolExecutor(max_workers=max_workers,
                                thread_name_prefix="proxy-validate") as ex:
            futs = [ex.submit(worker, e) for e in items]
            for fut in as_completed(futs):
                if stop_event and stop_event.is_set():
                    for f in futs:
                        if not f.done():
                            f.cancel()
                    break
                try: fut.result()
                except Exception as e: log_event(f"Proxy validate worker error: {e}")

        with self.lock:
            rawmap = {e["raw"]: e for e in out}
            for i, e in enumerate(self.proxies):
                if e["raw"] in rawmap:
                    self.proxies[i] = rawmap[e["raw"]]
        alive_count = sum(1 for p in self.proxies if p.get("alive"))
        log_event(f"Proxy validation done: {alive_count}/{len(self.proxies)} alive.")

    def get_random_proxy(self, protocols=None, require_https=True):
        """Return requests-compatible proxies dict or None.
        Picks randomly from a larger low-latency bucket to avoid hammering
        only a handful of proxies.
        pysocks required for SOCKS proxies.
        """
        now_ts = time.time()
        with self.lock:
            pool = [p for p in self.proxies if p.get("alive")]
            if protocols:
                pool = [p for p in pool if p["proto"] in protocols]
            pool = [p for p in pool if p.get("cooldown_until", 0.0) <= now_ts]
            if require_https:
                pool = [p for p in pool if p.get("supports_https")]
            if not pool:
                return None
            with_rtime = [p for p in pool if p.get("rtime") is not None]
            if with_rtime:
                with_rtime.sort(key=lambda p: p["rtime"])
                top_n = min(30, len(with_rtime))
                pick = random.choice(with_rtime[:top_n])
            else:
                pick = random.choice(pool)
        return {"http": pick["raw"], "https": pick["raw"]}

    def get_random_proxy_gated(self, protocols=None, require_https=True,
                               min_https_checks=1):
        """Like get_random_proxy, but supports HTTPS quality gate."""
        now_ts = time.time()
        gate = max(0, int(min_https_checks or 0))
        with self.lock:
            pool = [p for p in self.proxies if p.get("alive")]
            if protocols:
                pool = [p for p in pool if p["proto"] in protocols]
            pool = [p for p in pool if p.get("cooldown_until", 0.0) <= now_ts]
            if require_https:
                pool = [
                    p for p in pool
                    if p.get("supports_https")
                    and int(p.get("https_ok_count", 0) or 0) >= gate
                ]
            if not pool:
                return None
            with_rtime = [p for p in pool if p.get("rtime") is not None]
            if with_rtime:
                with_rtime.sort(key=lambda p: p["rtime"])
                top_n = min(30, len(with_rtime))
                pick = random.choice(with_rtime[:top_n])
            else:
                pick = random.choice(pool)
        return {"http": pick["raw"], "https": pick["raw"]}

    def report_runtime_failure(self, proxy_url, error_msg=""):
        """Demote proxies that fail TLS/connect during real scan traffic."""
        em = (error_msg or "").lower()
        hard_fail = ("certificate_verify_failed" in em
                     or "certificate verify failed" in em
                     or "sslcertverificationerror" in em
                     or "self-signed certificate" in em
                     or "winerror 10061" in em
                     or "failed to establish a new connection" in em)
        timeout_fail = ("timed out" in em or "connecttimeout" in em)
        with self.lock:
            for p in self.proxies:
                if p.get("raw") != proxy_url:
                    continue
                p["fail_count"] = int(p.get("fail_count") or 0) + 1
                if hard_fail:
                    p["alive"] = False
                    p["cooldown_until"] = time.time() + 900
                elif timeout_fail and p["fail_count"] >= 2:
                    p["alive"] = False
                    p["cooldown_until"] = time.time() + 300
                elif timeout_fail:
                    p["cooldown_until"] = time.time() + 90
                break

    def report_runtime_success(self, proxy_url, https_success=False):
        """Reward proxies that complete successful live traffic."""
        with self.lock:
            for p in self.proxies:
                if p.get("raw") != proxy_url:
                    continue
                p["alive"] = True
                p["fail_count"] = 0
                p["cooldown_until"] = 0.0
                if https_success:
                    p["supports_https"] = True
                    p["https_ok_count"] = int(p.get("https_ok_count", 0) or 0) + 1
                break

    def pool_summary(self, protocols=None):
        """Return dict with alive/dead/untested counts and per-protocol alive counts."""
        with self.lock:
            proxies = list(self.proxies)
        if protocols:
            proxies = [p for p in proxies if p["proto"] in protocols]
        alive    = sum(1 for p in proxies if p.get("alive") is True)
        dead     = sum(1 for p in proxies if p.get("alive") is False and p.get("last_checked"))
        untested = sum(1 for p in proxies if not p.get("last_checked"))
        by_proto = {}
        for proto in ("http", "https", "socks4", "socks5"):
            by_proto[proto] = sum(1 for p in proxies
                                  if p.get("alive") and p["proto"] == proto)
        return {"alive": alive, "dead": dead, "untested": untested,
                "total": len(proxies), "by_proto": by_proto}

    def count_eligible(self, protocols=None, require_https=True, min_https_checks=1):
        """Count currently usable alive proxies for scanner selection logic."""
        now_ts = time.time()
        gate = max(0, int(min_https_checks or 0))
        with self.lock:
            pool = [p for p in self.proxies if p.get("alive")]
            if protocols:
                pool = [p for p in pool if p["proto"] in protocols]
            pool = [p for p in pool if p.get("cooldown_until", 0.0) <= now_ts]
            if require_https:
                pool = [
                    p for p in pool
                    if p.get("supports_https")
                    and int(p.get("https_ok_count", 0) or 0) >= gate
                ]
            return len(pool)

proxy_manager = ProxyManager()

# ═══════════════════════════════════════════════════════════════════════════════
# RESULT STORE  (SQLite-backed, unlimited scale)
# ═══════════════════════════════════════════════════════════════════════════════
class ResultStore:
    """Thread-safe SQLite store. Saves ALL scraped URLs with domain column
    so post-scan filtering by domain is possible without re-scanning."""

    def __init__(self, db_path=None):
        self.db_path = db_path or os.path.join(DATA_DIR, "results.db")
        self._local  = threading.local()
        self._lock   = threading.Lock()
        self._init_db()

    def _conn(self):
        if not getattr(self._local, "conn", None):
            c = sqlite3.connect(self.db_path, check_same_thread=False)
            c.execute("PRAGMA journal_mode=WAL")
            c.execute("PRAGMA synchronous=NORMAL")
            self._local.conn = c
        return self._local.conn

    def _init_db(self):
        with self._lock:
            c = self._conn()
            c.execute("""CREATE TABLE IF NOT EXISTS results (
                id        INTEGER PRIMARY KEY AUTOINCREMENT,
                url       TEXT UNIQUE,
                domain    TEXT,
                dork      TEXT,
                engine    TEXT,
                timestamp TEXT,
                is_vuln   INTEGER DEFAULT 0
            )""")
            c.execute("CREATE INDEX IF NOT EXISTS idx_url    ON results(url)")
            c.execute("CREATE INDEX IF NOT EXISTS idx_vuln   ON results(is_vuln)")
            c.execute("CREATE INDEX IF NOT EXISTS idx_domain ON results(domain)")
            c.execute("CREATE INDEX IF NOT EXISTS idx_engine ON results(engine)")
            c.commit()

    def reset(self):
        with self._lock:
            self._conn().execute("DELETE FROM results")
            self._conn().commit()

    def add(self, meta, is_vuln=False):
        """Insert URL. Returns True if new, False if duplicate."""
        url    = meta["url"]
        domain = ""
        try:    domain = urlparse(url).hostname or ""
        except Exception: pass
        try:
            with self._lock:
                cur = self._conn().execute(
                    "INSERT OR IGNORE INTO results(url,domain,dork,engine,timestamp,is_vuln) VALUES(?,?,?,?,?,?)",
                    (url, domain, meta.get("dork", ""), meta.get("engine", ""),
                     meta.get("timestamp", ""), 1 if is_vuln else 0)
                )
                self._conn().commit()
            return cur.rowcount > 0   # True only if a new row was actually inserted
        except Exception as e:
            log_event(f"ResultStore.add error: {e}")
            return False

    def count(self, vuln_only=False, domain=None, engine=None):
        q, params = "SELECT COUNT(*) FROM results", []
        conditions = []
        if vuln_only: conditions.append("is_vuln=1")
        if domain:    conditions.append("domain=?"); params.append(domain)
        if engine:    conditions.append("engine=?"); params.append(engine)
        if conditions: q += " WHERE " + " AND ".join(conditions)
        with self._lock:
            return self._conn().execute(q, params).fetchone()[0]

    def count_by_engine(self):
        """Return dict engine -> count for all engines with results."""
        # Bug 6 fix: acquire _lock to be consistent with all other read methods.
        with self._lock:
            rows = self._conn().execute(
                "SELECT engine, COUNT(*) FROM results GROUP BY engine"
            ).fetchall()
        return {r[0]: r[1] for r in rows}

    def domains(self):
        """Return sorted list of unique domains in store."""
        # Fix #2: acquire _lock for consistency with all other read methods.
        with self._lock:
            rows = self._conn().execute(
                "SELECT DISTINCT domain FROM results ORDER BY domain"
            ).fetchall()
        return [r[0] for r in rows if r[0]]

    def iter_results(self, vuln_only=False, domain=None, engine=None,
                     limit=None, offset=0):
        q, params = "SELECT url,domain,dork,engine,timestamp,is_vuln FROM results", []
        conditions = []
        if vuln_only: conditions.append("is_vuln=1")
        if domain:    conditions.append("domain=?"); params.append(domain)
        if engine:    conditions.append("engine=?"); params.append(engine)
        if conditions: q += " WHERE " + " AND ".join(conditions)
        q += " ORDER BY id"
        if limit: q += f" LIMIT {int(limit)} OFFSET {int(offset)}"  # Fix E2: cast to int to prevent injection
        # Fix: stream results in chunks of 10 000 rows so that large exports
        # (hundreds of thousands of URLs) don't materialise the full result set
        # in memory at once.  Each chunk acquires the lock only for its own
        # fetchmany() call, keeping the lock hold-time short.
        _CHUNK = 10_000
        chunk_offset = int(offset)
        while True:
            chunk_q = q
            # If a caller-supplied LIMIT is already embedded we must not add
            # another one — just do a single pass using the original query.
            if not limit:
                chunk_q += f" LIMIT {_CHUNK} OFFSET {chunk_offset}"
            with self._lock:
                rows = self._conn().execute(chunk_q, params).fetchall()
            for row in rows:
                yield {"url": row[0], "domain": row[1], "dork": row[2],
                       "engine": row[3], "timestamp": row[4], "is_vuln": bool(row[5])}
            # If the caller supplied an explicit LIMIT we yielded everything in
            # one shot above; stop here.
            if limit or len(rows) < _CHUNK:
                break
            chunk_offset += _CHUNK

    def export_txt(self, path, vuln_only=False, domain=None, engine=None):
        with open(path, "w", encoding="utf-8") as f:
            for r in self.iter_results(vuln_only=vuln_only,
                                       domain=domain, engine=engine):
                f.write(r["url"] + "\n")

    def export_json(self, path, vuln_only=False, domain=None, engine=None):
        # Fix: stream rows incrementally so a 500k-row export doesn't load
        # everything into memory before writing.
        with open(path, "w", encoding="utf-8") as f:
            f.write("[\n")
            first = True
            for r in self.iter_results(vuln_only=vuln_only,
                                       domain=domain, engine=engine):
                if not first:
                    f.write(",\n")
                json.dump(r, f)
                first = False
            f.write("\n]")

result_store = ResultStore()

# ═══════════════════════════════════════════════════════════════════════════════
# SELENIUM DRIVER FACTORY  (persistent profiles + proxy support)
# ═══════════════════════════════════════════════════════════════════════════════
def _make_driver(browser="chrome", headless=True, proxy_dict=None):
    """Create and return a Selenium WebDriver using a persistent per-browser
    profile stored in data/selenium_profiles/{browser}/.
    proxy_dict: {"http": "socks5://...", "https": "socks5://..."} or None.
    Raises RuntimeError with descriptive message if unavailable.
    """
    if not SELENIUM_AVAILABLE:
        raise RuntimeError("selenium / webdriver-manager not installed.")

    def _proxy_arg(pd):
        if not pd: return None
        raw = pd.get("http") or pd.get("https", "")
        for prefix in ("socks5://", "socks4://", "https://", "http://"):
            if raw.startswith(prefix):
                return raw
        return raw

    proxy_url   = _proxy_arg(proxy_dict)
    # Each thread must have its own profile to avoid Chrome lock conflicts.
    # Use thread ident so concurrent Selenium workers don't share the same dir.
    thread_id   = threading.current_thread().ident or 0
    profile_dir = os.path.join(SEL_PROFILES, f"{browser}_{thread_id}")
    os.makedirs(profile_dir, exist_ok=True)

    if browser == "chrome":
        opts = webdriver.ChromeOptions()
        # BUG 21 fix: ChromeOptions handles the path correctly without shell quoting.
        # abspath ensures no relative-path issues; thread-unique dir (BUG 6) prevents lock.
        opts.add_argument(f"--user-data-dir={os.path.abspath(profile_dir)}")
        if headless: opts.add_argument("--headless=new")
        opts.add_argument("--no-sandbox")
        opts.add_argument("--disable-dev-shm-usage")
        opts.add_argument("--disable-blink-features=AutomationControlled")
        opts.add_argument("--disk-cache-size=0")
        opts.add_argument("--remote-debugging-port=0")  # avoids port conflicts across threads
        opts.add_experimental_option("excludeSwitches", ["enable-automation"])
        opts.add_argument(f"user-agent={random.choice(DEFAULT_USER_AGENTS)}")
        if proxy_url: opts.add_argument(f"--proxy-server={proxy_url}")
        svc = ChromeService(ChromeDriverManager().install())
        return webdriver.Chrome(service=svc, options=opts)

    elif browser == "firefox":
        if GeckoDriverManager is None:
            raise RuntimeError(
                "webdriver-manager firefox not available. pip install webdriver-manager")
        opts = webdriver.FirefoxOptions()
        if headless: opts.add_argument("--headless")
        opts.set_preference("browser.cache.disk.enable", False)
        # BUG 7 fix: removed the dead `drv.install_addon` no-op reference below.
        # Firefox profile isolation is handled by geckodriver's temp profile per session.
        if proxy_url:
            from selenium.webdriver.common.proxy import Proxy, ProxyType
            p = Proxy()
            if "socks5" in proxy_url:
                p.proxy_type = ProxyType.MANUAL
                p.socks_proxy = proxy_url.replace("socks5://", "")
                p.socks_version = 5
            elif "socks4" in proxy_url:
                p.proxy_type = ProxyType.MANUAL
                p.socks_proxy = proxy_url.replace("socks4://", "")
                p.socks_version = 4
            else:
                p.proxy_type = ProxyType.MANUAL
                host = proxy_url.replace("http://", "").replace("https://", "")
                p.http_proxy = host; p.ssl_proxy = host
            opts.proxy = p
        svc = FirefoxService(GeckoDriverManager().install())
        return webdriver.Firefox(service=svc, options=opts)

    elif browser == "edge":
        if EdgeChromiumDriverManager is None:
            raise RuntimeError(
                "EdgeChromiumDriverManager not available. pip install webdriver-manager")
        opts = webdriver.EdgeOptions()
        opts.add_argument(f"--user-data-dir={os.path.abspath(profile_dir)}")  # BUG 21
        if headless: opts.add_argument("--headless=new")
        opts.add_argument("--no-sandbox")
        opts.add_argument("--disk-cache-size=0")
        opts.add_argument("--remote-debugging-port=0")
        if proxy_url: opts.add_argument(f"--proxy-server={proxy_url}")
        svc = EdgeService(EdgeChromiumDriverManager().install())
        return webdriver.Edge(service=svc, options=opts)

    raise RuntimeError(
        f"Unknown browser: '{browser}'. Valid options: chrome, firefox, edge.")

# ═══════════════════════════════════════════════════════════════════════════════
# CAPTCHA DETECTION & HANDLING
# ═══════════════════════════════════════════════════════════════════════════════
_CAPTCHA_TITLE_KEYWORDS = [
    "captcha", "robot", "verify", "unusual traffic",
    "security check", "human", "not a robot", "access denied",
]
_CAPTCHA_BODY_KEYWORDS  = [
    "captcha", "i'm not a robot", "verify you are human",
    "unusual traffic", "security check", "please complete the security check",
]

def _detect_captcha(driver):
    """Return 'recaptcha', 'hcaptcha', 'generic', or None."""
    try:
        title = driver.title.lower()
        if any(k in title for k in _CAPTCHA_TITLE_KEYWORDS):
            # Check type
            try:
                driver.find_element(By.CSS_SELECTOR, "iframe[src*='recaptcha']")
                return "recaptcha"
            except Exception: pass
            try:
                driver.find_element(By.CSS_SELECTOR, "iframe[src*='hcaptcha']")
                return "hcaptcha"
            except Exception: pass
            return "generic"
        # Check body text (first 3000 chars)
        try:
            body_text = driver.find_element(By.TAG_NAME, "body").text[:3000].lower()
        except Exception:
            body_text = ""
        if any(k in body_text for k in _CAPTCHA_BODY_KEYWORDS):
            try:
                driver.find_element(By.CSS_SELECTOR, "div.g-recaptcha")
                return "recaptcha"
            except Exception: pass
            try:
                driver.find_element(
                    By.CSS_SELECTOR, "div[data-hcaptcha-widget-id]")
                return "hcaptcha"
            except Exception: pass
            return "generic"
        # Check for CAPTCHA elements directly (headless may not update title)
        try:
            driver.find_element(By.CSS_SELECTOR,
                "iframe[src*='recaptcha'], div.g-recaptcha")
            return "recaptcha"
        except Exception: pass
        try:
            driver.find_element(By.CSS_SELECTOR,
                "iframe[src*='hcaptcha'], div[data-hcaptcha-widget-id]")
            return "hcaptcha"
        except Exception: pass
    except Exception:
        pass
    return None


def _handle_captcha_manual(driver, captcha_type, engine, app_ref,
                            max_wait=60, auto_visible=True):
    """Pause scan, show popup, wait for user to solve, return True if resolved."""
    log_event(f"CAPTCHA detected [{captcha_type}] on {engine} — manual solve required.")
    resolved_event = threading.Event()

    # Fix #3: when there is no UI, return immediately — don't block for
    # max_wait seconds on an event that will never be set.
    if app_ref is None:
        log_event(f"CAPTCHA: no UI reference — auto-resuming immediately.")
        return True

    def _show_popup():
        try:
            top = tk.Toplevel(app_ref)
            top.title("CAPTCHA Detected")
            top.lift(); top.focus_force()
            ttk.Label(top,
                text=f"CAPTCHA detected ({captcha_type}) on: {engine}\n\n"
                     f"{'Switch to the browser window and solve it.' if not auto_visible else 'The browser window is now visible.'}\n"
                     f"Click Done when solved (auto-resumes in {max_wait}s).",
                wraplength=380, justify="center", padding=12
            ).pack(padx=20, pady=10)
            def _done():
                resolved_event.set()
                top.destroy()
            ttk.Button(top, text="Done — Resume Scan",
                       command=_done, style="Success.TButton").pack(pady=(0, 12))
            top.protocol("WM_DELETE_WINDOW", _done)
        except Exception as e:
            # If popup creation fails for any reason, unblock the scan thread
            log_event(f"CAPTCHA popup error: {e} — auto-resuming.")
            resolved_event.set()

    app_ref.after(0, _show_popup)
    resolved_event.wait(timeout=max_wait)
    return True  # resume regardless — user may have solved or timed out


def _inject_recaptcha_token(driver, token, engine):
    """Inject a solved reCAPTCHA token into the page and attempt to fire the
    completion callback.  Three escalating strategies are tried in order:

    1. Write token into the hidden textarea and dispatch a 'change' event.
    2. Walk ___grecaptcha_cfg.clients to find and call the success callback
       (internal reCAPTCHA v2 API — path changes across reCAPTCHA versions,
       so every candidate key is tried rather than assuming .aa.l.callback).
    3. Fallback: submit the nearest <form> containing the textarea so the
       page receives the solved response even if the JS callback is unreachable.
    """
    # Step 1 — write token and fire change event
    driver.execute_script(
        "var el=document.getElementById('g-recaptcha-response');"
        "if(el){"
        "  el.innerHTML=arguments[0];"
        "  el.dispatchEvent(new Event('change'));"
        "}",
        token
    )
    # Step 2 — try to call the internal success callback.
    # The path ___grecaptcha_cfg.clients[key].aa.l.callback is version-specific;
    # we probe all client keys and walk the object tree defensively.
    callback_fired = driver.execute_script(
        "try {"
        "  if(typeof ___grecaptcha_cfg==='undefined') return false;"
        "  var clients=___grecaptcha_cfg.clients||{};"
        "  var keys=Object.keys(clients);"
        "  for(var i=0;i<keys.length;i++){"
        "    var c=clients[keys[i]];"
        "    // Walk all own properties two levels deep looking for a callback fn"
        "    var l1=Object.keys(c||{});"
        "    for(var j=0;j<l1.length;j++){"
        "      var o1=c[l1[j]];"
        "      if(!o1||typeof o1!=='object') continue;"
        "      var l2=Object.keys(o1);"
        "      for(var k=0;k<l2.length;k++){"
        "        var o2=o1[l2[k]];"
        "        if(o2&&typeof o2.callback==='function'){"
        "          try{o2.callback(arguments[0]);return true;}catch(e){}"
        "        }"
        "      }"
        "    }"
        "  }"
        "  return false;"
        "} catch(e){ return false; }",
        token
    )
    if callback_fired:
        log_event(f"reCAPTCHA token injected + callback fired for {engine}.")
        return True
    # Step 3 — form-submit fallback
    submitted = driver.execute_script(
        "var el=document.getElementById('g-recaptcha-response');"
        "if(!el) return false;"
        "var form=el.closest('form');"
        "if(form){try{form.submit();return true;}catch(e){}}"
        "return false;"
    )
    if submitted:
        log_event(f"reCAPTCHA token injected; callback not found — form submitted for {engine}.")
    else:
        log_event(f"reCAPTCHA token injected for {engine}; no callback or form found (page may auto-proceed).")
    return True


def _handle_captcha_2captcha(driver, captcha_type, engine, api_key):
    """Try to solve via 2captcha API. Returns True on success, False on failure."""
    try:
        url = driver.current_url
        # Extract sitekey
        sitekey = None
        try:
            el = driver.find_element(By.CSS_SELECTOR,
                "div.g-recaptcha, div[data-sitekey]")
            sitekey = el.get_attribute("data-sitekey")
        except Exception: pass
        if not sitekey:
            log_event(f"2captcha: could not extract sitekey from {engine}.")
            return False
        # Submit task
        resp = requests.post("http://2captcha.com/in.php", data={
            "key": api_key, "method": "userrecaptcha",
            "googlekey": sitekey, "pageurl": url, "json": 1
        }, timeout=15).json()
        if resp.get("status") != 1:
            log_event(f"2captcha submit failed: {resp}"); return False
        task_id = resp["request"]
        # Poll for result
        for _ in range(24):
            time.sleep(5)
            res = requests.get(
                f"http://2captcha.com/res.php?key={api_key}&action=get&id={task_id}&json=1",
                timeout=10
            ).json()
            if res.get("status") == 1:
                token = res["request"]
                _inject_recaptcha_token(driver, token, engine)
                return True
            if res.get("request") != "CAPTCHA_NOT_READY":  # Fix B: was CAPCHA_NOT_READY (typo)
                log_event(f"2captcha error: {res}"); return False
        log_event("2captcha: timed out waiting for token.")
        return False
    except Exception as e:
        log_event(f"2captcha exception: {e}")
        return False


def _handle_captcha_anticaptcha(driver, captcha_type, engine, api_key):
    """Try to solve via AntiCaptcha API. Returns True on success."""
    try:
        url      = driver.current_url
        sitekey  = None
        try:
            el      = driver.find_element(By.CSS_SELECTOR,
                "div.g-recaptcha, div[data-sitekey]")
            sitekey = el.get_attribute("data-sitekey")
        except Exception: pass
        if not sitekey:
            log_event(f"AntiCaptcha: could not extract sitekey from {engine}.")
            return False
        create = requests.post("https://api.anti-captcha.com/createTask", json={
            "clientKey": api_key,
            "task": {
                "type": "NoCaptchaTaskProxyless",
                "websiteURL": url,
                "websiteKey": sitekey,
            }
        }, timeout=15).json()
        if create.get("errorId", 1) != 0:
            log_event(f"AntiCaptcha createTask error: {create}"); return False
        task_id = create["taskId"]
        for _ in range(24):
            time.sleep(5)
            res = requests.post("https://api.anti-captcha.com/getTaskResult", json={
                "clientKey": api_key, "taskId": task_id
            }, timeout=10).json()
            if res.get("status") == "ready":
                token = res["solution"]["gRecaptchaResponse"]
                _inject_recaptcha_token(driver, token, engine)
                return True
            if res.get("errorId", 0) != 0:
                log_event(f"AntiCaptcha error: {res}"); return False
        log_event("AntiCaptcha: timed out.")
        return False
    except Exception as e:
        log_event(f"AntiCaptcha exception: {e}")
        return False


def _handle_captcha_hcaptcha(driver, captcha_type, engine):
    """Best-effort hCaptcha bypass via JS token injection. Falls back gracefully."""
    try:
        driver.execute_script("""
            var el = document.querySelector('[name="h-captcha-response"]');
            if(el){ el.value = 'bypass-attempt'; }
            var el2 = document.querySelector('[data-hcaptcha-response]');
            if(el2){ el2.value = 'bypass-attempt'; }
        """)
        log_event(f"hCaptcha bypass attempt on {engine} (best-effort).")
        return True
    except Exception as e:
        log_event(f"hCaptcha bypass error: {e}")
        return False


def handle_captcha(driver, captcha_type, engine, app_ref,
                   mode="manual", api_key="",
                   max_wait=60, retry_delay=10, auto_visible=True):
    """Dispatch to the correct CAPTCHA handler. Returns True to retry the page."""
    solved = False
    if mode == "manual":
        solved = _handle_captcha_manual(
            driver, captcha_type, engine, app_ref,
            max_wait=max_wait, auto_visible=auto_visible)
    elif mode == "2captcha" and api_key:
        solved = _handle_captcha_2captcha(driver, captcha_type, engine, api_key)
        if not solved:
            log_event("2captcha failed — falling back to manual.")
            solved = _handle_captcha_manual(
                driver, captcha_type, engine, app_ref,
                max_wait=max_wait, auto_visible=auto_visible)
    elif mode == "anticaptcha" and api_key:
        solved = _handle_captcha_anticaptcha(driver, captcha_type, engine, api_key)
        if not solved:
            log_event("AntiCaptcha failed — falling back to manual.")
            solved = _handle_captcha_manual(
                driver, captcha_type, engine, app_ref,
                max_wait=max_wait, auto_visible=auto_visible)
    elif mode == "hcaptcha":
        solved = _handle_captcha_hcaptcha(driver, captcha_type, engine)
        if not solved:
            log_event("hCaptcha bypass failed — falling back to manual.")
            solved = _handle_captcha_manual(
                driver, captcha_type, engine, app_ref,
                max_wait=max_wait, auto_visible=auto_visible)
    else:
        solved = _handle_captcha_manual(
            driver, captcha_type, engine, app_ref,
            max_wait=max_wait, auto_visible=auto_visible)

    log_event(f"CAPTCHA handle complete — engine={engine} type={captcha_type} "
              f"mode={mode} solved={solved}")
    if retry_delay > 0:
        time.sleep(retry_delay)
    return solved

# ═══════════════════════════════════════════════════════════════════════════════
# ENGINE SCRAPERS — requests (BS4) mode
# All scrapers now use _make_session() with retry adapter (not bare requests.get)
# ═══════════════════════════════════════════════════════════════════════════════
HEADERS_BASE = {
    "Accept-Language": "en-US,en;q=0.9",
    "Accept": "text/html,application/xhtml+xml;q=0.9,*/*;q=0.8",
}

def headers_with_ua(pool=None):
    h = HEADERS_BASE.copy()
    h["User-Agent"] = random.choice(pool or DEFAULT_USER_AGENTS)
    return h

def add_date_to_url(url, engine, ds, du):
    if not ds and not du: return url
    if engine == "bing":
        if ds and du:
            return url + f"&filters=ex1%3A%22ez5_{ds.replace('-','')}_{du.replace('-','')}%22"
        elif ds:
            d = ds.replace("-", "")
            return url + f"&filters=ex1%3A%22ez5_{d}_{d}%22"
        return url
    elif engine == "yahoo":
        if ds and du: return url + f"&btf=d&b2={ds}&b3={du}"
        elif ds:      return url + f"&btf=d&b2={ds}"
        return url
    elif engine == "duckduckgo":
        if ds and du:
            delta = (datetime.strptime(du, "%Y-%m-%d") -
                     datetime.strptime(ds, "%Y-%m-%d")).days
            df = ("d" if delta <= 1 else "w" if delta <= 7
                  else "m" if delta <= 30 else "y" if delta <= 365 else "")
            if not df:
                log_event(f"DDG: date range too wide ({ds}..{du}), skipped.")
        else: df = ""
        return (url + f"&df={df}") if df else url
    elif engine == "google":
        # Fix A: only append &tbs= when there is actually a date filter;
        # appending &tbs= (empty value) confuses Google and wastes URL space.
        if ds and du:
            tbs = f"cdr:1,cd_min:{ds.replace('-','/')},cd_max:{du.replace('-','/')}"
            return url + f"&tbs={tbs}"
        return url
    elif engine == "startpage":
        # BUG 25 fix: Startpage uses its own date filter params, not Google's tbs=
        # with_date values: d=day, w=week, m=month, y=year
        # For a custom range we append the year as a "y" filter (best available)
        if ds:
            return url + "&with_date=y"
        return url
    elif engine == "yandex":
        if ds and du:
            suffix = " date:" + ds.replace("-", "") + ".." + du.replace("-", "")
            if "text=" in url:
                old = url.split("text=")[1].split("&")[0]
                new = quote_plus(old + suffix)
                return url.replace(f"text={old}", f"text={new}")
        return url
    # Engines below do not support date filtering — return silently
    return url

def _links_from_soup(soup, selectors, exclude_domains=None):
    """Try each (container_sel, link_sel) pair; return first non-empty list.
    exclude_domains is passed to _is_filtered_result_url so engine-internal
    tracker/redirect URLs (e.g. bing.com/ck/a?) are dropped here rather than
    leaking out as results.
    """
    seen, out = set(), []
    for csel, lsel in selectors:
        for container in soup.select(csel):
            a    = container.select_one(lsel) if lsel else container
            href = a.get("href", "") if a else ""
            if (href
                    and not _is_filtered_result_url(href, exclude_domains=exclude_domains)
                    and href not in seen):
                seen.add(href); out.append(href)
        if out: return out
    return out

def _is_filtered_result_url(href, exclude_domains=None):
    """Central URL quality filter for all engines.
    Filters out engine-internal, captcha/block, and non-http(s) links.
    """
    if not href:
        return True
    href = href.strip()
    if not (href.startswith("http://") or href.startswith("https://")):
        return True
    try:
        pu = urlparse(href)
        host = (pu.hostname or "").lower()
        pathq = (pu.path + "?" + pu.query).lower()
    except Exception:
        return True
    if not host:
        return True

    # Generic anti-bot/internal pages that should never be counted as findings.
    # IMPORTANT: keep tokens specific — broad strings like "verify" match legitimate
    # result URLs (e.g. /verify-email, ssllabs.com/ssltest/analyze?...) and cause
    # silent false-positive drops, especially after Yahoo/AOL redirect unwrapping.
    blocked_tokens = (
        "captcha", "recaptcha", "/sorry", "sorry/index",
        "consent.google", "consent.yahoo", "challenge",
        "/verify-you-are-human", "are-you-a-robot", "/bot-check",
    )
    if any(tok in pathq for tok in blocked_tokens):
        return True

    for d in (exclude_domains or []):
        d = (d or "").lower().strip()
        if d and (host == d or host.endswith("." + d)):
            return True
    return False

def _google_extract_result_href(href):
    """Unwrap Google redirect URLs like /url?q=https://target."""
    if not href:
        return ""
    href = href.strip()
    if href.startswith("/url?"):
        try:
            q = parse_qs(urlparse(href).query).get("q", [""])[0]
            return unquote(q) if q else ""
        except Exception:
            return ""
    return href

# Pre-check pysocks availability once at import time so SOCKS proxy failures
# are caught early with a clear message rather than silently returning [] from
# every engine scraper (the except-swallowing in _session_get hid the root cause).
try:
    import socks as _socks_lib  # noqa: F401  (pysocks)
    _SOCKS_AVAILABLE = True
except ImportError:
    _SOCKS_AVAILABLE = False

_tl_sessions = threading.local()

def _make_session():
    """Thread-local session pool: one persistent session per thread reused
    across all requests. Pool sizes tuned for high-throughput BS4 mode.
    Creating a new Session per request caused socket exhaustion at 200 workers.

    Note on proxies: the session itself carries no proxy configuration.
    Proxies are passed per-call via the `proxies=` argument to Session.get()
    (see _session_get).  This means a single thread can safely scrape two
    different engines with different proxies in sequence — the connection pool
    is shared for performance, but the proxy routing is determined at the
    individual request level, not at session-mount level.

    SOCKS note: requests routes SOCKS proxies via pysocks directly, bypassing
    the HTTPAdapter connection pool entirely.  The retry adapter still applies
    for HTTP/HTTPS proxies.  If pysocks is missing, _session_get will raise a
    descriptive RuntimeError rather than silently returning empty results.
    """
    if not getattr(_tl_sessions, "session", None):
        import urllib3
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        s = requests.Session()
        # verify=False is intentional: many proxy servers (especially HTTP→HTTPS
        # CONNECT tunnels and intercepting SOCKS proxies) present self-signed or
        # mis-matched TLS certs. Without this, every HTTPS target raises
        # SSLError: CERTIFICATE_VERIFY_FAILED through the proxy and gets silently
        # swallowed as an empty result set. We are scraping public search engines,
        # not exchanging secrets, so cert verification gives us nothing here.
        s.verify = False
        r = Retry(total=3, backoff_factor=1,
                  status_forcelist=[429, 500, 502, 503, 504])
        adapter = HTTPAdapter(
            max_retries=r,
            pool_connections=50,
            pool_maxsize=200,
        )
        s.mount("https://", adapter)
        s.mount("http://",  adapter)
        _tl_sessions.session = s
    return _tl_sessions.session

def _session_get(sess, url, headers=None, proxies=None, timeout=12):
    """Wrapper around Session.get with proxy runtime-failure feedback.

    SOCKS guard: if the selected proxy is a SOCKS proxy and pysocks is not
    installed, raise immediately with a descriptive message instead of letting
    requests raise an opaque MissingSchema / ConnectionError that gets swallowed
    as an empty result set by every engine scraper's except block.
    """
    if proxies:
        proxy_url = proxies.get("https") or proxies.get("http") or ""
        if proxy_url and ("socks5" in proxy_url or "socks4" in proxy_url):
            if not _SOCKS_AVAILABLE:
                msg = (
                    f"SOCKS proxy selected ({proxy_url}) but pysocks is not installed. "
                    "Run: pip install pysocks --break-system-packages"
                )
                log_event(f"[proxy] ERROR: {msg}")
                raise RuntimeError(msg)
    try:
        # verify=False: proxy CONNECT tunnels and intercepting proxies often
        # present self-signed certs on HTTPS targets (port 443). Without this
        # every HTTPS engine scrape raises SSLError through a proxy. We disable
        # per-call (not just on the session) so it is never accidentally skipped.
        r = sess.get(url, headers=headers, proxies=proxies, timeout=timeout,
                     verify=False)
        if proxies:
            proxy_url = proxies.get("https") or proxies.get("http")
            if proxy_url:
                try:
                    proxy_manager.report_runtime_success(
                        proxy_url,
                        https_success=str(url).lower().startswith("https://")
                    )
                except Exception:
                    pass
        return r
    except requests.exceptions.SSLError as e:
        # SSL errors through a proxy mean the proxy cannot tunnel HTTPS properly.
        # Demote it hard so it doesn't get picked again for HTTPS targets.
        log_event(f"[proxy] SSLError for {url} → demoting proxy: {e}")
        if proxies:
            proxy_url = proxies.get("https") or proxies.get("http")
            if proxy_url:
                try: proxy_manager.report_runtime_failure(proxy_url, str(e))
                except Exception: pass
        raise
    except requests.exceptions.ProxyError as e:
        # ProxyError = proxy refused CONNECT on port 443, or is dead.
        log_event(f"[proxy] ProxyError for {url} → demoting proxy: {e}")
        if proxies:
            proxy_url = proxies.get("https") or proxies.get("http")
            if proxy_url:
                try: proxy_manager.report_runtime_failure(proxy_url, str(e))
                except Exception: pass
        raise
    except Exception as e:
        if proxies:
            proxy_url = proxies.get("https") or proxies.get("http")
            if proxy_url:
                try:
                    proxy_manager.report_runtime_failure(proxy_url, str(e))
                except Exception:
                    pass
        raise

# ── Original 9 engines ────────────────────────────────────────────────────────

def bing_search_links(q, page=0, headers=None, proxies=None, timeout=12,
                      date_since=None, date_until=None):
    try:
        sess  = _make_session()
        first = page * 10 + 1
        url   = f"https://www.bing.com/search?q={quote_plus(q)}&first={first}&FORM=PERE"
        url   = add_date_to_url(url, "bing", date_since, date_until)
        r     = _session_get(sess, url, headers=headers, proxies=proxies, timeout=timeout)
        # Bing returns 200 OK with a bot/CAPTCHA page instead of a 429.
        # Detect it early so we log clearly and don't waste time parsing.
        low = r.text.lower()
        if ("captcha" in low and "input" in low) or "dog?mkt=" in r.url.lower() or \
                "botsignalcategory" in low or "/sorry/" in r.url.lower():
            log_event("bing: bot/captcha page detected — rotate proxy or add delay.")
            return []
        soup  = BeautifulSoup(r.text, "html.parser")
        out   = _links_from_soup(soup, [
            ("li.b_algo", "h2 a"),
            ("li.b_algo", "a[href^='http']"),
        ], exclude_domains=["bing.com", "microsoft.com"])
        if not out:
            seen = set()
            for a in soup.select("li.b_algo a"):
                h = a.get("href", "")
                if not _is_filtered_result_url(
                        h, exclude_domains=["bing.com", "microsoft.com"]) and h not in seen:
                    seen.add(h); out.append(h)
        return out
    except Exception as e:
        log_event(f"bing error: {e}"); return []

def duckduckgo_search_links(q, page=0, headers=None, proxies=None, timeout=12,
                             date_since=None, date_until=None):
    """DDG HTML endpoint.
    BUG 2 fix: use the `s` offset parameter (documented) rather than trying to
    chain vqd POST tokens, which is fragile and often returns page-1 results again.
    Page 0 → s=0, page 1 → s=30, page 2 → s=60, etc.  (DDG HTML uses step=30.)
    """
    try:
        sess = _make_session()
        h    = dict(headers or {})
        h.setdefault("Referer", "https://html.duckduckgo.com/")
        h.setdefault("Accept", "text/html,application/xhtml+xml;q=0.9,*/*;q=0.8")
        offset = page * 30
        base = (f"https://html.duckduckgo.com/html/?q={quote_plus(q)}&s={offset}"
                if page > 0 else
                f"https://html.duckduckgo.com/html/?q={quote_plus(q)}")
        base = add_date_to_url(base, "duckduckgo", date_since, date_until)
        r    = _session_get(sess, base, headers=h, proxies=proxies, timeout=timeout)
        soup = BeautifulSoup(r.text, "html.parser")
        out, seen = [], set()
        # Primary selector; also try result__url as href fallback
        for sel in ["a.result__a", "h2.result__title a", "a.result__url"]:
            for a in soup.select(sel):
                href = a.get("href", "")
                # DDG HTML wraps outbound links as /l/?uddg=<encoded-url> — unwrap
                if href and "/l/?uddg=" in href:
                    try:
                        href = unquote(parse_qs(urlparse(href).query).get("uddg", [""])[0])
                    except Exception:
                        pass
                if (not _is_filtered_result_url(href, exclude_domains=["duckduckgo.com"])
                        and href not in seen):
                    seen.add(href); out.append(href)
            if out: break
        return out
    except Exception as e:
        log_event(f"duckduckgo error: {e}"); return []

def brave_search_links(q, page=0, headers=None, proxies=None, timeout=12,
                        date_since=None, date_until=None):
    """Brave is a full React SPA — BS4 scraping always returns empty.
    This function is retained so ENGINE_FUNC_MAP is complete and the normal
    (non-BS4-only) path can call it as a last-resort fallback, but in
    BS4-only mode Brave is in _SELENIUM_ONLY_ENGINES and is never called.
    Use Selenium for reliable Brave results.
    """
    try:
        sess = _make_session()
        url  = f"https://search.brave.com/search?q={quote_plus(q)}&offset={page*10}&source=web"
        h    = dict(headers or {})
        h.setdefault("Accept",     "text/html,application/xhtml+xml;q=0.9,*/*;q=0.8")
        h.setdefault("User-Agent", random.choice(DEFAULT_USER_AGENTS))
        r    = _session_get(sess, url, headers=h, proxies=proxies, timeout=timeout)
        soup = BeautifulSoup(r.text, "html.parser")
        out, seen = [], set()
        for sel in [
            "a[data-testid='result-title-link']",           # 2024+ primary
            "div.snippet-title a",                          # alternate title anchor
            "div.result a[data-testid='result-title-link']",
            "a.result-header",                              # legacy fallback
            "a.snippet-url",                                # legacy fallback
        ]:
            for a in soup.select(sel):
                hf = a.get("href", "")
                if (not _is_filtered_result_url(
                        hf, exclude_domains=["brave.com", "search.brave.com"])
                        and hf not in seen):
                    seen.add(hf); out.append(hf)
            if out: break
        return out
    except Exception as e:
        log_event(f"brave error: {e}"); return []

def yandex_search_links(q, page=0, headers=None, proxies=None, timeout=12,
                         date_since=None, date_until=None):
    try:
        sess = _make_session()
        url  = f"https://yandex.com/search/?text={quote_plus(q)}&p={page}"
        url  = add_date_to_url(url, "yandex", date_since, date_until)
        h    = dict(headers or {})
        h.setdefault("User-Agent", random.choice(DEFAULT_USER_AGENTS))
        h.setdefault("Accept-Language", "en-US,en;q=0.9")
        r    = _session_get(sess, url, headers=h, proxies=proxies, timeout=timeout)
        # Yandex redirects to /showcaptcha on bot detection and returns 200 OK.
        if "showcaptcha" in r.url.lower() or "captcha" in r.url.lower() \
                or "showcaptcha" in r.text.lower():
            log_event("yandex: captcha/block page detected — rotate proxy or add delay.")
            return []
        soup = BeautifulSoup(r.text, "html.parser")
        out, seen = [], set()
        # a.organic__url holds the *display* domain — its href is a Yandex /redir/ URL.
        # The real external link href lives on the heading anchor (a.Link) wrapping h2/h3.
        # We try heading links first, then fall back to any a.Link with a real http href.
        for sel in [
            "h2.organic__title a.Link",       # heading anchor — real external href
            "h3.organic__title a.Link",
            "a.Link[href^='http']",           # broad fallback — filter /redir/ below
            "li.serp-item a[href^='http']",   # older SERP layout
        ]:
            for a in soup.select(sel):
                h2 = a.get("href", "")
                # Skip Yandex internal redirect paths (/redir/, /clck/)
                if h2 and ("/redir/" in h2 or "/clck/" in h2):
                    continue
                if (not _is_filtered_result_url(
                        h2, exclude_domains=["yandex.com", "yandex.ru"])
                        and h2 not in seen):
                    seen.add(h2); out.append(h2)
            if out: break

        # ── FALLBACK post-filter (Bug 6): strip any yandex.com / yandex.ru URLs
        # that slipped through the broad a.Link fallback selector before
        # _is_filtered_result_url had a chance to catch them.  This covers
        # pagination, "show more", and toolbar links whose host ends in yandex.*.
        if out:
            _yandex_hosts = ("yandex.com", "yandex.ru", "yandex.by",
                             "yandex.kz", "yandex.ua")
            cleaned = []
            for link in out:
                try:
                    host = urlparse(link).hostname or ""
                    if any(host == d or host.endswith("." + d)
                           for d in _yandex_hosts):
                        continue
                except Exception:
                    pass
                cleaned.append(link)
            if len(cleaned) < len(out):
                log_event(f"yandex: post-filter removed "
                          f"{len(out) - len(cleaned)} internal Yandex links.")
            out = cleaned

        return out
    except Exception as e:
        log_event(f"yandex error: {e}"); return []

def ask_search_links(q, page=0, headers=None, proxies=None, timeout=12,
                      date_since=None, date_until=None):
    try:
        sess = _make_session()
        url  = f"https://www.ask.com/web?q={quote_plus(q)}&page={page+1}"
        h    = dict(headers or {})
        h.setdefault("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
        h.setdefault("Referer", "https://www.ask.com/")
        h.setdefault("User-Agent", random.choice(DEFAULT_USER_AGENTS))
        r    = _session_get(sess, url, headers=h, proxies=proxies, timeout=timeout)
        soup = BeautifulSoup(r.text, "html.parser")
        # Ask returns an empty JS bundle when bot-detected — no result containers at all.
        if not soup.select("div.PartialSearchResults-item, div.result-title, "
                           "div.web-result, li.result"):
            log_event("ask: empty JS shell or bot block — no result containers found.")
            # ── FALLBACK (Bug 2): retry with alternate URL pattern + fresh UA ─
            try:
                alt_url = (f"https://www.ask.com/web?q={quote_plus(q)}"
                           f"&qo=serpSearchTopBox&o=0&page={page+1}")
                alt_h   = dict(h)
                alt_h["User-Agent"]   = random.choice(DEFAULT_USER_AGENTS)
                alt_h["Referer"]      = "https://www.ask.com/"
                alt_h["Accept-Language"] = "en-US,en;q=0.9"
                alt_r   = _session_get(sess, alt_url, headers=alt_h,
                                       proxies=proxies, timeout=timeout)
                soup    = BeautifulSoup(alt_r.text, "html.parser")
                if not soup.select(
                    "div.PartialSearchResults-item, div.result-title, "
                    "div.web-result, li.result, div.PartialSearchResults-item-title, "
                    "div.web-result-container, div[class*='ResultsList']"
                ):
                    log_event("ask: fallback URL also returned empty — engine blocked.")
                    return []
                log_event("ask: fallback URL succeeded — parsing alternate layout.")
            except Exception as e_alt:
                log_event(f"ask: fallback attempt error: {e_alt}")
                return []
        out, seen = [], set()
        # BUG 3 fix: use result-container selectors instead of grabbing every href.
        for sel in [
            "div.PartialSearchResults-item a.result-title-link",  # 2024 layout
            "div.result-title a",
            "div.web-result a.result-link",
            "li.result a[href^='http']",                          # older layout
            # ── ADDITIONAL FALLBACK SELECTORS (Bug 2) ──────────────────────
            "div.PartialSearchResults-item-title a",              # 2025/2026 layout
            "div.web-result-container a[href^='http']",           # 2025 alt container
            "div[class*='ResultsList'] a[href^='http']",          # generic class match
            "div[class*='result'] h3 a[href^='http']",            # broad h3 title links
        ]:
            for a in soup.select(sel):
                h2 = a.get("href", "")
                if not _is_filtered_result_url(h2, exclude_domains=["ask.com"]) and h2 not in seen:
                    seen.add(h2); out.append(h2)
            if out: break
        return out
    except Exception as e:
        log_event(f"ask error: {e}"); return []

def _yahoo_unwrap_href(href):
    """Unwrap Yahoo Search result redirect URLs.

    Yahoo wraps outbound links in two formats:
      1. https://r.search.yahoo.com/_ylt=.../RU=https%3A%2F%2Ftarget.com/RK=...
         → path-encoded RU= segment, same as AOL — handled by _aol_unwrap_href logic.
      2. https://search.yahoo.com/cbclk/... with ?url=https%3A%2F%2Ftarget.com
         → query-string url= param.
      3. Plain https://target.com — already unwrapped, pass through.

    _aol_unwrap_href is NOT used here: AOL uses r.aol.com as the redirect host;
    Yahoo uses r.search.yahoo.com.  Both use the /RU= path pattern so the same
    regex works, but we also need to handle the ?url= query variant Yahoo uses
    in some layouts.
    """
    if not href:
        return href
    try:
        pu = urlparse(href)
        qs = parse_qs(pu.query)
        # Pattern 1 — url= in query string (Yahoo cbclk redirects)
        if "url" in qs:
            candidate = unquote(qs["url"][0])
            if candidate.startswith("http"):
                return candidate
        # Pattern 2 — RU= in query string
        if "RU" in qs:
            return unquote(qs["RU"][0])
        # Pattern 3 — /RU=<encoded>/ in path (r.search.yahoo.com style)
        if pu.path:
            m = re.search(r'/RU=([^/]+)', pu.path)
            if m:
                return unquote(m.group(1))
    except Exception:
        pass
    return href

def yahoo_search_links(q, page=0, headers=None, proxies=None, timeout=12,
                        date_since=None, date_until=None):
    try:
        sess = _make_session()
        h    = dict(headers or {})
        # Yahoo requires Accept-Language + a minimal consent cookie to skip the
        # GDPR/consent redirect that returns a page with zero result containers.
        h.setdefault("Accept-Language", "en-US,en;q=0.9")
        h.setdefault("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
        h.setdefault("Referer", "https://search.yahoo.com/")
        h.setdefault("User-Agent", random.choice(DEFAULT_USER_AGENTS))
        sess.cookies.set("sB",    "v=1&pn=10&rw=new",  domain=".yahoo.com")
        sess.cookies.set("GUC",   "AQE=",               domain=".yahoo.com")
        url  = f"https://search.yahoo.com/search?p={quote_plus(q)}&b={page*10+1}&pz=10"
        url  = add_date_to_url(url, "yahoo", date_since, date_until)
        r    = _session_get(sess, url, headers=h, proxies=proxies, timeout=timeout)
        # Detect consent/login wall — no result containers present
        low = r.text.lower()
        if "login.yahoo.com" in r.url or "consent.yahoo.com" in r.url:
            log_event("yahoo: consent/login redirect — skipping page.")
            return []
        soup = BeautifulSoup(r.text, "html.parser")
        out, seen = [], set()
        # Use _yahoo_unwrap_href (not _aol_unwrap_href) — Yahoo's redirect host
        # is r.search.yahoo.com, not r.aol.com, but the /RU= path pattern is shared.
        # Also handles Yahoo's ?url= cbclk format which AOL never uses.
        for sel in [
            "div.algo h3.title a",        # primary 2024-2026 layout
            "div.algo div.compTitle a",   # alternate title container
            "h3.title a",                 # classic layout
            "div.compTitle a",            # classic alt
            # ── ADDITIONAL FALLBACK SELECTORS (Bug 4) ──────────────────────
            "div.Sr h3.title a",          # 2025/2026 container rename
            "div.Algo h3.title a",        # regional variant capitalisation
            "li.first h3.title a",        # list-item layout fallback
            "div.dd h3 a[href^='http']",  # broad dd-container fallback
            "ol.reg li div.compTitle a",  # ordered-list result layout
        ]:
            for a in soup.select(sel):
                raw  = a.get("href", "")
                href = _yahoo_unwrap_href(raw)
                if not _is_filtered_result_url(href, exclude_domains=["yahoo.com"]) and href not in seen:
                    seen.add(href); out.append(href)
            if out: break

        # ── FALLBACK (Bug 3): retry with correctly-scoped consent cookies ────
        # requests' cookie domain matching requires the cookie domain to match
        # the exact request host (search.yahoo.com), not just the TLD (.yahoo.com).
        # If the first attempt found nothing, re-try with per-host cookies injected.
        if not out:
            try:
                from requests.cookies import RequestsCookieJar
                jar = RequestsCookieJar()
                jar.set("sB",  "v=1&pn=10&rw=new", domain="search.yahoo.com", path="/")
                jar.set("GUC", "AQE=",              domain="search.yahoo.com", path="/")
                jar.set("B",   "aeaebfaketoken00",  domain=".yahoo.com",       path="/")
                retry_h = dict(h)
                retry_h["Cookie"] = "sB=v%3D1%26pn%3D10%26rw%3Dnew; GUC=AQE="
                r2   = sess.get(url, headers=retry_h, cookies=jar,
                                proxies=proxies, timeout=timeout, verify=False)
                soup2 = BeautifulSoup(r2.text, "html.parser")
                for sel in [
                    "div.algo h3.title a", "div.Sr h3.title a",
                    "div.Algo h3.title a", "h3.title a",
                    "div.dd h3 a[href^='http']", "ol.reg li div.compTitle a",
                ]:
                    for a in soup2.select(sel):
                        raw  = a.get("href", "")
                        href = _yahoo_unwrap_href(raw)
                        if not _is_filtered_result_url(
                                href, exclude_domains=["yahoo.com"]) and href not in seen:
                            seen.add(href); out.append(href)
                    if out: break
                if out:
                    log_event(f"yahoo: per-host cookie retry returned {len(out)} results.")
            except Exception as e_retry:
                log_event(f"yahoo: cookie retry error: {e_retry}")

        return out
    except Exception as e:
        log_event(f"yahoo error: {e}"); return []

def ecosia_search_links(q, page=0, headers=None, proxies=None, timeout=12,
                         date_since=None, date_until=None):
    try:
        sess = _make_session()
        url  = f"https://www.ecosia.org/search?q={quote_plus(q)}&p={page}"
        h    = dict(headers or {})
        h.setdefault("Accept-Language", "en-US,en;q=0.9")
        h.setdefault("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
        h.setdefault("User-Agent", random.choice(DEFAULT_USER_AGENTS))
        # Ecosia requires cookie consent before serving results. Inject the
        # consent cookie so we get results instead of a GDPR wall.
        sess.cookies.set("ecosia_cc", "1",    domain="www.ecosia.org")
        sess.cookies.set("ecosia_p",  "0",    domain="www.ecosia.org")
        sess.cookies.set("de",        "false", domain="www.ecosia.org")
        r    = _session_get(sess, url, headers=h, proxies=proxies, timeout=timeout)
        soup = BeautifulSoup(r.text, "html.parser")
        # Detect consent wall (no result containers present)
        if soup.select_one("div[class*='consent'], div[class*='cookie'], "
                           "button[data-testid*='accept']") and \
                not soup.select("a.result__link, div.result-body, article.result"):
            log_event("ecosia: consent/cookie wall detected — results unavailable.")
            # ── FALLBACK (Bug 5): Ecosia moved to localStorage consent in 2024.
            # Sending Referer from within ecosia.org bypasses the consent wall
            # server-side. Also inject the newer cookie key as a header value.
            try:
                fb_h = dict(h)
                fb_h["Referer"]        = "https://www.ecosia.org/"
                fb_h["Cookie"]         = (
                    "user-has-accepted-cookies=true; "
                    "ecosia_cc=1; ecosia_p=0; de=false"
                )
                fb_h["User-Agent"]     = random.choice(DEFAULT_USER_AGENTS)
                fb_h["Accept-Language"] = "en-US,en;q=0.9"
                # Use a fresh session so the stale consent-wall cookies don't persist
                fb_sess = _make_session()
                fb_r    = _session_get(fb_sess, url, headers=fb_h,
                                       proxies=proxies, timeout=timeout)
                soup    = BeautifulSoup(fb_r.text, "html.parser")
                if not soup.select(
                    "a.result__link, div.result-body, article.result, "
                    "div.result__body, a.result__title"
                ):
                    log_event("ecosia: fallback also hit consent wall — "
                              "no results available.")
                    return []
                log_event("ecosia: Referer-based consent fallback succeeded.")
            except Exception as e_fb:
                log_event(f"ecosia: fallback error: {e_fb}")
                return []
        out, seen = [], set()
        for sel in [
            "a.result__link",                                        # current primary
            "div.result-body a.result-title",                        # SSR layout
            "article.result a.result-title",                         # SSR alt
            "div.result__body a[href^='http']",                      # current fallback
            "a.result__title",                                       # older layout
            "a.result-title",                                        # older layout alt
            "article.result a[href^='http']:not([href*='ecosia'])",  # generic fallback
        ]:
            for a in soup.select(sel):
                h2 = a.get("href", "")
                if not _is_filtered_result_url(h2, exclude_domains=["ecosia.org"]) and h2 not in seen:
                    seen.add(h2); out.append(h2)
            if out: break
        return out
    except Exception as e:
        log_event(f"ecosia error: {e}"); return []

def startpage_search_links(q, page=0, headers=None, proxies=None, timeout=12,
                             date_since=None, date_until=None):
    try:
        sess = _make_session()
        url  = (f"https://www.startpage.com/search?query={quote_plus(q)}"
                f"&startAt={page*10}&language=english")
        url  = add_date_to_url(url, "startpage", date_since, date_until)
        r    = _session_get(sess, url, headers=headers, proxies=proxies, timeout=timeout)
        low_url = (r.url or "").lower()
        low_txt = (r.text or "").lower()
        if ("captcha-block" in low_url
                or "please verify you are a human" in low_txt
                or "sorry, this request could not be processed" in low_txt):
            log_event("startpage blocked/captcha page detected; skipping this page.")
            return []
        soup = BeautifulSoup(r.text, "html.parser")
        out, seen = [], set()
        for sel in ["a.result-link", "a.w-gl__result-url",
                    "a[data-testid='result-title-a']"]:
            for a in soup.select(sel):
                h = a.get("href", "")
                if not _is_filtered_result_url(
                        h, exclude_domains=["startpage.com", "ixquick.com"]) and h not in seen:
                    seen.add(h); out.append(h)
            if out: break
        return out
    except Exception as e:
        log_event(f"startpage error: {e}"); return []

def google_search_links(q, page=0, headers=None, proxies=None, timeout=12,
                         date_since=None, date_until=None):
    try:
        sess = _make_session()
        url  = f"https://www.google.com/search?q={quote_plus(q)}&start={page*10}&hl=en&num=10"
        url  = add_date_to_url(url, "google", date_since, date_until)
        h    = dict(headers or {})
        h.setdefault("Accept", "text/html,application/xhtml+xml;q=0.9,*/*;q=0.8")
        r    = _session_get(sess, url, headers=h, proxies=proxies, timeout=timeout)
        soup = BeautifulSoup(r.text, "html.parser")
        out, seen = [], set()
        # BUG 1 fix: expanded selector list to handle 2024-2026 Google DOM variants.
        # Selectors tried in order; first non-empty wins.
        selector_pairs = [
            ("div.MjjYud", "h3 a"),          # 2023-2024 primary
            ("div.g", "h3 a"),               # classic fallback
            ("div.yuRUbf", "a"),             # pre-2023
            ("div.tF2Cxc", "a"),             # alternate 2024 variant
            ("div[data-hveid] h3 a", None),  # attribute-based fallback
        ]
        for csel, lsel in selector_pairs:
            for container in soup.select(csel):
                a    = container.select_one(lsel) if lsel else container
                href = _google_extract_result_href(a.get("href", "") if a else "")
                if (not _is_filtered_result_url(
                        href, exclude_domains=["google.com", "gstatic.com", "googleusercontent.com"])
                        and href not in seen):
                    seen.add(href); out.append(href)
            if out: break
        return out
    except Exception as e:
        log_event(f"google error: {e}"); return []

# ── 4 New engines ─────────────────────────────────────────────────────────────

def _aol_unwrap_href(href):
    """AOL (Bing-backed) wraps outbound results through Yahoo/AOL redirect URLs.
    Handles two patterns:
      1. Query-string:  ?...&RU=https%3A%2F%2Ftarget.com
      2. Path-encoded:  /RU=https%3A%2F%2Ftarget.com/RK=...
         The target URL itself contains %2F so we MUST NOT split on "/" before
         extracting the RU= value — instead we use a regex on the raw path.
    """
    if not href:
        return href
    try:
        pu = urlparse(href)
        qs = parse_qs(pu.query)
        # Pattern 1 — RU in query string
        if "RU" in qs:
            return unquote(qs["RU"][0])
        # Pattern 2 — RU= segment in path (e.g. /RU=https%3A%2F%2F.../RK=...)
        # Use regex so encoded slashes (%2F) inside the value don't confuse split.
        if pu.path:
            m = re.search(r'/RU=([^/]+)', pu.path)
            if m:
                return unquote(m.group(1))
    except Exception:
        pass
    return href

def aol_search_links(q, page=0, headers=None, proxies=None, timeout=12,
                      date_since=None, date_until=None):
    """AOL Search — Bing-backed but independent result DOM.
    FIX (Bug 8): inject default headers when caller passes headers=None so AOL's
    CDN does not reject the request as a bot fingerprint.
    """
    try:
        sess = _make_session()
        # ── FIX (Bug 8): build header dict with sane defaults ─────────────────
        h    = dict(headers or {})
        h.setdefault("User-Agent",      random.choice(DEFAULT_USER_AGENTS))
        h.setdefault("Referer",         "https://search.aol.com/")
        h.setdefault("Accept-Language", "en-US,en;q=0.9")
        h.setdefault("Accept",          "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
        url  = f"https://search.aol.com/aol/search?q={quote_plus(q)}&b={page*10+1}"
        r    = _session_get(sess, url, headers=h, proxies=proxies, timeout=timeout)
        soup = BeautifulSoup(r.text, "html.parser")
        out, seen = [], set()
        for sel in [
            "div.algo h3 a",
            "div.dd.algo a",
            "li.first a[href^='http']",
            "a.ac-algo",
            # ── ADDITIONAL FALLBACK SELECTORS (Bug 8) ──────────────────────
            "div.algo div.compTitle a",      # AOL/Yahoo compTitle layout
            "div.Sr h3 a",                   # 2025 container rename (mirrors Yahoo)
            "ol.reg li div.dd h3 a",         # ordered-list SERP layout
            "div[class*='algo'] h3 a",       # class-substring broad match
            "li[class*='first'] h3 a",       # list-item variant
        ]:
            for a in soup.select(sel):
                h2 = _aol_unwrap_href(a.get("href", ""))
                if not _is_filtered_result_url(h2, exclude_domains=["aol.com"]) and h2 not in seen:
                    seen.add(h2); out.append(h2)
            if out: break

        # ── FALLBACK (Bug 8): if still empty, retry with a rotated UA ─────────
        if not out:
            try:
                fb_h = dict(h)
                fb_h["User-Agent"] = random.choice(DEFAULT_USER_AGENTS)
                fb_h["Referer"]    = "https://www.aol.com/"
                fb_r   = _session_get(sess, url, headers=fb_h,
                                      proxies=proxies, timeout=timeout)
                fb_soup = BeautifulSoup(fb_r.text, "html.parser")
                for sel in [
                    "div.algo h3 a", "div.algo div.compTitle a",
                    "div.Sr h3 a",   "div[class*='algo'] h3 a",
                ]:
                    for a in fb_soup.select(sel):
                        h2 = _aol_unwrap_href(a.get("href", ""))
                        if not _is_filtered_result_url(
                                h2, exclude_domains=["aol.com"]) and h2 not in seen:
                            seen.add(h2); out.append(h2)
                    if out: break
                if out:
                    log_event(f"aol: UA-rotation fallback returned {len(out)} results.")
            except Exception as e_fb:
                log_event(f"aol: fallback error: {e_fb}")

        return out
    except Exception as e:
        log_event(f"aol error: {e}"); return []

def yahoojapan_search_links(q, page=0, headers=None, proxies=None, timeout=12,
                              date_since=None, date_until=None):
    """Yahoo Japan — fully separate from Yahoo US, UTF-8 Japanese search.
    FIX (Bug 9): inject Referer + User-Agent so Yahoo Japan CDN does not
    geo-fence the request. Also fall back to a URL without rkf=1 (removed
    from Yahoo Japan's API in 2024) if the primary attempt returns empty.
    """
    try:
        sess = _make_session()
        h    = dict(headers or {})
        # Hard-set Accept-Language for Japanese results (keep existing behaviour)
        h["Accept-Language"] = "ja,en;q=0.9"
        # ── FIX (Bug 9): add missing headers ─────────────────────────────────
        h.setdefault("User-Agent", random.choice(DEFAULT_USER_AGENTS))
        h.setdefault("Referer",    "https://search.yahoo.co.jp/")
        h.setdefault("Accept",     "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
        url  = (f"https://search.yahoo.co.jp/search?p={quote_plus(q)}"
                f"&b={page*10+1}&rkf=1")
        r    = _session_get(sess, url, headers=h, proxies=proxies, timeout=timeout)
        soup = BeautifulSoup(r.text, "html.parser")
        out, seen = [], set()
        for sel in ["h3.sw-Card__title a", "div.sw-Card__content a",
                    "a.sw-Card__titleLink", "a[href^='http']"]:
            for a in soup.select(sel):
                href = a.get("href", "")
                if (not _is_filtered_result_url(href, exclude_domains=["yahoo.co.jp"])
                        and href not in seen):
                    seen.add(href); out.append(href)
            if out: break

        # ── FALLBACK (Bug 9): rkf=1 was removed in 2024 and causes a redirect
        # that adds a round-trip and sometimes drops results.  If primary attempt
        # is empty, retry without rkf=1 and with an expanded selector list.
        if not out:
            try:
                fb_url = (f"https://search.yahoo.co.jp/search?p={quote_plus(q)}"
                          f"&b={page*10+1}")
                fb_h   = dict(h)
                fb_h["User-Agent"] = random.choice(DEFAULT_USER_AGENTS)
                fb_r   = _session_get(sess, fb_url, headers=fb_h,
                                      proxies=proxies, timeout=timeout)
                fb_soup = BeautifulSoup(fb_r.text, "html.parser")
                for sel in [
                    "h3.sw-Card__title a",
                    "div.sw-Card__content a",
                    "a.sw-Card__titleLink",
                    # ── additional 2025 Yahoo Japan selectors ──────────────
                    "div.SearchResult__body h3 a",
                    "li.sw-ResultList__item h3 a",
                    "div[class*='SearchResult'] a[href^='http']",
                    "a[href^='http']:not([href*='yahoo.co.jp'])",  # broad last resort
                ]:
                    for a in fb_soup.select(sel):
                        href = a.get("href", "")
                        if (not _is_filtered_result_url(
                                href, exclude_domains=["yahoo.co.jp"])
                                and href not in seen):
                            seen.add(href); out.append(href)
                    if out: break
                if out:
                    log_event(f"yahoojapan: no-rkf fallback returned {len(out)} results.")
                else:
                    log_event("yahoojapan: both primary and fallback returned 0 results.")
            except Exception as e_fb:
                log_event(f"yahoojapan: fallback error: {e_fb}")

        return out
    except Exception as e:
        log_event(f"yahoojapan error: {e}"); return []

def mojeek_search_links(q, page=0, headers=None, proxies=None, timeout=12,
                         date_since=None, date_until=None):
    """Mojeek — fully independent index, no Google/Bing backend."""
    try:
        sess = _make_session()
        h    = dict(headers or {})
        h.setdefault("Accept-Language", "en-US,en;q=0.9")
        h.setdefault("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
        # ── FIX (Bug 7): always send a real browser UA — Mojeek rate-limits
        # python-requests/x.x.x user-agent with a 200 challenge page that
        # contains no result containers.
        h.setdefault("User-Agent", random.choice(DEFAULT_USER_AGENTS))
        h.setdefault("Referer", "https://www.mojeek.com/")
        url  = (f"https://www.mojeek.com/search?q={quote_plus(q)}"
                f"&s={page*10}")
        r    = _session_get(sess, url, headers=h, proxies=proxies, timeout=timeout)
        soup = BeautifulSoup(r.text, "html.parser")

        # Detect Mojeek bot/challenge page (returns 200 with a verify form)
        _mojeek_challenge = bool(
            soup.select_one("form[action*='challenge'], div[class*='challenge'], "
                            "input[name='mojeek_challenge']")
            or ("please verify" in (r.text or "").lower()
                and not soup.select("ul.results-standard, ul.results"))
        )
        if _mojeek_challenge:
            log_event("mojeek: challenge/bot-verify page — rotating UA and retrying.")
            # ── FALLBACK (Bug 7): rotate UA and retry once ────────────────
            try:
                fb_h = dict(h)
                fb_h["User-Agent"] = random.choice(
                    [ua for ua in DEFAULT_USER_AGENTS if ua != h.get("User-Agent")]
                    or DEFAULT_USER_AGENTS
                )
                fb_r    = _session_get(sess, url, headers=fb_h,
                                       proxies=proxies, timeout=timeout)
                soup    = BeautifulSoup(fb_r.text, "html.parser")
                log_event("mojeek: UA-rotation retry complete.")
            except Exception as e_fb:
                log_event(f"mojeek: UA-rotation retry error: {e_fb}")

        out, seen = [], set()
        # Mojeek DOM (verified 2026):
        #   <ul class="results-standard">
        #     <li>
        #       <a class="ob" href="/search?...&qr=...">  ← internal redirect, excluded
        #       <a class="result-title" href="https://target.com/...">Title</a>  ← REAL URL
        #     </li>
        #   </ul>
        # The title anchor (a.result-title) holds the absolute external URL directly.
        # NOTE: there is NO <h2> wrapper — previous "ul.results-standard li h2 a"
        # selector matched nothing because h2 does not exist in this structure.
        for sel in [
            "ul.results-standard li a.result-title",  # current primary (2024-2026)
            "ul.results li a.result-title",            # alternate ul class
            "li.result a.result-title",                # generic fallback
            "li a.result-title[href^='http']",         # broadest fallback
        ]:
            for a in soup.select(sel):
                href = a.get("href", "")
                if not _is_filtered_result_url(href, exclude_domains=["mojeek.com"]) and href not in seen:
                    seen.add(href); out.append(href)
            if out: break
        if not out:
            log_event(f"mojeek: 0 results on page {page} — possible block or DOM change.")
        return out
    except Exception as e:
        log_event(f"mojeek error: {e}"); return []

def qwant_search_links(q, page=0, headers=None, proxies=None, timeout=12,
                        date_since=None, date_until=None):
    """Qwant — JS-heavy; BS4 path is best-effort fallback. Use Selenium."""
    try:
        sess = _make_session()
        url  = f"https://www.qwant.com/?q={quote_plus(q)}&t=web&p={page}"
        h    = dict(headers or {})
        h.setdefault("Accept", "text/html,application/xhtml+xml;q=0.9,*/*;q=0.8")
        r    = _session_get(sess, url, headers=h, proxies=proxies, timeout=timeout)
        soup = BeautifulSoup(r.text, "html.parser")
        out, seen = [], set()
        # BUG 5 fix: a.WebResult-module__title is a webpack-hashed class that changes
        # on every deploy.  Prefer stable data-testid attributes, then broad fallbacks.
        for sel in [
            "div[data-testid='webResult'] a[data-testid='result-title']",
            "div[data-testid='webResult'] a",
            "article[data-testid='webResult'] a",
            "a[data-testid='result-title']",
            # hashed class kept last as a last-resort (may still match if unchanged)
            "a[class*='WebResult']",
        ]:
            for a in soup.select(sel):
                h2 = a.get("href", "")
                if not _is_filtered_result_url(h2, exclude_domains=["qwant.com"]) and h2 not in seen:
                    seen.add(h2); out.append(h2)
            if out: break
        if not out:
            log_event("qwant BS4: no results (JS-rendered) — enable Selenium for Qwant.")
        return out
    except Exception as e:
        log_event(f"qwant error: {e}"); return []

ENGINE_FUNC_MAP = {
    "bing":       bing_search_links,
    "duckduckgo": duckduckgo_search_links,
    "brave":      brave_search_links,
    "yandex":     yandex_search_links,
    "ask":        ask_search_links,
    "yahoo":      yahoo_search_links,
    "ecosia":     ecosia_search_links,
    "startpage":  startpage_search_links,
    "google":     google_search_links,
    "aol":        aol_search_links,
    "yahoojapan": yahoojapan_search_links,
    "mojeek":     mojeek_search_links,
    "qwant":      qwant_search_links,
}

# ═══════════════════════════════════════════════════════════════════════════════
# SELENIUM ENGINE SCRAPERS
# ═══════════════════════════════════════════════════════════════════════════════
def _driver_get_links(driver, css_selectors, exclude_domains=None,
                      wait_css=None, wait_sec=6):
    """Generic helper: wait for CSS selector then harvest all href links."""
    exclude_domains = exclude_domains or []
    if wait_css:
        try:
            WebDriverWait(driver, wait_sec).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, wait_css))
            )
        except Exception:
            pass
    out, seen = [], set()
    for sel in css_selectors:
        try:
            for el in driver.find_elements(By.CSS_SELECTOR, sel):
                href = el.get_attribute("href") or ""
                if (not _is_filtered_result_url(href, exclude_domains=exclude_domains)
                        and href not in seen):
                    seen.add(href); out.append(href)
        except Exception:
            continue
        if out: break
    return out

def bing_selenium(driver, q, page=0, date_since=None, date_until=None):
    first = page * 10 + 1
    url   = f"https://www.bing.com/search?q={quote_plus(q)}&first={first}&FORM=PERE"
    url   = add_date_to_url(url, "bing", date_since, date_until)
    driver.get(url)
    return _driver_get_links(driver, ["li.b_algo h2 a", "li.b_algo a"],
                             exclude_domains=["bing.com", "microsoft.com"],
                             wait_css="li.b_algo")

def duckduckgo_selenium(driver, q, page=0, date_since=None, date_until=None):
    url = f"https://html.duckduckgo.com/html/?q={quote_plus(q)}"
    url = add_date_to_url(url, "duckduckgo", date_since, date_until)
    driver.get(url)
    for _ in range(page):
        try:
            btn = driver.find_element(
                By.CSS_SELECTOR, "input.btn.btn--alt[type='submit']")
            btn.click(); time.sleep(1.5)
        except Exception: break
    return _driver_get_links(driver, ["a.result__a", "a.result-link"],
                             exclude_domains=["duckduckgo.com"],
                             wait_css="a.result__a")

def brave_selenium(driver, q, page=0, date_since=None, date_until=None):
    url = f"https://search.brave.com/search?q={quote_plus(q)}&offset={page*10}&source=web"
    driver.get(url)
    return _driver_get_links(driver,
                             ["a.result-header", "div.snippet a", "a[href^='https']"],
                             exclude_domains=["brave.com", "search.brave.com"],
                             wait_css="div.snippet", wait_sec=8)

def google_selenium(driver, q, page=0, date_since=None, date_until=None):
    url = f"https://www.google.com/search?q={quote_plus(q)}&start={page*10}&hl=en&num=10"
    url = add_date_to_url(url, "google", date_since, date_until)
    driver.get(url)
    return _driver_get_links(driver,
                             ["div.MjjYud h3 a", "div.g h3 a", "div.yuRUbf a", "a[href^='/url?q=']"],
                             exclude_domains=["google.com", "accounts.google"],
                             wait_css="div.g", wait_sec=8)

def yandex_selenium(driver, q, page=0, date_since=None, date_until=None):
    url = f"https://yandex.com/search/?text={quote_plus(q)}&p={page}"
    driver.get(url)
    return _driver_get_links(driver,
                             ["a.organic__url", "a.Link"],
                             exclude_domains=["yandex.com", "yandex.ru"],
                             wait_css="a.organic__url", wait_sec=7)

def yahoo_selenium(driver, q, page=0, date_since=None, date_until=None):
    url = f"https://search.yahoo.com/search?p={quote_plus(q)}&b={page*10+1}"
    driver.get(url)
    return _driver_get_links(driver,
                             ["h3.title a", "div.compTitle a"],
                             exclude_domains=["yahoo.com"],
                             wait_css="h3.title", wait_sec=6)

def startpage_selenium(driver, q, page=0, date_since=None, date_until=None):
    url = (f"https://www.startpage.com/search?query={quote_plus(q)}"
           f"&startAt={page*10}&language=english")
    driver.get(url)
    return _driver_get_links(driver,
                             ["a.result-link", "a.w-gl__result-url"],
                             exclude_domains=["startpage.com"],
                             wait_css="a.result-link", wait_sec=6)

def ecosia_selenium(driver, q, page=0, date_since=None, date_until=None):
    url = f"https://www.ecosia.org/search?q={quote_plus(q)}&p={page}"
    driver.get(url)
    return _driver_get_links(driver,
                             ["a.result__title", "a.result-title", "article.result a"],
                             exclude_domains=["ecosia.org"],
                             wait_css="article.result", wait_sec=6)

def ask_selenium(driver, q, page=0, date_since=None, date_until=None):
    url = f"https://www.ask.com/web?q={quote_plus(q)}&page={page+1}"
    driver.get(url)
    return _driver_get_links(driver,
                             ["a.result-link", "div.result a[href^='http']"],
                             exclude_domains=["ask.com"],
                             wait_css="div.result", wait_sec=6)

def aol_selenium(driver, q, page=0, date_since=None, date_until=None):
    url = f"https://search.aol.com/aol/search?q={quote_plus(q)}&b={page*10+1}"
    driver.get(url)
    return _driver_get_links(driver,
                             ["div.algo h3 a", "div.dd.algo a", "a.ac-algo"],
                             exclude_domains=["aol.com"],
                             wait_css="div.algo", wait_sec=6)

def yahoojapan_selenium(driver, q, page=0, date_since=None, date_until=None):
    url = f"https://search.yahoo.co.jp/search?p={quote_plus(q)}&b={page*10+1}"
    driver.get(url)
    return _driver_get_links(driver,
                             ["h3.sw-Card__title a", "a.sw-Card__titleLink",
                              "div.sw-Card__content a"],
                             exclude_domains=["yahoo.co.jp"],
                             wait_css="h3.sw-Card__title", wait_sec=7)

def mojeek_selenium(driver, q, page=0, date_since=None, date_until=None):
    url = f"https://www.mojeek.com/search?q={quote_plus(q)}&s={page*10}"
    driver.get(url)
    return _driver_get_links(driver,
                             ["ul.results-standard li a.ob", "ul.results li a.ob", "div.result a.ob", "a.result-link"],
                             exclude_domains=["mojeek.com"],
                             wait_css="ul.results-standard, ul.results", wait_sec=7)

def qwant_selenium(driver, q, page=0, date_since=None, date_until=None):
    url = f"https://www.qwant.com/?q={quote_plus(q)}&t=web&p={page}"
    driver.get(url)
    return _driver_get_links(driver,
                             ["div[data-testid='webResult'] a[data-testid='result-title']",
                              "div[data-testid='webResult'] a",
                              "article[data-testid='webResult'] a",
                              "a[class*='WebResult']"],
                             exclude_domains=["qwant.com"],
                             wait_css="div[data-testid='webResult'], article[data-testid='webResult']",
                             wait_sec=9)

SELENIUM_FUNC_MAP = {
    "bing":       bing_selenium,
    "duckduckgo": duckduckgo_selenium,
    "brave":      brave_selenium,
    "google":     google_selenium,
    "yandex":     yandex_selenium,
    "yahoo":      yahoo_selenium,
    "startpage":  startpage_selenium,
    "ecosia":     ecosia_selenium,
    "ask":        ask_selenium,
    "aol":        aol_selenium,
    "yahoojapan": yahoojapan_selenium,
    "mojeek":     mojeek_selenium,
    "qwant":      qwant_selenium,
}

# ═══════════════════════════════════════════════════════════════════════════════
# DORK SCANNER
# ═══════════════════════════════════════════════════════════════════════════════
class DorkScanner:
    """Run one dork across selected engines.
    ALL found URLs are saved — no domain filter here.
    Filtering is done at export time via ResultStore.
    CAPTCHA detection runs on Selenium path when enabled.
    """
    def __init__(self, dork, engines, pages=1, headers_pool=None,
                 use_proxies=False, proxy_protocols=None,
                 proxy_require_https=True,
                 proxy_min_https_checks=1,
                 per_request_delay=(1, 2), memory_limit_mb=None,
                 date_since=None, date_until=None,
                 selenium_enabled=False, selenium_browser="chrome",
                 selenium_headless=True, proxy_dict=None,
                 selenium_delay=(2, 4),
                 captcha_enabled=False, captcha_mode="manual",
                 captcha_api_key="", captcha_max_wait=60,
                 captcha_retry_delay=10, captcha_auto_visible=True,
                 bs4_only=False, bs4_workers=20,
                 app_ref=None, proxy_rotation_cb=None):
        self.dork               = dork
        self.engines            = engines
        self.pages              = pages
        self.headers_pool       = headers_pool or DEFAULT_USER_AGENTS
        self.use_proxies        = use_proxies
        self.proxy_protocols    = proxy_protocols or []
        self.proxy_require_https = bool(proxy_require_https)
        self.proxy_min_https_checks = max(0, int(proxy_min_https_checks or 0))
        self.per_request_delay  = per_request_delay
        self.memory_limit_mb    = memory_limit_mb
        self.date_since         = date_since
        self.date_until         = date_until
        self.selenium_enabled   = selenium_enabled and not bs4_only
        self.selenium_browser   = selenium_browser
        self.selenium_headless  = selenium_headless
        self.proxy_dict         = proxy_dict
        self.selenium_delay     = selenium_delay
        self.captcha_enabled    = captcha_enabled
        self.captcha_mode       = captcha_mode
        self.captcha_api_key    = captcha_api_key
        self.captcha_max_wait   = captcha_max_wait
        self.captcha_retry_delay= captcha_retry_delay
        self.captcha_auto_visible = captcha_auto_visible
        self.bs4_only           = bs4_only
        self.bs4_workers        = max(1, bs4_workers)
        self.app_ref            = app_ref
        self.proxy_rotation_cb  = proxy_rotation_cb
        # Per-instance set kept for fast local check; global set catches cross-instance dupes
        self.unique             = set()
        # DorkScanner no longer accumulates results/vuln lists — all state in result_store

    def _pick_proxy(self, log_prefix):
        """Pick proxy with HTTPS-first preference, then fallback to any alive."""
        protocols = self.proxy_protocols or None
        # Optional strict mode: only use HTTPS-validated proxies.
        if self.proxy_require_https:
            pr = proxy_manager.get_random_proxy_gated(
                protocols=protocols, require_https=True,
                min_https_checks=self.proxy_min_https_checks)
            if pr:
                proxy_str = list(pr.values())[0]
                log_event(f"{log_prefix} proxy: {proxy_str}")
                if self.proxy_rotation_cb:
                    self.proxy_rotation_cb(proxy_str, "attempt")
                return pr, proxy_str
            log_event(
                f"{log_prefix} WARNING: no HTTPS-validated proxy available — "
                f"using real IP.")
            return None, None

        pr = proxy_manager.get_random_proxy_gated(
            protocols=protocols, require_https=False,
            min_https_checks=self.proxy_min_https_checks)
        if pr:
            proxy_str = list(pr.values())[0]
            log_event(f"{log_prefix} proxy(any-alive): {proxy_str}")
            if self.proxy_rotation_cb:
                self.proxy_rotation_cb(proxy_str, "attempt")
            return pr, proxy_str

        log_event(f"{log_prefix} WARNING: no alive proxy — using real IP.")
        return None, None

    def _proxy_looks_bad_now(self, proxy_str):
        """Return True if proxy was demoted during the previous request."""
        if not proxy_str:
            return False
        with proxy_manager.lock:
            for p in proxy_manager.proxies:
                if p.get("raw") == proxy_str:
                    if not p.get("alive"):
                        return True
                    if p.get("cooldown_until", 0.0) > time.time():
                        return True
                    return False
        return False

    def _process_url(self, u, eng):
        """Deduplicate (local + global), classify, store, enqueue one URL.
        Returns 1 if this is a new unique URL, 0 if duplicate.
        Callers sum the return value instead of calling result_store.count() twice.

        Fix #10: _global_seen_urls grows unboundedly during long scans.
        When it exceeds 500 000 entries, we rebuild it from the DB so that
        the set size stays proportional to the actual number of unique URLs
        rather than accumulating across failed/retried dorks indefinitely.

        Fix: the rebuild is done *outside* the lock (DB iteration can be slow
        at 500k rows) and only swapped in under a brief lock acquisition so
        other threads are not serialised for the full rebuild duration.
        """
        _GLOBAL_SEEN_PRUNE_THRESHOLD = 500_000

        if u in self.unique:
            return 0
        self.unique.add(u)

        # Fast path — check under lock, bail early if already seen.
        with _global_seen_urls_lock:
            needs_rebuild = len(_global_seen_urls) >= _GLOBAL_SEEN_PRUNE_THRESHOLD
            if not needs_rebuild and u in _global_seen_urls:
                return 0

        if needs_rebuild:
            # Rebuild into a *local* set outside the lock so we don't hold
            # _global_seen_urls_lock while iterating the DB (which can be
            # slow and would serialise every other concurrent _process_url).
            new_set = set()
            for row in result_store.iter_results():
                new_set.add(row["url"])
            with _global_seen_urls_lock:
                _global_seen_urls.clear()
                _global_seen_urls.update(new_set)
                already_seen = u in _global_seen_urls
                if not already_seen:
                    _global_seen_urls.add(u)
            log_event(
                f"[dedup] _global_seen_urls pruned and rebuilt from DB "
                f"({len(_global_seen_urls)} entries).")
            if already_seen:
                return 0
        else:
            with _global_seen_urls_lock:
                # Re-check inside lock in case another thread added u between
                # our fast-path check and now.
                if u in _global_seen_urls:
                    return 0
                _global_seen_urls.add(u)

        meta    = {"url": u, "dork": self.dork, "engine": eng,
                   "timestamp": datetime.now(UTC).isoformat()}
        is_vuln = any(p.search(u) for p in COMPILED_VULN_PATTERNS)
        inserted = result_store.add(meta, is_vuln=is_vuln)
        if not inserted:
            return 0
        if is_vuln:
            meta["is_vuln"] = True
        try:
            result_queue.put_nowait(meta)
        except Exception:
            try:
                result_queue.put(meta, timeout=0.1)
            except Exception:
                pass
        return 1

    def run(self):
        """Run one dork across all selected engines.

        Two execution paths:
        - BS4-only mode: all (engine, page) combos are dispatched concurrently
          into a ThreadPoolExecutor(max_workers=self.bs4_workers).  Each worker
          makes one requests/BS4 scrape and returns its URL list.  No Selenium
          driver is opened at all.
        - Normal mode (original behaviour): engines are iterated sequentially;
          Selenium is used for engines in SELENIUM_FUNC_MAP when enabled, with
          the requests/BS4 fallback for the rest.
        """
        results_count = 0
        raw_found     = 0   # Bug 2 fix: pre-dedup total

        # ── Helper: one BS4 scrape for (eng, pg) ─────────────────────────────

        # Engines where 0 results on a deep page is expected/normal and a
        # content-based proxy retry would just waste time and a proxy slot.
        # Ask serves intentional JS shells on pages ≥ 5 (progressive bot defence);
        # Mojeek has a small index and genuinely exhausts results fast.
        # The threshold is (engine, min_page_where_empty_is_normal).
        _DEEP_PAGE_EMPTY_EXPECTED = {
            "ask":    5,   # JS shell defence kicks in around pg 5+
            "mojeek": 2,   # small index; niche dorks run dry fast
        }

        def _bs4_scrape(eng, pg):
            """Called from thread-pool workers in BS4-only mode."""
            if not SCAN_RUNNING:
                return eng, pg, []
            while SCAN_PAUSED:
                time.sleep(0.2)
            headers   = headers_with_ua(self.headers_pool)
            proxies   = None
            proxy_str = None
            if self.use_proxies:
                proxies, proxy_str = self._pick_proxy(f"[BS4/{eng}]")
            fn    = ENGINE_FUNC_MAP.get(eng)
            found = []
            if fn:
                try:
                    found = fn(self.dork, page=pg,
                               headers=headers, proxies=proxies,
                               date_since=self.date_since,
                               date_until=self.date_until)

                    # ── Retry 1: proxy was demoted during request (existing logic)
                    if (self.use_proxies and proxy_str and not found
                            and self._proxy_looks_bad_now(proxy_str)):
                        proxies2, proxy_str2 = self._pick_proxy(
                            f"[BS4/{eng}] retry(demoted)")
                        if proxies2 and proxy_str2 != proxy_str:
                            found = fn(self.dork, page=pg,
                                       headers=headers, proxies=proxies2,
                                       date_since=self.date_since,
                                       date_until=self.date_until)
                            if proxy_str2 and self.proxy_rotation_cb and found:
                                self.proxy_rotation_cb(proxy_str2, "success")

                    # ── Retry 2: content-based retry (Fix A)
                    # Proxy is still alive (returned HTTP 200) but scraper got 0
                    # results — the site served a consent wall, JS shell, or
                    # IP-gated empty page to this specific proxy IP.
                    # Rotating to a fresh IP gives Ask/Ecosia a second chance.
                    # Skip this retry for:
                    #   - engines where deep-page empty is expected (Ask pg≥5,
                    #     Mojeek pg≥2) — no proxy rotation will help there (Fix B)
                    #   - engines already excluded from BS4-only (selenium-only)
                    #   - when proxies are not in use
                    elif (self.use_proxies and proxy_str and not found
                            and not self._proxy_looks_bad_now(proxy_str)):
                        _empty_ok_from = _DEEP_PAGE_EMPTY_EXPECTED.get(eng, None)
                        _skip_content_retry = (
                            _empty_ok_from is not None and pg >= _empty_ok_from
                        )
                        if not _skip_content_retry:
                            proxies2, proxy_str2 = self._pick_proxy(
                                f"[BS4/{eng}] retry(content-empty)")
                            if proxies2 and proxy_str2 != proxy_str:
                                log_event(
                                    f"[BS4/{eng}] pg{pg}: 0 results on live proxy "
                                    f"— retrying with fresh IP")
                                found = fn(self.dork, page=pg,
                                           headers=headers_with_ua(self.headers_pool),
                                           proxies=proxies2,
                                           date_since=self.date_since,
                                           date_until=self.date_until)
                                if proxy_str2 and self.proxy_rotation_cb and found:
                                    self.proxy_rotation_cb(proxy_str2, "success")
                        else:
                            log_event(
                                f"[BS4/{eng}] pg{pg}: 0 results — deep-page "
                                f"empty expected, skipping content retry")

                    if proxy_str and self.proxy_rotation_cb:
                        self.proxy_rotation_cb(proxy_str, "success")
                    log_event(f"[BS4/{eng}] pg{pg}: {len(found)} links")
                except Exception as e:
                    log_event(f"[BS4/{eng}] pg{pg} error: {e}")
            # Per-worker delay (randomised so workers don't all fire at once)
            if self.per_request_delay:
                time.sleep(random.uniform(*self.per_request_delay))
            return eng, pg, found

        # ── BS4-only fast path ────────────────────────────────────────────────
        if self.bs4_only:
            # Bug fix: exclude selenium-only engines (qwant, google) — they
            # always return [] through BS4, wasting workers and hitting rate limits.
            bs4_engines = [e for e in self.engines
                           if e not in _SELENIUM_ONLY_ENGINES]
            skipped_sel = [e for e in self.engines
                           if e in _SELENIUM_ONLY_ENGINES]
            if skipped_sel:
                log_event(
                    f"[BS4-ONLY] skipping selenium-only engines "
                    f"{skipped_sel} — enable Selenium for these.")
            log_event(
                f"[BS4-ONLY] dork='{self.dork}' "
                f"engines={len(bs4_engines)} (of {len(self.engines)} selected) "
                f"pages={self.pages} workers={self.bs4_workers}")
            tasks = [(eng, pg)
                     for eng in bs4_engines
                     for pg  in range(self.pages)]
            if not tasks:
                log_event(f"[BS4-ONLY] no eligible engines for '{self.dork}'")
                return 0, 0
            with ThreadPoolExecutor(
                    max_workers=min(self.bs4_workers, len(tasks)),
                    thread_name_prefix="bs4-worker") as pool:
                futs = {pool.submit(_bs4_scrape, eng, pg): (eng, pg)
                        for eng, pg in tasks}
                for fut in as_completed(futs):
                    if not SCAN_RUNNING:
                        for f in futs:
                            if not f.done():
                                f.cancel()
                        break
                    try:
                        eng, pg, found = fut.result()
                    except Exception as e:
                        eng, pg = futs[fut]
                        log_event(f"[BS4-ONLY] worker error ({eng} pg{pg}): {e}")
                        continue
                    raw_found += len(found)
                    # Bug fix: use _process_url return value (1=new, 0=dupe)
                    # instead of calling result_store.count() twice per future
                    # (that was serialising 200 workers through a DB lock).
                    for u in found:
                        results_count += self._process_url(u, eng)
                    # Memory guard
                    if psutil and self.memory_limit_mb:
                        t0 = time.time()
                        while (psutil.virtual_memory().available / (1024 * 1024)
                               < self.memory_limit_mb):
                            if time.time() - t0 > 60:
                                log_event("Memory limit hit — stopping BS4 pool.")
                                _set_scan_running(False)
                                break
                            time.sleep(1)
            log_event(
                f"[BS4-ONLY] dork '{self.dork}' done — "
                f"{results_count} new URLs ({raw_found} raw).")
            return results_count, raw_found

        # ── Normal path (Selenium + sequential BS4 fallback) ─────────────────
        driver = None
        if self.selenium_enabled and SELENIUM_AVAILABLE:
            try:
                driver = _make_driver(
                    browser=self.selenium_browser,
                    headless=self.selenium_headless,
                    proxy_dict=self.proxy_dict,
                )
                log_event(
                    f"Selenium {self.selenium_browser} driver started "
                    f"({'headless' if self.selenium_headless else 'visible'}).")
            except Exception as e:
                log_event(f"Selenium driver failed ({e}); falling back to requests.")
                driver = None

        try:
            for eng in self.engines:
                if not SCAN_RUNNING: break
                for pg in range(self.pages):
                    if not SCAN_RUNNING: break
                    while SCAN_PAUSED: time.sleep(0.2)

                    found = []
                    sel_proxy_str = (self.proxy_dict.get("http", "") if self.proxy_dict else "")
                    if driver and eng in SELENIUM_FUNC_MAP:
                        # ── Selenium path ──────────────────────────────────
                        try:
                            fn    = SELENIUM_FUNC_MAP[eng]
                            found = fn(driver, self.dork, page=pg,
                                       date_since=self.date_since,
                                       date_until=self.date_until)
                            if sel_proxy_str and self.proxy_rotation_cb:
                                self.proxy_rotation_cb(sel_proxy_str, "success")
                            # CAPTCHA detection
                            if self.captcha_enabled and not found:
                                ct = _detect_captcha(driver)
                                if ct:
                                    # BUG 10 fix: if auto_visible and currently headless,
                                    # quit and relaunch as visible for manual CAPTCHA solve.
                                    if self.captcha_auto_visible and self.selenium_headless:
                                        log_event(
                                            f"CAPTCHA on {eng}: relaunching browser "
                                            f"as visible for manual solve.")
                                        try:
                                            driver.quit()
                                        except Exception:
                                            pass
                                        try:
                                            driver = _make_driver(
                                                browser=self.selenium_browser,
                                                headless=False,
                                                proxy_dict=self.proxy_dict,
                                            )
                                            # Fix C: capture the result of the relaunch
                                            # scrape and use it; old code discarded it.
                                            found = fn(driver, self.dork, page=pg,
                                                       date_since=self.date_since,
                                                       date_until=self.date_until)
                                        except Exception as e_relaunch:
                                            log_event(
                                                f"Relaunch as visible failed: {e_relaunch}")
                                    # Fix C: guard against driver being None after a
                                    # failed relaunch before passing to handle_captcha.
                                    if driver:
                                        handle_captcha(
                                            driver, ct, eng, self.app_ref,
                                            mode=self.captcha_mode,
                                            api_key=self.captcha_api_key,
                                            max_wait=self.captcha_max_wait,
                                            retry_delay=self.captcha_retry_delay,
                                            auto_visible=self.captcha_auto_visible,
                                        )
                                        # Retry once after CAPTCHA handled
                                        try:
                                            found = fn(driver, self.dork, page=pg,
                                                       date_since=self.date_since,
                                                       date_until=self.date_until)
                                        except Exception as e2:
                                            log_event(f"Selenium {eng} retry error: {e2}")
                            log_event(f"[SEL/{eng}] pg{pg}: {len(found)} links scraped")
                        except Exception as e:
                            log_event(f"Selenium {eng} error: {e}")
                            found = []
                        # Selenium-specific delay
                        if self.selenium_delay:
                            time.sleep(random.uniform(*self.selenium_delay))
                    else:
                        # ── Requests / BS4 path ───────────────────────────
                        headers = headers_with_ua(self.headers_pool)
                        proxies = None
                        proxy_str = None
                        if self.use_proxies:
                            proxies, proxy_str = self._pick_proxy("[BS4]")
                        fn = ENGINE_FUNC_MAP.get(eng)
                        # Bug 7 fix: initialise found before the if-block so
                        # an unknown engine name never causes UnboundLocalError.
                        found = []
                        if fn:
                            try:
                                found = fn(self.dork, page=pg,
                                           headers=headers, proxies=proxies,
                                           date_since=self.date_since,
                                           date_until=self.date_until)
                                if (self.use_proxies and proxy_str and not found
                                        and self._proxy_looks_bad_now(proxy_str)):
                                    proxies2, proxy_str2 = self._pick_proxy(f"[{eng}] retry")
                                    if proxies2 and proxy_str2 != proxy_str:
                                        found = fn(self.dork, page=pg,
                                                   headers=headers, proxies=proxies2,
                                                   date_since=self.date_since,
                                                   date_until=self.date_until)
                                        if proxy_str2 and self.proxy_rotation_cb and found:
                                            self.proxy_rotation_cb(proxy_str2, "success")
                                if proxy_str and self.proxy_rotation_cb:
                                    self.proxy_rotation_cb(proxy_str, "success")
                            except Exception as e:
                                log_event(f"[{eng}] error: {e}"); found = []
                        # Requests delay
                        if self.per_request_delay:
                            time.sleep(random.uniform(*self.per_request_delay))

                    raw_found  += len(found)
                    for u in found:
                        results_count += self._process_url(u, eng)

                    # Memory guard
                    if psutil and self.memory_limit_mb:
                        t0 = time.time()
                        while (psutil.virtual_memory().available / (1024*1024)
                               < self.memory_limit_mb):
                            if time.time() - t0 > 60:
                                log_event("Memory limit: scan paused > 60s, stopping.")
                                _set_scan_running(False); break
                            time.sleep(1)
                        if not SCAN_RUNNING: break
        finally:
            if driver:
                try: driver.quit()
                except Exception: pass

        log_event(f"Dork [{self.dork}] -> {results_count} new URLs ({raw_found} raw found).")
        return results_count, raw_found   # Bug 2 fix: return tuple

# ═══════════════════════════════════════════════════════════════════════════════
# GUI
# ═══════════════════════════════════════════════════════════════════════════════
class EthicalDorkSuiteApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Ethical Dork Management & Scanner Suite  v5 · 2026")
        self.geometry("1400x860")
        self.minsize(1150, 720)
        self.protocol("WM_DELETE_WINDOW", self.on_exit)

        # ── State vars ────────────────────────────────────────────────────────
        self.scanner_thread  = None
        self.user_agents     = list(DEFAULT_USER_AGENTS)
        self.auth_domains    = []
        self.results_lock    = threading.Lock()
        self.MAX_LOG_LINES   = 2000
        self._failed_domains  = []
        self._proxy_rotations = 0          # proxy pick attempts
        self._proxy_rot_success = 0        # attempts that completed request path
        self._last_port_host  = ""
        self._last_open_ports = []   # [port, ...] list from last port scan
        self._dns_resolved    = []   # [(domain, ip), ...] from last DNS run
        self._dns_failed      = []   # [domain, ...] from last DNS run
        self._is_closing      = False

        # Scan controls
        self.ua_rotate       = tk.BooleanVar(value=True)
        self.use_proxies     = tk.BooleanVar(value=False)
        self.proxy_protocols = {k: tk.BooleanVar(value=(k in ("http", "https")))
                                for k in ("http", "https", "socks4", "socks5")}
        self.proxy_mode      = tk.StringVar(
            value=("validated_https"
                   if APP_SETTINGS.get("proxy_require_https", True)
                   else "any_alive"))
        self.proxy_min_https_checks = tk.IntVar(
            value=int(APP_SETTINGS.get("proxy_min_https_checks", 1)))
        _def_eng = set(APP_SETTINGS.get("engines", ["bing", "duckduckgo"]))
        self.selected_engines = {e: tk.BooleanVar(value=(e in _def_eng))
                                 for e in BS_ENGINES}
        self.use_multi_engine = tk.BooleanVar(value=True)
        self.pages_per_engine = tk.IntVar(value=1)
        self.min_delay        = tk.DoubleVar(value=APP_SETTINGS.get("delay_min", 1.0))
        self.max_delay        = tk.DoubleVar(value=APP_SETTINGS.get("delay_max", 2.0))
        self.memory_limit_mb  = tk.IntVar(value=APP_SETTINGS.get("max_memory_mb", 250))
        self.multi_thread     = tk.BooleanVar(value=False)
        self.num_threads      = tk.IntVar(value=2)
        self.thread_cap       = tk.IntVar(value=APP_SETTINGS.get("thread_cap", 8))
        self.auto_save        = tk.BooleanVar(value=False)

        # BS4 Engine Mode
        self.bs4_only         = tk.BooleanVar(value=False)
        self.bs4_workers      = tk.IntVar(value=20)
        self.bs4_high_throughput = tk.BooleanVar(value=False)

        # Date filter
        self.recent_date = tk.BooleanVar(value=False)
        cur_year         = datetime.now().year
        self.years       = list(range(1990, cur_year + 1))[::-1]
        self.from_year   = tk.StringVar()
        self.to_year     = tk.StringVar(value=str(cur_year))

        # Selenium controls
        self.selenium_enabled  = tk.BooleanVar(value=False)
        self.selenium_headless = tk.BooleanVar(value=True)
        # Fix #8: single StringVar for browser selection (was a dict of BooleanVars
        # that allowed multiple browsers to appear checked simultaneously, but only
        # the first was ever used).
        self.selenium_browser_var = tk.StringVar(value="chrome")
        self.sel_delay_min     = tk.DoubleVar(
            value=APP_SETTINGS.get("selenium_delay_min", 2.0))
        self.sel_delay_max     = tk.DoubleVar(
            value=APP_SETTINGS.get("selenium_delay_max", 4.0))

        # CAPTCHA controls
        self.captcha_enabled      = tk.BooleanVar(
            value=APP_SETTINGS.get("captcha_detection", True))
        self.captcha_mode         = tk.StringVar(
            value=APP_SETTINGS.get("captcha_mode", "manual"))
        self.captcha_api_key      = tk.StringVar(value="")
        self.captcha_max_wait     = tk.IntVar(
            value=APP_SETTINGS.get("captcha_max_wait", 60))
        self.captcha_retry_delay  = tk.IntVar(
            value=APP_SETTINGS.get("captcha_retry_delay", 10))
        self.captcha_auto_visible = tk.BooleanVar(
            value=APP_SETTINGS.get("captcha_auto_visible", True))

        # Port scanner
        self.port_mode    = tk.StringVar(value="fixed")
        self.fixed_ports  = tk.StringVar(value="21,22,80,443,8080,3389")
        self.num_random   = tk.IntVar(value=100)
        self.target_host  = tk.StringVar()
        self.port_timeout = tk.DoubleVar(
            value=APP_SETTINGS.get("port_timeout", 1.0))

        # Domain-to-IP concurrency
        self.domain_ip_workers = tk.IntVar(value=20)
        self.normalize_domains = tk.BooleanVar(value=True)

        # Proxy manager filter
        self.pm_status_filter = tk.StringVar(value="all")
        self.pm_proto_filter  = {k: tk.BooleanVar(value=(k == "all"))
                                 for k in ("all", "http", "https", "socks4", "socks5")}

        # Separate protocol selector for SCRAPING (independent from table filter)
        # Bug fix: scrape reads its own vars, not the scanner's proxy_protocols
        self.pm_scrape_protos = {k: tk.BooleanVar(value=(k in ("http", "https")))
                                 for k in ("http", "https", "socks4", "socks5")}

        # Proxy validation thread count (exposed in Proxy Manager tab)
        self.proxy_validate_workers = tk.IntVar(value=30)

        # Stop events for scrape and validation (Bug 3 fix)
        self._proxy_scrape_stop   = threading.Event()
        self._proxy_validate_stop = threading.Event()

        self.build_ui()
        self.after(200, self._process_queues)

    # ═══════════════════════════════════════════════════════════════════════════
    # build_ui
    # ═══════════════════════════════════════════════════════════════════════════
    def build_ui(self):
        style = ttk.Style()
        try: style.theme_use("clam")
        except Exception: pass
        style.configure("Accent.TButton",  foreground="white",
                         background="#2563eb", font=("TkDefaultFont", 9, "bold"))
        style.configure("Danger.TButton",  foreground="white",
                         background="#dc2626", font=("TkDefaultFont", 9, "bold"))
        style.configure("Success.TButton", foreground="white",
                         background="#16a34a", font=("TkDefaultFont", 9, "bold"))

        nb = ttk.Notebook(self)
        nb.pack(fill="both", expand=True)

        self._build_scanner_tab(nb)
        self._build_proxy_tab(nb)
        self._build_dork_tools_tab(nb)
        self._build_stats_tab(nb)
        self._build_port_scanner_tab(nb)
        self._build_domain_ip_tab(nb)

        ttk.Label(self,
            text="⚠ For authorized security testing ONLY  |  "
                 "Audit log: data/audit_log.txt  |  Exports: data/exports/",
            foreground="#666", font=("TkDefaultFont", 8)
        ).pack(side="bottom", fill="x", padx=8, pady=2)

    # ── Mousewheel / scrollable helpers ───────────────────────────────────────
    def _bind_mousewheel(self, canvas):
        # BUG 34 fix: use enter/leave events to bind mousewheel only while the
        # cursor is inside this canvas, not app-wide via bind_all.
        def _on_enter(event):
            def _scroll(e):
                if e.num == 4 or e.delta > 0:
                    canvas.yview_scroll(-1, "units")
                else:
                    canvas.yview_scroll(1, "units")
            canvas._mw_handler = _scroll
            canvas.bind("<MouseWheel>", _scroll)
            canvas.bind("<Button-4>",   _scroll)
            canvas.bind("<Button-5>",   _scroll)

        def _on_leave(event):
            canvas.unbind("<MouseWheel>")
            canvas.unbind("<Button-4>")
            canvas.unbind("<Button-5>")

        canvas.bind("<Enter>", _on_enter)
        canvas.bind("<Leave>", _on_leave)

    def _scrollable_tab(self, parent):
        canvas = tk.Canvas(parent, highlightthickness=0)
        vsb    = ttk.Scrollbar(parent, orient="vertical", command=canvas.yview)
        frame  = ttk.Frame(canvas)
        frame.bind("<Configure>",
                   lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=frame, anchor="nw")
        canvas.configure(yscrollcommand=vsb.set)
        canvas.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")
        self._bind_mousewheel(canvas)
        return canvas, frame

    # ═══════════════════════════════════════════════════════════════════════════
    # MAIN SCANNER TAB
    # ═══════════════════════════════════════════════════════════════════════════
    def _build_scanner_tab(self, nb):
        tab = ttk.Frame(nb)
        nb.add(tab, text="🔍 Main Scanner")

        pane = ttk.PanedWindow(tab, orient="horizontal")
        pane.pack(fill="both", expand=True)

        # ── LEFT: scrollable controls ──
        left_outer = ttk.Frame(pane)
        pane.add(left_outer, weight=0)
        can, left = self._scrollable_tab(left_outer)
        can.configure(width=390)

        # Dork Input
        df = ttk.LabelFrame(left, text="🎯 Dork Input", padding=6)
        df.pack(fill="x", padx=6, pady=4)
        self.dork_text = scrolledtext.ScrolledText(
            df, width=46, height=10, font=("Courier", 9))
        self.dork_text.pack(fill="x")
        r = ttk.Frame(df); r.pack(fill="x", pady=(4, 0))
        ttk.Button(r, text="📂 Load dorks.txt",
                   command=self.load_dorks_file).pack(side="left", padx=2)
        ttk.Button(r, text="✖ Clear",
                   command=lambda: self.dork_text.delete(1.0, tk.END)).pack(side="left", padx=2)

        # Engines — dynamic wrap, 13 engines
        ef = ttk.LabelFrame(left, text="🌐 Search Engines", padding=6)
        ef.pack(fill="x", padx=6, pady=4)
        eng_wrap = ttk.Frame(ef)
        eng_wrap.pack(fill="x", anchor="w")
        # Build chips in rows of 5
        _row = None
        for i, e in enumerate(BS_ENGINES):
            if i % 5 == 0:
                _row = ttk.Frame(eng_wrap); _row.pack(anchor="w")
            lbl = e if e not in ("yahoojapan", "aol", "mojeek", "qwant") else {
                "yahoojapan": "Yahoo JP", "aol": "AOL",
                "mojeek": "Mojeek", "qwant": "Qwant"
            }[e]
            ttk.Checkbutton(_row, text=lbl,
                            variable=self.selected_engines[e]).pack(side="left", padx=2)
        ef2 = ttk.Frame(ef); ef2.pack(fill="x", pady=(4, 0))
        ttk.Checkbutton(ef2, text="Use all selected simultaneously",
                        variable=self.use_multi_engine).pack(side="left")
        ttk.Label(ef2, text="Pages/engine:").pack(side="left", padx=(12, 2))
        ttk.Spinbox(ef2, from_=1, to=10,
                    textvariable=self.pages_per_engine, width=4).pack(side="left")

        # ── BS4 Engine Mode ───────────────────────────────────────────────────
        bs4f = ttk.LabelFrame(left, text="🟢 BS4 Engine Mode", padding=6)
        bs4f.pack(fill="x", padx=6, pady=4)

        bs4r1 = ttk.Frame(bs4f); bs4r1.pack(fill="x")
        ttk.Checkbutton(bs4r1, text="BS4-only mode (no Selenium)",
                        variable=self.bs4_only,
                        command=self._on_bs4_mode_change).pack(side="left")
        ttk.Label(bs4r1,
                  text="Forces all engines to requests/BS4 path, disables Selenium",
                  font=("TkDefaultFont", 8), foreground="#888").pack(
                      side="left", padx=6)

        bs4r2 = ttk.Frame(bs4f); bs4r2.pack(fill="x", pady=(4, 0))
        ttk.Label(bs4r2, text="BS4 workers:").pack(side="left")
        self.bs4_workers_spin = ttk.Spinbox(
            bs4r2, from_=1, to=600, increment=10,
            textvariable=self.bs4_workers, width=5)
        self.bs4_workers_spin.pack(side="left", padx=4)
        ttk.Label(bs4r2, text="(max 600 — each worker runs one engine+page concurrently)",
                  font=("TkDefaultFont", 8), foreground="#888").pack(side="left")

        bs4r3 = ttk.Frame(bs4f); bs4r3.pack(fill="x", pady=(4, 0))
        ttk.Checkbutton(bs4r3, text="High-throughput (auto 200 workers, minimal delay)",
                        variable=self.bs4_high_throughput,
                        command=self._on_bs4_htp_change).pack(side="left")

        ttk.Label(bs4f,
                  text="Tip: BS4-only mode is fastest for engines that don't need JS "
                       "(Bing, DDG, Yahoo, Ask, Yandex, Ecosia, AOL, Yahoo JP, Mojeek).\n"
                       "Selenium-required engines (Qwant, Google) are still used via Selenium "
                       "unless BS4-only forces them to BS4 fallback.",
                  font=("TkDefaultFont", 8), foreground="#666",
                  wraplength=360, justify="left").pack(anchor="w", pady=(4, 0))

        # Threading & Delays (combined)
        thf = ttk.LabelFrame(left, text="⚡ Threading & Delays", padding=6)
        thf.pack(fill="x", padx=6, pady=4)
        r = ttk.Frame(thf); r.pack(fill="x")
        ttk.Checkbutton(r, text="Multi-thread",
                        variable=self.multi_thread).pack(side="left")
        ttk.Label(r, text="Workers:").pack(side="left", padx=(10, 2))
        ttk.Spinbox(r, from_=1, to=20,
                    textvariable=self.num_threads, width=4).pack(side="left")
        ttk.Label(r, text="Cap:").pack(side="left", padx=(8, 2))
        ttk.Spinbox(r, from_=1, to=32,
                    textvariable=self.thread_cap, width=4).pack(side="left")
        r2 = ttk.Frame(thf); r2.pack(fill="x", pady=(4, 0))
        ttk.Label(r2, text="Request delay min:").pack(side="left")
        ttk.Spinbox(r2, from_=0.1, to=60, increment=0.1,
                    textvariable=self.min_delay, width=5).pack(side="left", padx=2)
        ttk.Label(r2, text="max:").pack(side="left")
        ttk.Spinbox(r2, from_=0.1, to=60, increment=0.1,
                    textvariable=self.max_delay, width=5).pack(side="left", padx=2)

        # Date filter
        datef = ttk.LabelFrame(left, text="📅 Date Filter", padding=6)
        datef.pack(fill="x", padx=6, pady=4)
        r = ttk.Frame(datef); r.pack(fill="x")
        ttk.Checkbutton(r, text="Recent (last 12 months)",
                        variable=self.recent_date).pack(side="left")
        r2 = ttk.Frame(datef); r2.pack(fill="x", pady=(4, 0))
        ttk.Label(r2, text="From:").pack(side="left")
        self.from_year_combo = ttk.Combobox(
            r2, textvariable=self.from_year, values=self.years, width=6)
        self.from_year_combo.pack(side="left", padx=2)
        ttk.Label(r2, text="To:").pack(side="left", padx=(8, 0))
        self.to_year_combo = ttk.Combobox(
            r2, textvariable=self.to_year, values=self.years, width=6)
        self.to_year_combo.pack(side="left", padx=2)

        # Proxy & User-Agent — redesigned with live pool summary
        pf = ttk.LabelFrame(left, text="🛡️ Proxy & User-Agent", padding=6)
        pf.pack(fill="x", padx=6, pady=4)
        ttk.Checkbutton(pf, text="Route requests through proxy",
                        variable=self.use_proxies).pack(anchor="w")

        # Pool summary box
        pool_box = ttk.Frame(pf, relief="sunken", borderwidth=1)
        pool_box.pack(fill="x", pady=(4, 2))
        self.lbl_pool_alive    = ttk.Label(pool_box, text="Alive: 0",
                                           foreground="#16a34a",
                                           font=("TkDefaultFont", 8, "bold"))
        self.lbl_pool_alive.grid(row=0, column=0, padx=6, pady=2, sticky="w")
        self.lbl_pool_alive_total = ttk.Label(
            pool_box, text="Total alive(all): 0",
            foreground="#0f766e",
            font=("TkDefaultFont", 8))
        self.lbl_pool_alive_total.grid(row=0, column=1, padx=6, pady=2, sticky="w")
        self.lbl_pool_dead     = ttk.Label(pool_box, text="Dead: 0",
                                           foreground="#dc2626",
                                           font=("TkDefaultFont", 8))
        self.lbl_pool_dead.grid(row=0, column=2, padx=6, pady=2, sticky="w")
        self.lbl_pool_untested = ttk.Label(pool_box, text="Untested: 0",
                                           foreground="#888",
                                           font=("TkDefaultFont", 8))
        self.lbl_pool_untested.grid(row=0, column=3, padx=6, pady=2, sticky="w")
        self.lbl_pool_protocols = ttk.Label(pool_box,
                                             text="http(0) https(0) socks4(0) socks5(0)",
                                             foreground="#555",
                                             font=("TkDefaultFont", 8))
        self.lbl_pool_protocols.grid(row=1, column=0, columnspan=4,
                                     padx=6, pady=(0, 2), sticky="w")
        self.lbl_active_proxy  = ttk.Label(pool_box, text="Active: none",
                                            foreground="#7c3aed",
                                            font=("TkDefaultFont", 8))
        self.lbl_active_proxy.grid(row=2, column=0, columnspan=4,
                                   padx=6, pady=(0, 4), sticky="w")

        ttk.Label(pf, text="Protocol filter (unchecked = any alive):",
                  font=("TkDefaultFont", 8), foreground="#555").pack(
                      anchor="w", pady=(4, 0))
        prow = ttk.Frame(pf); prow.pack(anchor="w")
        for p in ("http", "https", "socks4", "socks5"):
            ttk.Checkbutton(prow, text=p.upper(),
                            variable=self.proxy_protocols[p]).pack(
                                side="left", padx=3)
        mode_row = ttk.Frame(pf); mode_row.pack(anchor="w", pady=(3, 0))
        ttk.Label(mode_row, text="Proxy mode:",
                  font=("TkDefaultFont", 8), foreground="#555").pack(side="left")
        ttk.Radiobutton(
            mode_row, text="Use only validated HTTPS", value="validated_https",
            variable=self.proxy_mode).pack(side="left", padx=(6, 3))
        ttk.Radiobutton(
            mode_row, text="Use any alive", value="any_alive",
            variable=self.proxy_mode).pack(side="left", padx=3)
        gate_row = ttk.Frame(pf); gate_row.pack(anchor="w", pady=(2, 0))
        ttk.Label(gate_row, text="Min HTTPS successes:",
                  font=("TkDefaultFont", 8), foreground="#555").pack(side="left")
        ttk.Spinbox(
            gate_row, from_=0, to=20, width=4,
            textvariable=self.proxy_min_https_checks).pack(side="left", padx=4)
        ttk.Checkbutton(pf, text="Rotate User-Agents",
                        variable=self.ua_rotate).pack(anchor="w", pady=(4, 0))
        ttk.Button(pf, text="📂 Load useragents.txt",
                   command=self.load_useragents_file).pack(anchor="w", pady=2)

        # Selenium Controls — new dedicated LabelFrame
        sf = ttk.LabelFrame(left, text="🌐 Selenium Controls", padding=6)
        sf.pack(fill="x", padx=6, pady=4)

        r = ttk.Frame(sf); r.pack(fill="x")
        ttk.Checkbutton(r, text="Enable Selenium",
                        variable=self.selenium_enabled).pack(side="left")
        ttk.Checkbutton(r, text="Headless",
                        variable=self.selenium_headless).pack(side="left", padx=8)

        br = ttk.Frame(sf); br.pack(anchor="w", pady=(2, 0))
        ttk.Label(br, text="Browser:").pack(side="left")
        # Fix #8: use a single StringVar + Radiobuttons so only one browser
        # can be selected at a time. The old Checkbuttons let users tick
        # chrome+firefox+edge simultaneously, but only the first was ever used.
        self.selenium_browser_var = tk.StringVar(value="chrome")
        for b in ("chrome", "firefox", "edge"):
            ttk.Radiobutton(br, text=b.title(),
                            variable=self.selenium_browser_var,
                            value=b).pack(side="left", padx=3)

        ttk.Separator(sf, orient="horizontal").pack(fill="x", pady=4)

        r2 = ttk.Frame(sf); r2.pack(fill="x")
        ttk.Label(r2, text="Selenium delay min:").pack(side="left")
        ttk.Spinbox(r2, from_=0.5, to=30, increment=0.5,
                    textvariable=self.sel_delay_min, width=5).pack(
                        side="left", padx=2)
        ttk.Label(r2, text="max:").pack(side="left")
        ttk.Spinbox(r2, from_=0.5, to=30, increment=0.5,
                    textvariable=self.sel_delay_max, width=5).pack(
                        side="left", padx=2)

        ttk.Separator(sf, orient="horizontal").pack(fill="x", pady=4)

        # CAPTCHA controls
        ttk.Checkbutton(sf, text="Enable CAPTCHA detection",
                        variable=self.captcha_enabled).pack(anchor="w")

        r3 = ttk.Frame(sf); r3.pack(fill="x", pady=(4, 0))
        ttk.Label(r3, text="CAPTCHA mode:").pack(side="left")
        mode_combo = ttk.Combobox(
            r3, textvariable=self.captcha_mode,
            values=["manual", "2captcha", "anticaptcha", "hcaptcha"],
            state="readonly", width=14)
        mode_combo.pack(side="left", padx=4)
        mode_combo.bind("<<ComboboxSelected>>", self._on_captcha_mode_change)

        r4 = ttk.Frame(sf); r4.pack(fill="x", pady=(4, 0))
        ttk.Label(r4, text="API key:").pack(side="left")
        self.captcha_key_entry = ttk.Entry(
            r4, textvariable=self.captcha_api_key, show="•", width=22)
        self.captcha_key_entry.pack(side="left", padx=4)
        self.captcha_key_show = tk.BooleanVar(value=False)
        ttk.Checkbutton(r4, text="Show",
                        variable=self.captcha_key_show,
                        command=self._toggle_captcha_key_vis).pack(side="left")
        self.lbl_key_mem = ttk.Label(r4, text="(in-memory only)",
                                      foreground="#888",
                                      font=("TkDefaultFont", 7))
        self.lbl_key_mem.pack(side="left", padx=4)

        r5 = ttk.Frame(sf); r5.pack(fill="x", pady=(4, 0))
        ttk.Label(r5, text="Retry delay (s):").pack(side="left")
        ttk.Spinbox(r5, from_=5, to=120,
                    textvariable=self.captcha_retry_delay, width=5).pack(
                        side="left", padx=2)
        ttk.Label(r5, text="Max wait (s):").pack(side="left", padx=(8, 2))
        ttk.Spinbox(r5, from_=10, to=300,
                    textvariable=self.captcha_max_wait, width=5).pack(
                        side="left", padx=2)

        ttk.Checkbutton(sf, text="Auto-switch to visible browser on CAPTCHA",
                        variable=self.captcha_auto_visible).pack(
                            anchor="w", pady=(4, 0))

        ttk.Separator(sf, orient="horizontal").pack(fill="x", pady=4)

        ttk.Button(sf, text="🧹 Clear Selenium Profile Data",
                   command=self.clear_selenium_data).pack(anchor="w")
        ttk.Label(sf,
                  text="Tip: disable headless to handle CAPTCHAs manually in browser",
                  font=("TkDefaultFont", 8), foreground="#888").pack(anchor="w")

        # Initial API key state
        self._on_captcha_mode_change()

        # Authorization
        af = ttk.LabelFrame(left, text="🔒 Authorization", padding=6)
        af.pack(fill="x", padx=6, pady=4)
        self.lbl_auth = ttk.Label(
            af, text="Not authorized — required before scan",
            foreground="#dc2626")
        self.lbl_auth.pack(anchor="w")
        ttk.Button(af, text="🔐 Authorize Target Domains",
                   command=self.authorize_domains_dialog,
                   style="Danger.TButton").pack(fill="x", pady=4)
        ttk.Label(af,
                  text="Note: All scraped URLs are saved. Domain filter is applied at export.",
                  font=("TkDefaultFont", 8), foreground="#888",
                  wraplength=340).pack(anchor="w")

        # ── RIGHT: controls + stats + log ──
        right = ttk.Frame(pane)
        pane.add(right, weight=1)

        # Scan control rows
        ctrl = ttk.LabelFrame(right, text="▶ Scan Controls", padding=6)
        ctrl.pack(fill="x", padx=6, pady=4)
        r1 = ttk.Frame(ctrl); r1.pack(fill="x", pady=(0, 4))
        ttk.Button(r1, text="▶ Start Scan",
                   command=self.start_scan,
                   style="Success.TButton").pack(side="left", padx=2)
        ttk.Button(r1, text="⏸ Pause",
                   command=self.pause_scan,
                   style="Accent.TButton").pack(side="left", padx=2)
        ttk.Button(r1, text="⏹ Stop",
                   command=self.stop_scan,
                   style="Danger.TButton").pack(side="left", padx=2)
        ttk.Button(r1, text="🗑 Remove Dupes",
                   command=self.remove_duplicates).pack(side="left", padx=2)
        ttk.Checkbutton(r1, text="Auto-save on finish",
                        variable=self.auto_save).pack(side="left", padx=6)

        r2 = ttk.Frame(ctrl); r2.pack(fill="x")
        ttk.Label(r2, text="Export:",
                  font=("TkDefaultFont", 9, "bold")).pack(side="left")
        ttk.Button(r2, text="All → JSON",
                   command=lambda: self.export_results_dialog(
                       export_all=True, fmt="json")).pack(side="left", padx=2)
        ttk.Button(r2, text="All → TXT",
                   command=lambda: self.export_results_dialog(
                       export_all=True, fmt="txt")).pack(side="left", padx=2)
        ttk.Button(r2, text="Vuln → JSON",
                   command=lambda: self.export_results_dialog(
                       vuln=True, fmt="json")).pack(side="left", padx=2)
        ttk.Button(r2, text="Vuln → TXT",
                   command=lambda: self.export_results_dialog(
                       vuln=True, fmt="txt")).pack(side="left", padx=2)
        ttk.Button(r2, text="By Domain…",
                   command=self.export_by_domain_dialog).pack(side="left", padx=2)
        ttk.Button(r2, text="By Engine…",
                   command=self.export_by_engine_dialog).pack(side="left", padx=2)

        # Progress panel — individual stat cards
        prog = ttk.LabelFrame(right, text="📊 Progress", padding=6)
        prog.pack(fill="x", padx=6, pady=4)

        stats_row = ttk.Frame(prog)
        stats_row.pack(fill="x", pady=(0, 4))

        def _stat_card(parent, label, init="0", fg=None):
            f = ttk.Frame(parent, relief="groove", borderwidth=1)
            f.pack(side="left", padx=3, ipadx=6, ipady=2)
            ttk.Label(f, text=label, font=("TkDefaultFont", 8),
                      foreground="#666").pack()
            lbl = ttk.Label(f, text=init,
                            font=("TkDefaultFont", 12, "bold"),
                            foreground=fg or "")
            lbl.pack()
            return lbl

        self.lbl_dorks_scanned = _stat_card(stats_row, "Dorks", "0/0 (0%)")
        self.lbl_total         = _stat_card(stats_row, "URLs found", "0", "#185FA5")
        self.lbl_unique        = _stat_card(stats_row, "Unique", "0", "#185FA5")
        self.lbl_vuln          = _stat_card(stats_row, "Vuln-like", "0", "#dc2626")
        self.lbl_speed         = _stat_card(stats_row, "Speed", "0/s")
        self.lbl_proxy_rotations = _stat_card(
            stats_row, "Proxy rot (attempt/success)", "0/0", "#7c3aed")

        self.progress_bar = ttk.Progressbar(prog, orient="horizontal",
                                             mode="determinate")
        self.progress_bar.pack(fill="x", padx=4, pady=(2, 4))

        # Per-engine result pills
        eng_row_frame = ttk.Frame(prog)
        eng_row_frame.pack(fill="x")
        ttk.Label(eng_row_frame, text="Per engine:",
                  font=("TkDefaultFont", 8), foreground="#555").pack(
                      side="left", padx=(4, 6))
        # BUG 17 fix: use human-readable display labels, not raw internal keys
        _eng_display = {
            "yahoojapan": "Yahoo JP", "aol": "AOL",
            "mojeek": "Mojeek", "qwant": "Qwant",
        }
        self.engine_pills = {}
        for eng in BS_ENGINES:
            display = _eng_display.get(eng, eng)
            lbl = ttk.Label(eng_row_frame,
                            text=f"{display} 0",
                            font=("TkDefaultFont", 8),
                            foreground="#888",
                            relief="groove", borderwidth=1, padding=(4, 1))
            lbl.pack(side="left", padx=2)
            self.engine_pills[eng] = lbl

        # Live filter
        ff = ttk.Frame(right); ff.pack(fill="x", padx=6, pady=2)
        ttk.Label(ff, text="🔎 Filter:").pack(side="left")
        self.live_filter = tk.StringVar()
        ttk.Entry(ff, textvariable=self.live_filter,
                  width=40).pack(side="left", padx=4)
        ttk.Button(ff, text="Apply",
                   command=self.apply_live_filter).pack(side="left")
        ttk.Button(ff, text="Clear Filter",
                   command=self._clear_live_filter).pack(side="left", padx=2)

        # Live log
        lf = ttk.LabelFrame(right, text="📋 Live Results", padding=4)
        lf.pack(fill="both", expand=True, padx=6, pady=4)
        self.log_box = tk.Text(lf, wrap="none", font=("Courier", 9),
                               background="#0f1923", foreground="#a8d8a8",
                               insertbackground="#fff")
        self.log_box.tag_configure("vuln", foreground="#f87171")
        self.log_box.tag_configure("info", foreground="#93c5fd")
        hsb = ttk.Scrollbar(lf, orient="horizontal", command=self.log_box.xview)
        vsb = ttk.Scrollbar(lf, orient="vertical",   command=self.log_box.yview)
        self.log_box.configure(xscrollcommand=hsb.set, yscrollcommand=vsb.set)
        hsb.pack(side="bottom", fill="x")
        vsb.pack(side="right",  fill="y")
        self.log_box.pack(fill="both", expand=True)

    # ── CAPTCHA mode helper ───────────────────────────────────────────────────
    def _on_captcha_mode_change(self, event=None):
        mode = self.captcha_mode.get()
        needs_key = mode in ("2captcha", "anticaptcha")
        state = "normal" if needs_key else "disabled"
        self.captcha_key_entry.configure(state=state)
        self.lbl_key_mem.configure(
            foreground="#dc2626" if (needs_key and self.captcha_api_key.get()) else "#888")

    def _toggle_captcha_key_vis(self):
        self.captcha_key_entry.configure(
            show="" if self.captcha_key_show.get() else "•")

    def _on_bs4_mode_change(self):
        """When BS4-only is toggled, grey out Selenium controls to make
        the relationship clear — BS4-only forces the requests path for
        every engine regardless of Selenium being installed."""
        if self.bs4_only.get():
            # Disable the Selenium enable checkbox visually
            self.selenium_enabled.set(False)
        # Re-evaluate high-throughput state
        self._on_bs4_htp_change()

    def _on_bs4_htp_change(self):
        """High-throughput preset: set workers to 200 and min delay to 0."""
        if self.bs4_high_throughput.get():
            self.bs4_workers.set(200)
            self.min_delay.set(0.1)
            self.max_delay.set(0.5)
        else:
            # Restore sensible defaults if un-ticked
            if self.bs4_workers.get() == 200:
                self.bs4_workers.set(20)
            if self.min_delay.get() == 0.1:
                self.min_delay.set(1.0)
            if self.max_delay.get() == 0.5:
                self.max_delay.set(2.0)

    # ═══════════════════════════════════════════════════════════════════════════
    # PROXY MANAGER TAB
    # ═══════════════════════════════════════════════════════════════════════════
    def _build_proxy_tab(self, nb):
        tab = ttk.Frame(nb)
        nb.add(tab, text="🛡️ Proxy Manager")

        # ── Load & Scrape ─────────────────────────────────────────────────────
        top = ttk.LabelFrame(tab, text="📂 Load & Scrape", padding=6)
        top.pack(fill="x", padx=6, pady=4)

        # Row 1: Load file + source selector + Scrape + Stop Scrape
        r1 = ttk.Frame(top); r1.pack(fill="x", pady=(0, 4))
        ttk.Button(r1, text="📂 Load proxies.txt",
                   command=self.load_proxies_file).pack(side="left", padx=2)
        ttk.Label(r1, text="Source:").pack(side="left", padx=(8, 2))
        self.proxy_sources = {
            "Proxyscrape": ("https://api.proxyscrape.com/v3/free-proxy-list/get"
                            "?request=getproxies&protocol={proto}&country=all"
                            "&anonymity=all&format=text&timeout=20000"),
            "TheSpeedX":   "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/{proto}.txt",
            "Proxy-list.download": "https://www.proxy-list.download/api/v1/get?type={proto}",
            "Proxifly":    "https://raw.githubusercontent.com/proxifly/free-proxy-list/main/proxies/all/data.txt",
            "Vakhov":      "https://raw.githubusercontent.com/vakhov/fresh-proxy-list/master/{proto}.txt",
            "Monosans":    "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/{proto}.txt",
        }
        self.proxy_source_var = tk.StringVar(value="Proxyscrape")
        ttk.Combobox(r1, textvariable=self.proxy_source_var,
                     values=list(self.proxy_sources.keys()),
                     width=18).pack(side="left", padx=2)
        ttk.Button(r1, text="⬇ Scrape",
                   command=self.scrape_sample_proxies_thread,
                   style="Accent.TButton").pack(side="left", padx=2)
        ttk.Button(r1, text="⏹ Stop Scrape",
                   command=self.stop_scrape,
                   style="Danger.TButton").pack(side="left", padx=2)

        # Row 1b: Scrape protocol selector — dedicated, separate from table filter
        # Bug fix: scrape must know which protocols to fetch, independent of
        # the table display filter. These are the checkboxes the scrape reads.
        rs = ttk.Frame(top); rs.pack(fill="x", pady=(0, 4))
        ttk.Label(rs, text="Scrape protocols:",
                  font=("TkDefaultFont", 9, "bold")).pack(side="left")
        for key in ("http", "https", "socks4", "socks5"):
            ttk.Checkbutton(rs, text=key.upper(),
                            variable=self.pm_scrape_protos[key]).pack(
                                side="left", padx=3)
        ttk.Label(rs, text="← select which protocol types to scrape",
                  foreground="#888", font=("TkDefaultFont", 8)).pack(
                      side="left", padx=6)

        # Row 2: Validate + Stop Validate + Thread count + Refresh + Exports
        r2 = ttk.Frame(top); r2.pack(fill="x")
        ttk.Button(r2, text="✔ Validate All",
                   command=self.validate_proxies_thread,
                   style="Success.TButton").pack(side="left", padx=2)
        ttk.Button(r2, text="⏹ Stop Validate",
                   command=self.stop_validate,
                   style="Danger.TButton").pack(side="left", padx=2)
        ttk.Label(r2, text="Threads:").pack(side="left", padx=(8, 2))
        ttk.Spinbox(r2, from_=1, to=200, textvariable=self.proxy_validate_workers,
                    width=5).pack(side="left", padx=2)
        ttk.Label(r2, text="(1–200)",
                  foreground="#888", font=("TkDefaultFont", 8)).pack(
                      side="left", padx=(0, 6))
        ttk.Button(r2, text="🗑 Clear Proxies",
                   command=self.clear_proxy_manager_data).pack(side="left", padx=2)
        ttk.Button(r2, text="🧽 Clear + Remove File",
                   command=self.clear_proxy_manager_data_and_file).pack(
                       side="left", padx=2)
        ttk.Button(r2, text="🪦 Delete Dead",
                   command=self.delete_dead_proxies).pack(side="left", padx=2)
        ttk.Button(r2, text="🔄 Refresh Table",
                   command=self.refresh_proxy_table).pack(side="left", padx=2)
        ttk.Separator(r2, orient="vertical").pack(side="left", fill="y",
                                                   padx=6, pady=2)
        ttk.Button(r2, text="⬇ Export Filtered → TXT",
                   command=self.export_filtered_proxies).pack(side="left", padx=2)
        ttk.Button(r2, text="⬇ Export Alive → TXT",
                   command=self.export_valid_proxies).pack(side="left", padx=2)

        # Progress bar
        pp = ttk.Frame(tab); pp.pack(fill="x", padx=6, pady=2)
        self.pm_progress_label = ttk.Label(pp, text="Idle")
        self.pm_progress_label.pack(side="left", padx=4)
        self.pm_progress_bar = ttk.Progressbar(
            pp, orient="horizontal", mode="determinate")
        self.pm_progress_bar.pack(side="left", fill="x", expand=True, padx=4)
        self.pm_count_label = ttk.Label(pp, text="0 loaded")
        self.pm_count_label.pack(side="left", padx=4)

        # ── Table Filter ──────────────────────────────────────────────────────
        fbar = ttk.LabelFrame(tab, text="🔍 Table Filter", padding=6)
        fbar.pack(fill="x", padx=6, pady=4)

        # Status filter row
        fr1 = ttk.Frame(fbar); fr1.pack(fill="x")
        ttk.Label(fr1, text="Status:",
                  font=("TkDefaultFont", 9, "bold")).pack(side="left")
        for key, lbl in [("all", "All"), ("alive", "✔ Alive"),
                          ("dead", "✘ Dead"), ("untested", "— Untested")]:
            ttk.Radiobutton(fr1, text=lbl, value=key,
                            variable=self.pm_status_filter,
                            command=self.refresh_proxy_table).pack(
                                side="left", padx=4)

        # Protocol filter row — Bug 1 fix: now uses pm_proto_filter (table display only)
        # These checkboxes filter what the TABLE shows — NOT what gets scraped.
        fr2 = ttk.Frame(fbar); fr2.pack(fill="x", pady=(4, 0))
        ttk.Label(fr2, text="Protocol:",
                  font=("TkDefaultFont", 9, "bold")).pack(side="left")
        # "All" radio-style toggle
        ttk.Checkbutton(fr2, text="ALL",
                        variable=self.pm_proto_filter["all"],
                        command=self._on_pm_proto_toggle).pack(side="left", padx=3)
        for key in ("http", "https", "socks4", "socks5"):
            ttk.Checkbutton(fr2, text=key.upper(),
                            variable=self.pm_proto_filter[key],
                            command=self._on_pm_proto_toggle).pack(
                                side="left", padx=3)
        self.pm_filter_count_label = ttk.Label(fr2, text="", foreground="#555")
        self.pm_filter_count_label.pack(side="right", padx=8)

        # ── Proxy Table ───────────────────────────────────────────────────────
        tf = ttk.Frame(tab)
        tf.pack(fill="both", expand=True, padx=6, pady=4)
        cols   = ("proto", "ip", "port", "alive", "rtime", "last")
        labels = {"proto": "Protocol", "ip": "IP Address", "port": "Port",
                  "alive": "Status", "rtime": "Resp. Time", "last": "Last Checked"}
        widths = {"proto": 90, "ip": 160, "port": 60,
                  "alive": 90, "rtime": 100, "last": 170}
        self.proxy_tree = ttk.Treeview(tf, columns=cols, show="headings",
                                        selectmode="extended")
        for c in cols:
            self.proxy_tree.heading(c, text=labels[c],
                                     command=lambda col=c: self._sort_proxy_table(col))
            self.proxy_tree.column(c, width=widths[c], anchor="center")
        self.proxy_tree.tag_configure("alive",    background="#d4edda",
                                       foreground="#155724")
        self.proxy_tree.tag_configure("dead",     background="#f8d7da",
                                       foreground="#721c24")
        self.proxy_tree.tag_configure("untested", background="#f0f0f0",
                                       foreground="#555555")
        vsb = ttk.Scrollbar(tf, orient="vertical",   command=self.proxy_tree.yview)
        hsb = ttk.Scrollbar(tf, orient="horizontal", command=self.proxy_tree.xview)
        self.proxy_tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        vsb.pack(side="right",  fill="y")
        hsb.pack(side="bottom", fill="x")
        self.proxy_tree.pack(fill="both", expand=True)

        leg = ttk.Frame(tab); leg.pack(fill="x", padx=6, pady=2)
        ttk.Label(leg,
                  text="● Green=alive  ● Red=dead  ● Grey=untested  |  "
                       "Click column headers to sort",
                  font=("TkDefaultFont", 8), foreground="#666").pack(side="left")
        # Track sort state per column
        self._proxy_sort_col  = None
        self._proxy_sort_desc = False

    # ═══════════════════════════════════════════════════════════════════════════
    # DORK TOOLS TAB  (unchanged from v4)
    # ═══════════════════════════════════════════════════════════════════════════
    def _build_dork_tools_tab(self, nb):
        tab = ttk.Frame(nb)
        nb.add(tab, text="🔧 Dork Tools")
        pane = ttk.PanedWindow(tab, orient="horizontal")
        pane.pack(fill="both", expand=True)

        left = ttk.Frame(pane); pane.add(left, weight=0)

        kf = ttk.LabelFrame(left, text="🔑 Keyword Generator", padding=6)
        kf.pack(fill="x", padx=6, pady=4)
        self.kwords = tk.StringVar()
        ttk.Entry(kf, textvariable=self.kwords, width=36).pack(fill="x")
        ttk.Label(kf, text="Comma-separated keywords",
                  foreground="#888", font=("TkDefaultFont", 8)).pack(anchor="w")
        r = ttk.Frame(kf); r.pack(fill="x", pady=4)
        ttk.Button(r, text="⚡ Generate Dorks",
                   command=self.generate_dorks_from_keywords).pack(
                       side="left", padx=2)
        ttk.Button(r, text="🎲 Random",
                   command=self.generate_random_dork).pack(side="left", padx=2)
        ttk.Button(r, text="💡 Suggest",
                   command=self.suggest_keywords).pack(side="left", padx=2)
        ttk.Button(r, text="📂 Upload List",
                   command=self.upload_keywords).pack(side="left", padx=2)

        cbf = ttk.LabelFrame(left, text="🔧 Custom Dork Builder", padding=6)
        cbf.pack(fill="x", padx=6, pady=4)
        for label, attr in [("inurl:", "inurl"), ("intitle:", "intitle"),
                             ("filetype:", "filetype"), ("site:", "site_field")]:
            r = ttk.Frame(cbf); r.pack(fill="x", pady=1)
            ttk.Label(r, text=label, width=9).pack(side="left")
            e = ttk.Entry(r, width=26); e.pack(side="left", padx=2)
            setattr(self, attr, e)
        ttk.Button(cbf, text="⚙ Combine & Add to Library",
                   command=self.combine_generate_dorks).pack(fill="x", pady=4)

        ef = ttk.LabelFrame(left, text="🔗 Extract from URLs", padding=6)
        ef.pack(fill="x", padx=6, pady=4)
        self.extract_text = scrolledtext.ScrolledText(
            ef, height=7, width=38, font=("Courier", 9))
        self.extract_text.pack(fill="x")
        r = ttk.Frame(ef); r.pack(fill="x", pady=4)
        ttk.Button(r, text="🔍 Extract Dorks",
                   command=self.extract_dorks_from_urls).pack(
                       side="left", padx=2)
        ttk.Button(r, text="📂 Load URLs",
                   command=self.load_urls).pack(side="left", padx=2)

        right = ttk.Frame(pane); pane.add(right, weight=1)
        lf = ttk.LabelFrame(right, text="📚 Dork Library", padding=6)
        lf.pack(fill="both", expand=True, padx=6, pady=4)
        r = ttk.Frame(lf); r.pack(fill="x", pady=(0, 4))
        ttk.Button(r, text="➕ Add to Scanner",
                   command=self.add_selected_dorks_to_scanner).pack(
                       side="left", padx=2)
        ttk.Button(r, text="💾 Save Library",
                   command=self.save_dork_library).pack(side="left", padx=2)
        ttk.Button(r, text="⬇ Export JSON",
                   command=self.export_dorks).pack(side="left", padx=2)
        ttk.Button(r, text="📂 Load Domains",
                   command=self.load_domains_file).pack(side="left", padx=2)
        lbox_frame = ttk.Frame(lf)
        lbox_frame.pack(fill="both", expand=True)
        self.dork_listbox = tk.Listbox(
            lbox_frame, font=("Courier", 9), selectmode="extended")
        vsb = ttk.Scrollbar(lbox_frame, command=self.dork_listbox.yview)
        self.dork_listbox.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        self.dork_listbox.pack(fill="both", expand=True)

    # ═══════════════════════════════════════════════════════════════════════════
    # STATS / LOGS TAB
    # ═══════════════════════════════════════════════════════════════════════════
    def _build_stats_tab(self, nb):
        tab = ttk.Frame(nb)
        nb.add(tab, text="📊 Stats / Logs")
        r = ttk.Frame(tab, padding=6); r.pack(fill="x")
        ttk.Button(r, text="⬇ Export Audit Log",
                   command=self.export_audit_log).pack(side="left", padx=2)
        ttk.Button(r, text="🗑 Clear Cache",
                   command=self.clear_cache).pack(side="left", padx=2)
        ttk.Button(r, text="📈 Memory Chart",
                   command=self.show_memory_chart).pack(side="left", padx=2)
        st = ttk.LabelFrame(tab, text="Live Audit Log", padding=6)
        st.pack(fill="both", expand=True, padx=6, pady=4)
        self.stats_text = scrolledtext.ScrolledText(
            st, font=("Courier", 9), background="#0f1923", foreground="#93c5fd")
        self.stats_text.pack(fill="both", expand=True)

    # ═══════════════════════════════════════════════════════════════════════════
    # PORT SCANNER TAB  (adds timeout spinbox)
    # ═══════════════════════════════════════════════════════════════════════════
    def _build_port_scanner_tab(self, nb):
        tab = ttk.Frame(nb)
        nb.add(tab, text="⚡ Port Scanner")
        pane = ttk.PanedWindow(tab, orient="horizontal")
        pane.pack(fill="both", expand=True)

        left = ttk.Frame(pane); pane.add(left, weight=0)

        tf = ttk.LabelFrame(left, text="🎯 Target (authorized)", padding=6)
        tf.pack(fill="x", padx=6, pady=4)
        ttk.Entry(tf, textvariable=self.target_host, width=36).pack(fill="x")
        ttk.Label(tf, text="Must be in authorized domains list",
                  foreground="#888", font=("TkDefaultFont", 8)).pack(anchor="w")

        mf = ttk.LabelFrame(left, text="🔢 Port Selection", padding=6)
        mf.pack(fill="x", padx=6, pady=4)
        r = ttk.Frame(mf); r.pack(fill="x")
        ttk.Radiobutton(r, text="Fixed ports",
                        variable=self.port_mode, value="fixed").pack(side="left")
        ttk.Radiobutton(r, text="Random",
                        variable=self.port_mode, value="dynamic").pack(
                            side="left", padx=8)
        r2 = ttk.Frame(mf); r2.pack(fill="x", pady=2)
        ttk.Label(r2, text="Fixed:", width=8).pack(side="left")
        ttk.Entry(r2, textvariable=self.fixed_ports,
                  width=28).pack(side="left", padx=2)
        r3 = ttk.Frame(mf); r3.pack(fill="x", pady=2)
        ttk.Label(r3, text="# Random:", width=8).pack(side="left")
        ttk.Spinbox(r3, from_=1, to=1000,
                    textvariable=self.num_random, width=6).pack(
                        side="left", padx=2)
        r4 = ttk.Frame(mf); r4.pack(fill="x", pady=2)
        ttk.Label(r4, text="Timeout (s):", width=8).pack(side="left")
        ttk.Spinbox(r4, from_=0.1, to=10, increment=0.1,
                    textvariable=self.port_timeout, width=6).pack(
                        side="left", padx=2)

        cf = ttk.LabelFrame(left, text="▶ Controls", padding=6)
        cf.pack(fill="x", padx=6, pady=4)
        r = ttk.Frame(cf); r.pack(fill="x")
        ttk.Button(r, text="▶ Start Scan",
                   command=self.start_port_scan,
                   style="Success.TButton").pack(side="left", padx=2)
        ttk.Button(r, text="⏹ Stop",
                   command=self.stop_port_scan,
                   style="Danger.TButton").pack(side="left", padx=2)
        ttk.Label(cf, text="Concurrent threads with jitter between batches",
                  font=("TkDefaultFont", 8), foreground="#888").pack(
                      anchor="w", pady=(4, 0))

        # ── Export ───────────────────────────────────────────────────────────
        xf = ttk.LabelFrame(left, text="⬇ Export Results", padding=6)
        xf.pack(fill="x", padx=6, pady=4)
        xr = ttk.Frame(xf); xr.pack(fill="x")
        ttk.Button(xr, text="Export Open Ports → TXT",
                   command=self.export_port_results_txt).pack(
                       side="left", padx=2)
        ttk.Button(xr, text="Export → JSON",
                   command=self.export_port_results_json).pack(
                       side="left", padx=2)
        ttk.Label(xf, text="Exports open ports found in last scan",
                  font=("TkDefaultFont", 8), foreground="#888").pack(
                      anchor="w", pady=(2, 0))

        right = ttk.Frame(pane); pane.add(right, weight=1)
        # Results header row with clear button
        rh = ttk.Frame(right); rh.pack(fill="x", padx=6, pady=(4, 0))
        ttk.Label(rh, text="📋 Results",
                  font=("TkDefaultFont", 9, "bold")).pack(side="left")
        ttk.Button(rh, text="🗑 Clear Log",
                   command=lambda: self.port_log.delete(
                       1.0, tk.END)).pack(side="right", padx=2)
        rf = ttk.LabelFrame(right, text="", padding=6)
        rf.pack(fill="both", expand=True, padx=6, pady=(2, 4))
        self.port_log = scrolledtext.ScrolledText(
            rf, font=("Courier", 9), background="#0f1923", foreground="#a8d8a8")
        self.port_log.tag_configure("open",   foreground="#4ade80")
        self.port_log.tag_configure("closed", foreground="#6b7280")
        self.port_log.tag_configure("info",   foreground="#93c5fd")
        self.port_log.pack(fill="both", expand=True)

    # ═══════════════════════════════════════════════════════════════════════════
    # DOMAIN-TO-IP TAB  (adds concurrency workers spinbox)
    # ═══════════════════════════════════════════════════════════════════════════
    def _build_domain_ip_tab(self, nb):
        tab = ttk.Frame(nb)
        nb.add(tab, text="🌐 Domain-to-IP")
        pane = ttk.PanedWindow(tab, orient="horizontal")
        pane.pack(fill="both", expand=True)

        left = ttk.Frame(pane); pane.add(left, weight=0)

        inf = ttk.LabelFrame(left, text="📥 Input", padding=6)
        inf.pack(fill="x", padx=6, pady=4)
        self.domain_input = scrolledtext.ScrolledText(
            inf, height=14, width=36, font=("Courier", 9))
        self.domain_input.pack(fill="x")
        ttk.Button(inf, text="📂 Load from file",
                   command=self.load_urls_for_domain_ip).pack(fill="x", pady=2)
        ttk.Checkbutton(inf, text="Normalize (strip protocol/www.)",
                        variable=self.normalize_domains).pack(anchor="w")

        cf = ttk.LabelFrame(left, text="▶ Controls", padding=6)
        cf.pack(fill="x", padx=6, pady=4)
        r = ttk.Frame(cf); r.pack(fill="x")
        ttk.Button(r, text="▶ Start",
                   command=self.start_domain_ip_conversion,
                   style="Success.TButton").pack(side="left", padx=2)
        ttk.Button(r, text="⏸ Pause",
                   command=self.pause_domain_ip).pack(side="left", padx=2)
        ttk.Button(r, text="⏹ Stop",
                   command=self.stop_domain_ip,
                   style="Danger.TButton").pack(side="left", padx=2)
        r2 = ttk.Frame(cf); r2.pack(fill="x", pady=(4, 0))
        ttk.Label(r2, text="Workers:").pack(side="left")
        ttk.Spinbox(r2, from_=1, to=100,
                    textvariable=self.domain_ip_workers, width=5).pack(
                        side="left", padx=4)
        ttk.Button(cf, text="🔁 Retry Failed",
                   command=self.retry_failed_resolutions).pack(
                       fill="x", pady=2)
        ttk.Button(cf, text="🗑 Clear",
                   command=self.clear_domain_ip_results).pack(fill="x", pady=2)

        # ── Export ───────────────────────────────────────────────────────────
        xf = ttk.LabelFrame(left, text="⬇ Export Results", padding=6)
        xf.pack(fill="x", padx=6, pady=4)
        ttk.Button(xf, text="Export Resolved → TXT",
                   command=self.export_dns_results_txt).pack(
                       fill="x", pady=1)
        ttk.Button(xf, text="Export Resolved → JSON",
                   command=self.export_dns_results_json).pack(
                       fill="x", pady=1)
        ttk.Button(xf, text="Export Failed → TXT",
                   command=self.export_dns_failed_txt).pack(
                       fill="x", pady=1)
        ttk.Label(xf, text="Exports results from last resolution run",
                  font=("TkDefaultFont", 8), foreground="#888").pack(
                      anchor="w", pady=(2, 0))

        right = ttk.Frame(pane); pane.add(right, weight=1)
        # Results header with stats label
        rh = ttk.Frame(right); rh.pack(fill="x", padx=6, pady=(4, 0))
        ttk.Label(rh, text="📋 Resolution Results",
                  font=("TkDefaultFont", 9, "bold")).pack(side="left")
        self.dns_stats_label = ttk.Label(
            rh, text="", foreground="#555",
            font=("TkDefaultFont", 8))
        self.dns_stats_label.pack(side="right", padx=4)
        rf = ttk.LabelFrame(right, text="", padding=6)
        rf.pack(fill="both", expand=True, padx=6, pady=(2, 4))
        self.domain_log = scrolledtext.ScrolledText(
            rf, font=("Courier", 9), background="#0f1923", foreground="#a8d8a8")
        self.domain_log.tag_configure("ok",   foreground="#4ade80")
        self.domain_log.tag_configure("fail", foreground="#f87171")
        self.domain_log.pack(fill="both", expand=True)

    # ═══════════════════════════════════════════════════════════════════════════
    # ACTION METHODS
    # ═══════════════════════════════════════════════════════════════════════════

    def load_dorks_file(self):
        p = filedialog.askopenfilename(
            title="Open dorks.txt",
            filetypes=[("Text", "*.txt"), ("All", "*.*")])
        if not p: return
        with open(p, "r", encoding="utf-8") as f:
            d = [l.strip() for l in f if l.strip()]
        self.dork_text.insert(tk.END, "\n".join(d) + "\n")
        messagebox.showinfo("Loaded", f"Loaded {len(d)} dorks.")

    def load_useragents_file(self):
        p = filedialog.askopenfilename(
            title="Open useragents.txt", filetypes=[("Text", "*.txt")])
        if not p: return
        with open(p, "r", encoding="utf-8") as f:
            uas = [l.strip() for l in f if l.strip()]
        if uas:
            self.user_agents = uas
            messagebox.showinfo("Loaded", f"Loaded {len(uas)} user-agents.")

    def authorize_domains_dialog(self):
        def save():
            text = ta.get(1.0, tk.END).strip()
            if not text:
                messagebox.showwarning("Authorize", "Enter at least one domain.")
                return
            self.auth_domains = [d.strip() for d in text.splitlines() if d.strip()]
            self.lbl_auth.config(
                text=f"Authorized: {', '.join(self.auth_domains)}",
                foreground="#16a34a")
            log_event(f"Authorization set for: {self.auth_domains}")
            top.destroy()
        top = tk.Toplevel(self)
        top.title("Authorize Target Domains")
        ttk.Label(top,
                  text="Enter authorized domains (one per line).\n"
                       "You must have permission to test these.",
                  wraplength=400).pack(padx=12, pady=8)
        ta = scrolledtext.ScrolledText(top, width=50, height=8)
        ta.pack(padx=12, pady=4)
        if self.auth_domains:
            ta.insert(tk.END, "\n".join(self.auth_domains))
        ttk.Button(top, text="💾 Save Authorization", command=save).pack(pady=8)

    # ── Proxy Manager actions ─────────────────────────────────────────────────
    def load_proxies_file(self):
        p = filedialog.askopenfilename(
            title="Open proxies.txt", filetypes=[("Text", "*.txt")])
        if not p: return
        proxy_manager.load_from_file(p)
        self.refresh_proxy_table()
        self._refresh_pool_summary()

    def clear_proxy_manager_data(self):
        """Clear loaded proxy pool and reset proxy-manager UI state."""
        if not messagebox.askyesno(
                "Clear Proxies",
                "Clear all proxies currently loaded in Proxy Manager?\n\n"
                "This does not delete your proxies.txt file on disk."):
            return
        # Stop background proxy tasks first so they don't repopulate during clear.
        self._proxy_scrape_stop.set()
        self._proxy_validate_stop.set()
        with proxy_manager.lock:
            proxy_manager.proxies.clear()
        self.refresh_proxy_table()
        self._refresh_pool_summary()
        self.pm_progress_bar.config(value=0)
        self.pm_progress_label.config(text="Cleared")
        self.pm_count_label.config(text="0 total loaded")
        self.lbl_active_proxy.config(text="Active: none")
        log_event("Proxy manager cleared: in-memory proxy pool reset.")

    def clear_proxy_manager_data_and_file(self):
        """Clear loaded proxies and truncate proxies.txt."""
        if not messagebox.askyesno(
                "Clear + Remove File",
                "Clear all loaded proxies AND remove all lines from proxies.txt?\n\n"
                "This action truncates data/proxies.txt to empty."):
            return
        self._proxy_scrape_stop.set()
        self._proxy_validate_stop.set()
        try:
            os.makedirs(os.path.dirname(PROXIES_FILE), exist_ok=True)
            with open(PROXIES_FILE, "w", encoding="utf-8") as f:
                f.write("")
        except Exception as e:
            messagebox.showerror("Clear Failed", f"Could not truncate proxies.txt:\n{e}")
            return
        with proxy_manager.lock:
            proxy_manager.proxies.clear()
        self.refresh_proxy_table()
        self._refresh_pool_summary()
        self.pm_progress_bar.config(value=0)
        self.pm_progress_label.config(text="Cleared + file wiped")
        self.pm_count_label.config(text="0 total loaded")
        self.lbl_active_proxy.config(text="Active: none")
        log_event("Proxy manager cleared and proxies.txt truncated.")

    def delete_dead_proxies(self):
        """Delete dead proxies from memory and proxies.txt after validation."""
        with proxy_manager.lock:
            dead = [p for p in proxy_manager.proxies
                    if p.get("alive") is False and p.get("last_checked")]
            dead_n = len(dead)
            if dead_n == 0:
                messagebox.showinfo("Delete Dead", "No dead proxies found.")
                return
        if not messagebox.askyesno(
                "Delete Dead Proxies",
                f"Delete {dead_n} dead proxies from Proxy Manager and proxies.txt?"):
            return

        self._proxy_scrape_stop.set()
        self._proxy_validate_stop.set()

        try:
            existing = []
            if os.path.exists(PROXIES_FILE):
                with open(PROXIES_FILE, "r", encoding="utf-8") as f:
                    existing = [l.rstrip("\n") for l in f if l.strip()]
            dead_norm = set()
            for p in dead:
                dead_norm.add(p.get("raw", "").strip())
            kept_lines = []
            for line in existing:
                parsed = proxy_manager._parse_proxy_line(line.strip())
                if parsed and parsed["raw"] in dead_norm:
                    continue
                kept_lines.append(line)
            with open(PROXIES_FILE, "w", encoding="utf-8") as f:
                if kept_lines:
                    f.write("\n".join(kept_lines) + "\n")
                else:
                    f.write("")
        except Exception as e:
            messagebox.showerror("Delete Dead", f"Failed updating proxies.txt:\n{e}")
            return

        with proxy_manager.lock:
            proxy_manager.proxies = [
                p for p in proxy_manager.proxies
                if not (p.get("alive") is False and p.get("last_checked"))
            ]
        self.refresh_proxy_table()
        self._refresh_pool_summary()
        log_event(f"Deleted {dead_n} dead proxies from pool and proxies.txt.")
        messagebox.showinfo("Delete Dead", f"Removed {dead_n} dead proxies.")

    def _on_pm_proto_toggle(self):
        """Bug 2 fix: ALL and specific protocols are mutually exclusive.
        Checking ALL clears all specific ones.
        Checking any specific one clears ALL.
        If all specific ones get unchecked, re-enable ALL automatically.
        """
        # Determine which checkbox was just activated by reading current state
        all_checked  = self.pm_proto_filter["all"].get()
        specifics    = ("http", "https", "socks4", "socks5")
        any_specific = any(self.pm_proto_filter[k].get() for k in specifics)

        if all_checked and any_specific:
            # User just checked ALL — clear all specific ones
            for k in specifics:
                self.pm_proto_filter[k].set(False)
        elif any_specific and not all_checked:
            # User checked a specific protocol — ensure ALL stays unchecked
            self.pm_proto_filter["all"].set(False)
        elif not any_specific and not all_checked:
            # Nothing selected — revert to ALL to avoid empty filter
            self.pm_proto_filter["all"].set(True)
        self.refresh_proxy_table()

    def _get_filtered_proxies(self):
        status        = self.pm_status_filter.get()
        use_all_proto = self.pm_proto_filter["all"].get()
        allowed_proto = {k for k in ("http", "https", "socks4", "socks5")
                         if self.pm_proto_filter[k].get()}
        result = []
        with proxy_manager.lock:
            for p in proxy_manager.proxies:
                alive  = p.get("alive")
                tested = p.get("last_checked") is not None
                if status == "alive"    and alive is not True:            continue
                if status == "dead"     and not (alive is False and tested): continue
                if status == "untested" and tested:                        continue
                if not use_all_proto and p["proto"] not in allowed_proto: continue
                result.append(p)
        return result

    def refresh_proxy_table(self):
        for iid in self.proxy_tree.get_children():
            self.proxy_tree.delete(iid)
        filtered = self._get_filtered_proxies()
        alive_n  = sum(1 for p in filtered if p.get("alive"))
        dead_n   = sum(1 for p in filtered if p.get("alive") is False
                       and p.get("last_checked"))
        unt_n    = sum(1 for p in filtered if not p.get("last_checked"))
        self.pm_filter_count_label.config(
            text=f"{len(filtered)} shown  |  "
                 f"{alive_n} alive  {dead_n} dead  {unt_n} untested")
        self.pm_count_label.config(
            text=f"{len(proxy_manager.proxies)} total loaded")
        for p in filtered:
            alive  = p.get("alive")
            tested = p.get("last_checked") is not None
            tag    = "alive" if alive else ("dead" if tested else "untested")
            rtime  = f"{p['rtime']:.3f}s" if p.get("rtime") else "—"
            last   = (p.get("last_checked") or "never")[:19]
            status = "✔ alive" if alive else ("✘ dead" if tested else "—")
            iid    = p["raw"].replace(" ", "_")
            try:
                self.proxy_tree.insert("", tk.END, iid=iid, tags=(tag,),
                    values=(p["proto"], p["ip"], p["port"], status, rtime, last))
            except Exception:
                self.proxy_tree.insert("", tk.END, tags=(tag,),
                    values=(p["proto"], p["ip"], p["port"], status, rtime, last))

    def _update_proxy_row_live(self, entry):
        iid    = entry["raw"].replace(" ", "_")
        alive  = entry.get("alive")
        tested = entry.get("last_checked") is not None
        tag    = "alive" if alive else ("dead" if tested else "untested")
        rtime  = f"{entry['rtime']:.3f}s" if entry.get("rtime") else "—"
        last   = (entry.get("last_checked") or "never")[:19]
        status = "✔ alive" if alive else "✘ dead"
        try:
            if self.proxy_tree.exists(iid):
                self.proxy_tree.item(iid, tags=(tag,),
                    values=(entry["proto"], entry["ip"], entry["port"],
                            status, rtime, last))
            else:
                self.proxy_tree.insert("", tk.END, iid=iid, tags=(tag,),
                    values=(entry["proto"], entry["ip"], entry["port"],
                            status, rtime, last))
        except Exception:
            pass

    def _refresh_pool_summary(self):
        """Update the pool summary box in the scanner tab."""
        proto_choices = [k for k, v in self.proxy_protocols.items() if v.get()]
        s = proxy_manager.pool_summary(
            protocols=proto_choices if proto_choices else None)
        s_all = proxy_manager.pool_summary()
        self.lbl_pool_alive.config(text=f"Alive: {s['alive']}")
        self.lbl_pool_alive_total.config(text=f"Total alive(all): {s_all['alive']}")
        self.lbl_pool_dead.config(text=f"Dead: {s['dead']}")
        self.lbl_pool_untested.config(text=f"Untested: {s['untested']}")
        bp = s["by_proto"]
        self.lbl_pool_protocols.config(
            text=f"http({bp['http']}) https({bp['https']}) "
                 f"socks4({bp['socks4']}) socks5({bp['socks5']})")

    def _refresh_proxy_counts_live(self):
        """Refresh count labels without rebuilding the whole proxy table."""
        filtered = self._get_filtered_proxies()
        alive_n  = sum(1 for p in filtered if p.get("alive"))
        dead_n   = sum(1 for p in filtered if p.get("alive") is False
                       and p.get("last_checked"))
        unt_n    = sum(1 for p in filtered if not p.get("last_checked"))
        self.pm_filter_count_label.config(
            text=f"{len(filtered)} shown  |  "
                 f"{alive_n} alive  {dead_n} dead  {unt_n} untested")
        self.pm_count_label.config(text=f"{len(proxy_manager.proxies)} total loaded")

    def stop_scrape(self):
        """Bug 3 fix: cancel an in-progress proxy scrape."""
        self._proxy_scrape_stop.set()
        log_event("Proxy scrape stop requested.")
        self.after(0, lambda: self.pm_progress_label.config(text="Stopped"))

    def stop_validate(self):
        """Bug 3 fix: cancel an in-progress proxy validation."""
        self._proxy_validate_stop.set()
        log_event("Proxy validation stop requested.")
        self.after(0, lambda: self.pm_progress_label.config(text="Stopping…"))

    def _sort_proxy_table(self, col):
        """Sort proxy table by column header click."""
        if self._proxy_sort_col == col:
            self._proxy_sort_desc = not self._proxy_sort_desc
        else:
            self._proxy_sort_col  = col
            self._proxy_sort_desc = False
        items = [(self.proxy_tree.set(iid, col), iid)
                 for iid in self.proxy_tree.get_children("")]
        try:
            items.sort(key=lambda x: float(x[0].replace("s", "")) if x[0] not in ("—", "✔ alive", "✘ dead") else -1,
                       reverse=self._proxy_sort_desc)
        except Exception:
            items.sort(key=lambda x: x[0], reverse=self._proxy_sort_desc)
        for idx, (_, iid) in enumerate(items):
            self.proxy_tree.move(iid, "", idx)

    def scrape_sample_proxies_thread(self):
        self._proxy_scrape_stop.clear()
        threading.Thread(target=self._scrape_sample_proxies,
                         name="proxy-scrape", daemon=True).start()

    def _scrape_sample_proxies(self):
        """Bug 1 fix: reads pm_scrape_protos (proxy tab's own protocol selector)
        NOT self.proxy_protocols (the scanner tab's routing checkboxes).
        Bug 3 fix: checks _proxy_scrape_stop event to allow cancellation.
        """
        selected = self.proxy_source_var.get()
        tmpl     = self.proxy_sources.get(selected)
        if not tmpl: return

        # Bug 1 fix: read the proxy tab's dedicated scrape protocol checkboxes
        protos = [k for k, v in self.pm_scrape_protos.items() if v.get()]
        if not protos:
            self.after(0, lambda: messagebox.showwarning(
                "Scrape Protocols",
                "Select at least one protocol to scrape in the "
                "'Scrape protocols' row above."))
            return

        n = len(protos)
        self.after(0, lambda: self.pm_progress_label.config(
            text=f"Fetching {', '.join(p.upper() for p in protos)} proxies…"))
        self.after(0, lambda: self.pm_progress_bar.config(
            maximum=n, value=0))
        collected = []

        for i, proto in enumerate(protos):
            # Bug 3 fix: honour stop event between each protocol fetch
            if self._proxy_scrape_stop.is_set():
                log_event("Proxy scrape stopped by user.")
                break
            url = (tmpl.format(proto="http" if proto == "https" else proto)
                   if "{proto}" in tmpl else tmpl)
            try:
                r = requests.get(url, timeout=12)
                if r.status_code == 200:
                    newly_collected = 0
                    for line in r.text.splitlines():
                        line = line.strip()
                        if not line or line.startswith("#"):
                            continue
                        # Prepend protocol scheme if not already present
                        entry = (f"{proto}://{line}"
                                 if not line.startswith(proto + "://") else line)
                        collected.append(entry)
                        newly_collected += 1
                    # Fix #6: log collected proxy count, not raw line count
                    log_event(f"Scraped {proto}: {newly_collected} proxies collected from {selected}")
            except Exception as e:
                log_event(f"Scrape error ({proto} from {selected}): {e}")
            v = i + 1
            self.after(0, lambda v=v: self.pm_progress_bar.config(value=v))

        collected = list(set(collected))
        if collected:
            try:
                with open(PROXIES_FILE, "a", encoding="utf-8") as f:
                    f.write("\n".join(collected) + "\n")
            except Exception as e:
                log_event(f"Scrape write error: {e}")
            proxy_manager.load_from_file(PROXIES_FILE)

        self.after(0, self.refresh_proxy_table)
        self.after(0, self._refresh_pool_summary)
        stopped = self._proxy_scrape_stop.is_set()
        status  = f"Stopped — {len(collected)} scraped" if stopped else f"Done — {len(collected)} proxies added"
        self.after(0, lambda: self.pm_progress_label.config(text=status))
        self.after(0, lambda: self.pm_progress_bar.config(value=0))
        if not stopped:
            msg = (f"Scraped {len(collected)} proxies from {selected}.\n"
                   f"Protocols: {', '.join(p.upper() for p in protos)}")
            self.after(0, lambda: messagebox.showinfo("Scrape Complete", msg))

    def validate_proxies_thread(self):
        """Passes _proxy_validate_stop event so Stop Validate works.
        UI updates throttled so 100-200 simultaneous workers don't flood
        the Tkinter main thread with after(0,...) calls causing lag/freeze.
        """
        self._proxy_validate_stop.clear()
        validated_count  = [0]
        _ui_pending      = [False]
        _ui_pending_lock = threading.Lock()

        def cb(current, total, entry=None):
            validated_count[0] = current
            # Throttle: only queue a new UI update if one isn't already pending.
            # At 100-200 threads the callback fires extremely fast; without this
            # every completion queues its own after(0,...) and the main thread
            # drowns in Tkinter calls, making the UI feel frozen.
            with _ui_pending_lock:
                already_pending = _ui_pending[0]
                _ui_pending[0]  = True
            if already_pending:
                return
            snap_total = total
            snap_entry = entry

            def _upd():
                with _ui_pending_lock:
                    _ui_pending[0] = False
                live_cur = validated_count[0]
                self.pm_progress_label.config(
                    text=f"Validating {live_cur}/{snap_total}")
                self.pm_progress_bar.config(value=live_cur)
                if snap_entry:
                    self._update_proxy_row_live(snap_entry)
                self._refresh_pool_summary()
                self._refresh_proxy_counts_live()
                if (live_cur % 10 == 0
                        or self.pm_status_filter.get() != "all"
                        or not self.pm_proto_filter["all"].get()):
                    self.refresh_proxy_table()
            self.after(0, _upd)

        self.pm_progress_bar.config(
            maximum=max(1, len(proxy_manager.proxies)), value=0)

        def _run():
            proxy_manager.validate_proxies(
                max_workers=self.proxy_validate_workers.get(),
                progress_callback=cb,
                stop_event=self._proxy_validate_stop)
            alive = sum(1 for p in proxy_manager.proxies if p.get("alive"))
            tot   = len(proxy_manager.proxies)
            stopped = self._proxy_validate_stop.is_set()
            done_n  = validated_count[0]
            log_event(f"Validation {'stopped' if stopped else 'complete'}: "
                      f"{alive}/{tot} alive ({done_n} checked).")
            self.after(0, self.refresh_proxy_table)
            self.after(0, self._refresh_pool_summary)
            status = (f"Stopped at {done_n}/{tot} — {alive} alive"
                      if stopped else f"Done: {alive}/{tot} alive")
            self.after(0, lambda: self.pm_progress_label.config(text=status))
            self.after(0, lambda: self.pm_progress_bar.config(value=0))

        threading.Thread(target=_run, name="proxy-validate-ui",
                         daemon=True).start()

    def export_filtered_proxies(self):
        filtered = self._get_filtered_proxies()
        if not filtered:
            messagebox.showinfo("Export", "No proxies match current filter.")
            return
        urls = [p["raw"] for p in filtered]
        path = save_export("proxies_filtered", urls, fmt="txt")
        messagebox.showinfo("Exported", f"Exported {len(urls)} proxies to:\n{path}")

    def export_valid_proxies(self):
        """Bug 8 fix: export alive proxies respecting the current protocol filter.
        Previously exported ALL alive proxies regardless of protocol filter selection.
        Now uses _get_filtered_proxies with status forced to 'alive'.
        """
        # Temporarily force status to alive, keep protocol filter as-is
        orig_status = self.pm_status_filter.get()
        self.pm_status_filter.set("alive")
        filtered = self._get_filtered_proxies()
        self.pm_status_filter.set(orig_status)

        if not filtered:
            messagebox.showinfo("Export", "No alive proxies match the current "
                                          "protocol filter.")
            return
        urls = [p["raw"] for p in filtered]
        path = save_export("proxies_alive", urls, fmt="txt")
        # Show which protocols were included
        proto_summary = {}
        for p in filtered:
            proto_summary[p["proto"]] = proto_summary.get(p["proto"], 0) + 1
        breakdown = "  ".join(f"{k}:{v}" for k, v in sorted(proto_summary.items()))
        messagebox.showinfo("Exported",
                            f"Exported {len(urls)} alive proxies to:\n{path}\n\n"
                            f"Breakdown: {breakdown}")

    # ── Dork Tools actions ────────────────────────────────────────────────────
    def generate_dorks_from_keywords(self):
        kw = self.kwords.get().strip()
        if not kw:
            messagebox.showwarning("Keywords", "Enter keywords."); return
        for k in [p.strip() for p in kw.split(",") if p.strip()]:
            for d in (f"inurl:{k}", f"intitle:{k}", f'"{k}" filetype:php'):
                self.dork_listbox.insert(tk.END, d)
        messagebox.showinfo("Done", "Dorks added to library.")

    def generate_random_dork(self):
        op = random.choice(["inurl", "intitle", "filetype"])
        kw = random.choice(["login", "admin", "index.php", "dashboard",
                             "user", "config", "upload", "api"])
        self.dork_listbox.insert(tk.END, f"{op}:{kw}")

    def suggest_keywords(self):
        try:
            from faker import Faker
            faker = Faker()
            self.kwords.set(",".join(faker.word() for _ in range(5)))
        except ImportError:
            messagebox.showwarning(
                "Missing dep", "Install faker:  pip install faker")

    def upload_keywords(self):
        p = filedialog.askopenfilename(
            title="Keywords file", filetypes=[("Text", "*.txt")])
        if not p: return
        with open(p, "r", encoding="utf-8") as f:
            kws = [l.strip() for l in f if l.strip()]
        self.kwords.set(",".join(kws))
        messagebox.showinfo("Loaded", f"Loaded {len(kws)} keywords.")

    def load_urls(self):
        p = filedialog.askopenfilename(
            title="Open urls.txt", filetypes=[("Text", "*.txt")])
        if not p: return
        with open(p, "r", encoding="utf-8") as f:
            urls = [l.strip() for l in f if l.strip()]
        self.extract_text.delete(1.0, tk.END)
        self.extract_text.insert(tk.END, "\n".join(urls))

    def load_domains_file(self):
        p = filedialog.askopenfilename(
            title="Open domains.txt", filetypes=[("Text", "*.txt")])
        if not p: return
        with open(p, "r", encoding="utf-8") as f:
            doms = [l.strip() for l in f if l.strip()]
        self.auth_domains = doms
        log_event(f"Domains loaded: {doms}")
        messagebox.showinfo("Loaded", f"Loaded {len(doms)} domains.")

    def extract_dorks_from_urls(self):
        text = self.extract_text.get(1.0, tk.END).strip()
        if not text:
            messagebox.showwarning("Extract", "Paste URLs first."); return
        extracted = set()
        for u in [l.strip() for l in text.splitlines() if l.strip()]:
            if "?id=" in u:             extracted.add("inurl:?id=")
            if "login" in u.lower():    extracted.add("inurl:login")
            if "admin" in u.lower():    extracted.add("intitle:admin")
            try:
                if urlparse(u).path.endswith(".php"):
                    extracted.add("filetype:php")
            except Exception: pass
            try:
                qs = parse_qs(urlparse(u).query)
                for k in qs:
                    extracted.add(f"inurl:?{k}=")
            except Exception: pass
        for d in sorted(extracted):
            self.dork_listbox.insert(tk.END, d)
        messagebox.showinfo("Extracted", f"Extracted {len(extracted)} dorks.")

    def add_selected_dorks_to_scanner(self):
        sels = [self.dork_listbox.get(i)
                for i in self.dork_listbox.curselection()]
        if not sels:
            messagebox.showwarning("Select", "Select dorks first."); return
        self.dork_text.insert(tk.END, "\n".join(sels) + "\n")
        messagebox.showinfo("Added", f"Added {len(sels)} dorks.")

    def save_dork_library(self):
        arr = list(self.dork_listbox.get(0, tk.END))
        if not arr:
            messagebox.showinfo("Save", "Library empty."); return
        path = save_export("dork_library", arr, fmt="txt")
        messagebox.showinfo("Saved", f"Saved to:\n{path}")

    def export_dorks(self):
        arr = list(self.dork_listbox.get(0, tk.END))
        if not arr:
            messagebox.showinfo("Export", "Library empty."); return
        path = save_export("dorks_export", arr, fmt="json")
        messagebox.showinfo("Exported", f"Exported to:\n{path}")

    def combine_generate_dorks(self):
        parts = []
        if self.inurl.get().strip():
            parts.append(f"inurl:{self.inurl.get().strip()}")
        if self.intitle.get().strip():
            parts.append(f"intitle:{self.intitle.get().strip()}")
        if self.filetype.get().strip():
            parts.append(f"filetype:{self.filetype.get().strip()}")
        if self.site_field.get().strip():
            parts.append(f"site:{self.site_field.get().strip()}")
        if not parts: return
        dork = " ".join(parts)
        self.dork_listbox.insert(tk.END, dork)
        messagebox.showinfo("Added", f"Added: {dork}")

    # ── Scan control ──────────────────────────────────────────────────────────
    def start_scan(self):
        if not self.auth_domains:
            messagebox.showwarning("Authorization",
                                   "Authorize target domains first."); return
        text = self.dork_text.get(1.0, tk.END).strip()
        if not text:
            messagebox.showwarning("No dorks", "Paste or load dorks."); return
        dorks   = [l.strip() for l in text.splitlines() if l.strip()]
        engines = [e for e, v in self.selected_engines.items() if v.get()]
        if not engines:
            messagebox.showwarning("No engines", "Select at least one engine.")
            return

        # Guard: prevent starting a second scan while one runs
        if self.scanner_thread and self.scanner_thread.is_alive():
            messagebox.showwarning("Scan running",
                                   "A scan is already running. Stop it first.")
            return

        pages        = max(1, self.pages_per_engine.get())
        headers_pool = (self.user_agents if self.ua_rotate.get()
                        else [DEFAULT_USER_AGENTS[0]])
        use_px       = self.use_proxies.get()
        require_https = (self.proxy_mode.get() == "validated_https")
        min_https_checks = max(0, int(self.proxy_min_https_checks.get()))
        proto_choices = [k for k, v in self.proxy_protocols.items() if v.get()]
        min_d, max_d  = float(self.min_delay.get()), float(self.max_delay.get())
        if min_d > max_d:
            messagebox.showwarning("Delays", "Min delay > Max delay."); return
        if use_px:
            sel_summary = proxy_manager.pool_summary(
                protocols=proto_choices if proto_choices else None)
            all_summary = proxy_manager.pool_summary()
            sel_https_eligible = proxy_manager.count_eligible(
                protocols=proto_choices if proto_choices else None,
                require_https=True,
                min_https_checks=min_https_checks)
            sel_any_eligible = proxy_manager.count_eligible(
                protocols=proto_choices if proto_choices else None,
                require_https=False)
            if sel_any_eligible == 0 and all_summary["alive"] > 0:
                selected = ", ".join((proto_choices or ["ALL"])).upper()
                if not messagebox.askyesno(
                        "Proxy Protocol Mismatch",
                        "Route proxy is enabled, but no ALIVE proxies match the "
                        f"selected protocol filter ({selected}).\n\n"
                        f"Alive now: selected={sel_summary['alive']}  all={all_summary['alive']}.\n"
                        "If you continue, scan requests will fall back to real IP.\n\n"
                        "Continue anyway?"):
                    return
            elif require_https and sel_https_eligible == 0 and sel_any_eligible > 0:
                if not messagebox.askyesno(
                        "Proxy HTTPS Verification",
                        "No HTTPS-verified proxies are currently available for the "
                        "selected protocol filter.\n\n"
                        "The scanner can still use HTTPS-untested alive proxies "
                        "(better than falling back to real IP), but reliability may be lower.\n\n"
                        "Continue?"):
                    return

        # Date
        date_since = date_until = None
        if self.recent_date.get():
            date_since = (datetime.now() - timedelta(days=365)).strftime("%Y-%m-%d")
            date_until = datetime.now().strftime("%Y-%m-%d")
        elif self.from_year.get() or self.to_year.get():
            fy, ty = self.from_year.get(), self.to_year.get()
            # Fix H: guard against non-numeric strings typed into the Combobox.
            try:
                fy_int = int(fy) if fy else None
                ty_int = int(ty) if ty else None
            except ValueError:
                messagebox.showwarning("Dates", "From/To year must be numeric."); return
            if fy_int and ty_int and fy_int > ty_int:
                messagebox.showwarning("Dates", "From year > To year."); return
            if fy: date_since = f"{fy}-01-01"
            if ty: date_until = f"{ty}-12-31"

        # BS4 Engine Mode config
        bs4_only_mode   = self.bs4_only.get()
        bs4_workers_n   = int(self.bs4_workers.get())
        bs4_htp         = self.bs4_high_throughput.get()
        if bs4_htp:
            bs4_workers_n = 200

        # Selenium config — disabled when BS4-only mode is active
        sel_on      = (self.selenium_enabled.get() and SELENIUM_AVAILABLE
                       and not bs4_only_mode)
        sel_browser = self.selenium_browser_var.get()  # Fix #8: single Radiobutton var
        sel_headless = self.selenium_headless.get()
        sel_delay_min = float(self.sel_delay_min.get())
        sel_delay_max = float(self.sel_delay_max.get())
        if sel_delay_min > sel_delay_max:
            # Fix F: swap silently rather than rejecting — user likely just
            # entered them in the wrong order; a warning would be too noisy.
            sel_delay_min, sel_delay_max = sel_delay_max, sel_delay_min
        sel_delay = (sel_delay_min, sel_delay_max)

        # CAPTCHA config
        cap_enabled = self.captcha_enabled.get() and sel_on
        cap_mode    = self.captcha_mode.get()
        cap_key     = self.captcha_api_key.get()
        cap_wait    = int(self.captcha_max_wait.get())
        cap_retry   = int(self.captcha_retry_delay.get())
        cap_vis     = self.captcha_auto_visible.get()

        # Proxy for Selenium (grab once at scan start)
        sel_proxy = None
        if use_px and sel_on:
            sel_proxy = proxy_manager.get_random_proxy_gated(
                protocols=proto_choices or None, require_https=require_https,
                min_https_checks=min_https_checks)
            if not sel_proxy and not require_https:
                sel_proxy = proxy_manager.get_random_proxy_gated(
                    protocols=proto_choices or None, require_https=False,
                    min_https_checks=min_https_checks)
            if sel_proxy:
                log_event(f"Selenium proxy: {list(sel_proxy.values())[0]}")
                self.lbl_active_proxy.config(
                    text=f"Active: {list(sel_proxy.values())[0]}")

        # Refresh pool summary before scan
        self._refresh_pool_summary()

        mode_label = (f"BS4-ONLY · {bs4_workers_n} workers"
                      if bs4_only_mode else
                      f"{'Selenium+BS4' if sel_on else 'BS4/requests'}")
        if not messagebox.askyesno("Confirm",
            f"Scan {len(dorks)} dorks × {len(engines)} engines\n"
            f"Mode: {mode_label}\n"
            f"Authorized domains: {self.auth_domains}\n"
            f"⚠ ALL previous results will be WIPED from the database.\n"
            f"ALL scraped URLs will be saved. Filter at export.\n\nProceed?"):
            return

        _set_scan_running(True); _set_scan_paused(False)
        result_store.reset()
        with _global_seen_urls_lock:
            _global_seen_urls.clear()
        self._proxy_rotations = 0
        self._proxy_rot_success = 0
        self.lbl_proxy_rotations.config(text="0/0")
        self.dorks_processed  = 0
        self.urls_processed   = 0
        total_dorks           = len(dorks)
        self.progress_bar.config(maximum=total_dorks, value=0)
        self.lbl_dorks_scanned.config(text=f"0/{total_dorks} (0%)")
        self.start_time = time.time()
        log_event(
            f"Scan started — {len(dorks)} dorks × {len(engines)} engines · "
            f"{mode_label}")

        # Reset engine pills — Bug 8 fix: use human-readable display labels, not raw keys.
        _reset_disp = {
            "yahoojapan": "Yahoo JP", "aol": "AOL",
            "mojeek": "Mojeek", "qwant": "Qwant",
        }
        for eng, lbl in self.engine_pills.items():
            lbl.config(text=f"{_reset_disp.get(eng, eng)} 0", foreground="#888")

        def _on_proxy_rotation(proxy_str, status="attempt"):
            """Called from scan thread for proxy attempt/success events."""
            with self.results_lock:
                if status == "success":
                    self._proxy_rot_success += 1
                else:
                    self._proxy_rotations += 1
                rot_a = self._proxy_rotations
                rot_s = self._proxy_rot_success
            self.after(0, lambda ps=proxy_str, a=rot_a, s=rot_s: (
                self.lbl_active_proxy.config(text=f"Active: {ps}"),
                self.lbl_proxy_rotations.config(text=f"{a}/{s}"),
                self._refresh_pool_summary(),  # BUG 18: keep pool summary live
            ))

        _eng_disp = {
            "yahoojapan": "Yahoo JP", "aol": "AOL",
            "mojeek": "Mojeek", "qwant": "Qwant",
        }

        # Bug 2 fix: track raw found URLs (pre-dedup) for speed calculation.
        self._raw_urls_found = 0

        def update_labels():
            total   = result_store.count()
            vuln    = result_store.count(vuln_only=True)
            elapsed = time.time() - self.start_time
            # Bug 2 fix: divide raw found (pre-dedup) by elapsed for true speed.
            raw     = getattr(self, "_raw_urls_found", 0)
            spd     = raw / elapsed if elapsed > 0 else 0
            self.lbl_total.config(text=str(raw))   # Bug 4: raw found (pre-dedup)
            # Bug 4 fix: "Unique" shows deduplicated DB count; "URLs found" shows raw total.
            self.lbl_unique.config(text=str(total))
            self.lbl_vuln.config(text=str(vuln))
            self.lbl_speed.config(text=f"{spd:.1f}/s")
            # Update engine pills with display name (BUG 17)
            eng_counts = result_store.count_by_engine()
            for eng, pill in self.engine_pills.items():
                cnt     = eng_counts.get(eng, 0)
                fg      = "#16a34a" if cnt > 0 else "#888"
                display = _eng_disp.get(eng, eng)
                pill.config(text=f"{display} {cnt}", foreground=fg)
        # Bug 1 fix: expose update_labels so _process_queues can call it live.
        self._current_update_labels = update_labels

        def on_dork_done(new_count, raw_found):
            # Acquire lock only to update plain counters — never call Tkinter widget
            # methods or ResultStore (DB _lock) while holding results_lock.
            with self.results_lock:
                self._raw_urls_found += raw_found   # Bug 2: pre-dedup total
                self.urls_processed  += new_count
                self.dorks_processed += 1
                processed  = self.dorks_processed
            # All widget updates happen outside the lock (Bug 1 & 3 fix).
            perc = (processed / total_dorks * 100 if total_dorks else 0)
            self.lbl_dorks_scanned.config(
                text=f"{processed}/{total_dorks} ({perc:.1f}%)")
            self.progress_bar.config(value=processed)
            update_labels()

        def scan_dork(d):
            if not SCAN_RUNNING: return 0, 0
            # BUG 28 fix: pick a fresh Selenium proxy per dork, not once at scan start
            dork_sel_proxy = sel_proxy  # default: reuse pre-selected (no proxy mode)
            if use_px and sel_on:
                fresh = proxy_manager.get_random_proxy_gated(
                    protocols=proto_choices or None, require_https=require_https,
                    min_https_checks=min_https_checks)
                if not fresh and not require_https:
                    fresh = proxy_manager.get_random_proxy_gated(
                        protocols=proto_choices or None, require_https=False,
                        min_https_checks=min_https_checks)
                if fresh:
                    dork_sel_proxy = fresh
                    proxy_str = list(fresh.values())[0]
                    log_event(f"Selenium proxy (dork rotate): {proxy_str}")
                    # BUG 40 fix: fire rotation callback so UI counter increments
                    _on_proxy_rotation(proxy_str, "attempt")
            sc = DorkScanner(
                dork=d,
                engines=engines if self.use_multi_engine.get()
                        else [random.choice(engines)],
                pages=pages,
                headers_pool=headers_pool,
                use_proxies=use_px,
                proxy_protocols=proto_choices,
                proxy_require_https=require_https,
                proxy_min_https_checks=min_https_checks,
                per_request_delay=(min_d, max_d),
                memory_limit_mb=int(self.memory_limit_mb.get()),
                date_since=date_since, date_until=date_until,
                selenium_enabled=sel_on,
                selenium_browser=sel_browser,
                selenium_headless=sel_headless,
                proxy_dict=dork_sel_proxy,
                selenium_delay=sel_delay,
                captcha_enabled=cap_enabled,
                captcha_mode=cap_mode,
                captcha_api_key=cap_key,
                captcha_max_wait=cap_wait,
                captcha_retry_delay=cap_retry,
                captcha_auto_visible=cap_vis,
                bs4_only=bs4_only_mode,
                bs4_workers=bs4_workers_n,
                app_ref=self,
                proxy_rotation_cb=_on_proxy_rotation,
            )
            # Bug 2 fix: run() returns (new_unique, raw_found) tuple.
            return sc.run()

        def worker_seq():
            try:
                for d in dorks:
                    if not SCAN_RUNNING: break
                    while SCAN_PAUSED: time.sleep(0.2)
                    new_count, raw_found = scan_dork(d)
                    self.after(0, lambda n=new_count, r=raw_found: on_dork_done(n, r))
                    time.sleep(0.1)
                log_event("Scan complete.")
                if self.auto_save.get():
                    # Fix D: export_results_dialog opens a messagebox and touches
                    # Tkinter widgets — must run on the main thread via after().
                    self.after(0, lambda: self.export_results_dialog(
                        export_all=True, fmt="txt"))
            except Exception as e:
                log_event(f"Scan error: {e}")
            finally:
                _set_scan_running(False)
                self.after(0, self._on_scan_finished)

        def worker_multi():
            ex = None
            try:
                cap = min(self.num_threads.get(),
                          self.thread_cap.get(), len(dorks))
                ex = ThreadPoolExecutor(max_workers=cap,
                                        thread_name_prefix="dork-scan")
                pending_dorks = list(dorks)
                pending_idx = [0]
                futs = {}

                def _submit_more():
                    if not SCAN_RUNNING or SCAN_PAUSED:
                        return
                    while len(futs) < cap and pending_idx[0] < len(pending_dorks):
                        d = pending_dorks[pending_idx[0]]
                        pending_idx[0] += 1
                        futs[ex.submit(scan_dork, d)] = d

                _submit_more()
                while futs or pending_idx[0] < len(pending_dorks):
                    if not SCAN_RUNNING:
                        for f in list(futs):
                            if not f.running():
                                f.cancel()
                        break
                    if not futs:
                        # Paused with drained in-flight work: wait for resume/stop
                        time.sleep(0.2)
                        _submit_more()
                        continue
                    done, _ = wait(
                        list(futs.keys()),
                        timeout=0.2,
                        return_when=FIRST_COMPLETED
                    )
                    if not done:
                        _submit_more()
                        continue
                    for fut in done:
                        d = futs.pop(fut, None)
                        if d is None:
                            continue
                        try:
                            new_count, raw_found = fut.result()
                            self.after(0, lambda n=new_count, r=raw_found: on_dork_done(n, r))
                        except Exception as e:
                            log_event(f"Thread error ({d}): {e}")
                    _submit_more()
                if SCAN_RUNNING:
                    log_event("Scan complete.")
                if self.auto_save.get():
                    # Fix D: same as worker_seq — must be on main thread.
                    self.after(0, lambda: self.export_results_dialog(
                        export_all=True, fmt="txt"))
            except Exception as e:
                log_event(f"Multi-thread error: {e}")
            finally:
                if ex:
                    try:
                        ex.shutdown(wait=False, cancel_futures=True)
                    except Exception:
                        pass
                _set_scan_running(False)
                self.after(0, self._on_scan_finished)

        target = (worker_seq
                  if (not self.multi_thread.get() or self.num_threads.get() <= 1)
                  else worker_multi)
        self.scanner_thread = threading.Thread(
            target=target, name="scan-main", daemon=True)
        self.scanner_thread.start()

    def _on_scan_finished(self):
        """Reset transient UI state when scan ends (stop or finish)."""
        self.lbl_active_proxy.config(text="Active: none")
        # Bug 1 fix: deregister the live label updater when scan is not running.
        self._current_update_labels = None

    def pause_scan(self):
        if _scan_paused_event.is_set():
            _set_scan_paused(False); log_event("Scan resumed.")
        else:
            _set_scan_paused(True); log_event("Scan paused.")

    def stop_scan(self):
        _set_scan_running(False); _set_scan_paused(False)
        log_event("Scan stopped by user.")
        self._on_scan_finished()

    def _clear_live_filter(self):
        self.live_filter.set("")
        self.log_box.delete(1.0, tk.END)

    def apply_live_filter(self):
        f = self.live_filter.get().strip()
        if not f: return
        try:
            # BUG 11 fix: push the filter into SQL — don't load all rows into memory.
            # Use LIKE with limit instead of Python-side filtering over iter_results().
            pattern = f"%{f}%"
            with result_store._lock:
                rows = result_store._conn().execute(
                    "SELECT url FROM results WHERE url LIKE ? LIMIT 1000",
                    (pattern,)
                ).fetchall()
            matches = [r[0] for r in rows]
        except Exception as e:
            messagebox.showerror("Filter error", str(e)); return
        if not matches:
            messagebox.showinfo("Filter", "No matches."); return
        self.log_box.delete(1.0, tk.END)
        self.log_box.insert(tk.END, "\n".join(matches))

    def remove_duplicates(self):
        """The SQLite UNIQUE constraint on url already prevents duplicates at insert time.
        This method syncs the in-memory global seen set with what's actually in the DB,
        and refreshes the UI counters — useful after importing external data.
        """
        with _global_seen_urls_lock:
            _global_seen_urls.clear()
            for row in result_store.iter_results():
                _global_seen_urls.add(row["url"])
            synced = len(_global_seen_urls)
        total = result_store.count()
        self.lbl_total.config(text=str(total))
        self.lbl_unique.config(text=str(total))
        log_event(f"Dedup sync: {total} unique URLs in DB, {synced} in memory seen-set.")

    def export_results_dialog(self, export_all=False, vuln=False, fmt="json"):
        if result_store.count() == 0:
            messagebox.showinfo("Export", "No results yet."); return
        ts   = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
        base = "results_all" if export_all else "results_vuln"
        os.makedirs(EXPORT_DIR, exist_ok=True)
        path = os.path.join(EXPORT_DIR, f"{base}_{ts}.{fmt}")
        if fmt == "json": result_store.export_json(path, vuln_only=vuln)
        else:             result_store.export_txt(path,  vuln_only=vuln)
        messagebox.showinfo("Exported", f"Saved to:\n{path}")

    def export_by_domain_dialog(self):
        domains = result_store.domains()
        if not domains:
            messagebox.showinfo("Export",
                                "No results yet or no domain data."); return
        top = tk.Toplevel(self)
        top.title("Export by Domain")
        ttk.Label(top, text="Select domain to export:").pack(padx=12, pady=8)
        lb = tk.Listbox(top, width=50, height=12)
        lb.pack(padx=12, pady=4)
        for d in domains: lb.insert(tk.END, d)
        fv = tk.StringVar(value="txt")
        r  = ttk.Frame(top); r.pack()
        ttk.Radiobutton(r, text="TXT",  variable=fv, value="txt").pack(
            side="left", padx=4)
        ttk.Radiobutton(r, text="JSON", variable=fv, value="json").pack(
            side="left", padx=4)
        def do_export():
            sel = lb.curselection()
            if not sel:
                messagebox.showwarning("Select", "Select a domain."); return
            domain = lb.get(sel[0])
            fmt    = fv.get()
            ts     = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
            path   = os.path.join(EXPORT_DIR, f"domain_{domain}_{ts}.{fmt}")
            if fmt == "json": result_store.export_json(path, domain=domain)
            else:             result_store.export_txt(path,  domain=domain)
            messagebox.showinfo("Exported", f"Saved to:\n{path}")
            top.destroy()
        ttk.Button(top, text="⬇ Export", command=do_export).pack(pady=8)

    def export_by_engine_dialog(self):
        """Export results filtered to a single engine."""
        eng_counts = result_store.count_by_engine()
        if not eng_counts:
            messagebox.showinfo("Export", "No results yet."); return
        top = tk.Toplevel(self)
        top.title("Export by Engine")
        ttk.Label(top, text="Select engine to export:").pack(padx=12, pady=8)
        lb = tk.Listbox(top, width=40, height=10)
        lb.pack(padx=12, pady=4)
        for eng, cnt in sorted(eng_counts.items()):
            lb.insert(tk.END, f"{eng}  ({cnt} URLs)")
        fv = tk.StringVar(value="txt")
        r  = ttk.Frame(top); r.pack()
        ttk.Radiobutton(r, text="TXT",  variable=fv, value="txt").pack(
            side="left", padx=4)
        ttk.Radiobutton(r, text="JSON", variable=fv, value="json").pack(
            side="left", padx=4)
        def do_export():
            sel = lb.curselection()
            if not sel:
                messagebox.showwarning("Select", "Select an engine."); return
            eng = lb.get(sel[0]).split()[0]
            fmt = fv.get()
            ts  = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
            path = os.path.join(EXPORT_DIR, f"engine_{eng}_{ts}.{fmt}")
            if fmt == "json": result_store.export_json(path, engine=eng)
            else:             result_store.export_txt(path,  engine=eng)
            messagebox.showinfo("Exported", f"Saved to:\n{path}")
            top.destroy()
        ttk.Button(top, text="⬇ Export", command=do_export).pack(pady=8)

    # ── Stats / Logs ──────────────────────────────────────────────────────────
    def export_audit_log(self):
        if not os.path.exists(AUDIT_LOG):
            messagebox.showinfo("Logs", "No audit log found."); return
        # Flush handler before copying to avoid truncation on Windows.
        # Fix #5: _get_audit_handler() returns a Logger, not a Handler —
        # renamed to audit_logger for clarity.
        try:
            audit_logger = _get_audit_handler()
            for h in audit_logger.handlers:
                try: h.flush()
                except Exception: pass
        except Exception: pass
        path = os.path.join(DATA_DIR, "audit_log_export.txt")
        shutil.copy2(AUDIT_LOG, path)
        messagebox.showinfo("Exported", f"Log copied to:\n{path}")

    def clear_cache(self):
        if os.path.exists(CACHE_DB):
            os.remove(CACHE_DB)
        messagebox.showinfo("Cache", "Cache cleared.")

    def show_memory_chart(self):
        try: import matplotlib.pyplot as plt
        except Exception:
            messagebox.showwarning("Dependency", "pip install matplotlib"); return
        if not psutil:
            messagebox.showwarning("Dependency", "pip install psutil"); return
        def _run():
            samples = []
            for _ in range(20):
                samples.append(psutil.virtual_memory().used / (1024 * 1024))
                time.sleep(0.5)
            def _plot():
                fig, ax = plt.subplots()
                ax.plot(samples)
                ax.set_title("RAM used (MB) — 10s sample")
                ax.set_xlabel("Sample"); ax.set_ylabel("MB")
                fig.tight_layout()
                chart_path = os.path.join(EXPORT_DIR, "memory_chart.png")
                fig.savefig(chart_path)
                plt.close(fig)
                import webbrowser
                webbrowser.open(chart_path)
                messagebox.showinfo("Memory Chart", f"Chart saved to:\n{chart_path}")
            self.after(0, _plot)
        threading.Thread(target=_run, name="memory-chart",
                         daemon=True).start()

    # ── Queue processor ───────────────────────────────────────────────────────
    def _process_queues(self):
        if self._is_closing or not self.winfo_exists():
            return
        had_items = False
        # Log queue → both text boxes
        for _ in range(100):
            try:
                line = log_queue.get_nowait()
                self.log_box.insert(tk.END, line + "\n", "info")
                self.stats_text.insert(tk.END, line + "\n")
                had_items = True
            except Empty: break
        # Result queue → live log
        for _ in range(200):
            try:
                item  = result_queue.get_nowait()
                is_v  = item.get("is_vuln", False)
                tag   = "vuln" if is_v else ""
                flag  = " 🔴 VULN" if is_v else ""
                line  = (f"[{item.get('engine','?')}] "
                         f"{item.get('url','')}{flag}\n")
                self.log_box.insert(tk.END, line, tag)
                had_items = True
            except Empty: break
        # Fix G: trim AFTER both queues are drained so lines inserted by the
        # result queue in this cycle are included in the line count, and
        # stats_text (log-only) is trimmed separately on its own limit.
        for widget in (self.log_box, self.stats_text):
            try:
                nlines = int(widget.index("end-1c").split(".")[0])
                if nlines > self.MAX_LOG_LINES:
                    widget.delete("1.0", f"{nlines - self.MAX_LOG_LINES + 1}.0")
            except Exception: pass
        self.log_box.see(tk.END)
        self.stats_text.see(tk.END)
        # Bug 1 fix: refresh counters and engine pills on every active poll
        # cycle so the progress panel updates per-URL, not only once per dork.
        if had_items and SCAN_RUNNING and hasattr(self, "start_time"):
            try:
                fn = getattr(self, "_current_update_labels", None)
                if fn:
                    fn()
            except Exception:
                pass
        # Adaptive polling: faster when active, slower when idle
        delay = 150 if had_items else 350
        self.after(delay, self._process_queues)

    # ── Selenium clear — FIXED ────────────────────────────────────────────────
    def clear_selenium_data(self):
        """Delete the persistent profile directories for selected browser(s).
        This correctly clears cookies, localStorage, and cache because the
        profile dirs in data/selenium_profiles/ are what the driver actually uses.
        Guards against clearing while a scan is running.
        """
        if not SELENIUM_AVAILABLE:
            messagebox.showwarning(
                "Dependency", "Install selenium + webdriver-manager."); return
        if SCAN_RUNNING:
            messagebox.showwarning(
                "Scan Running",
                "Cannot clear Selenium profiles while a scan is running.\n"
                "Stop the scan first."); return

        # Fix #8: selenium_browsers dict replaced with selenium_browser_var StringVar
        browsers = [self.selenium_browser_var.get()]

        def _run():
            cleared = {}
            for browser in browsers:
                # Fix #7: _make_driver creates per-thread profiles at
                # SEL_PROFILES/{browser}_{thread_id}/ — the old code only
                # deleted the base SEL_PROFILES/{browser}/ dir which was
                # always empty. Scan all entries matching the browser prefix.
                total_bytes = 0
                found_any   = False
                try:
                    for entry in os.listdir(SEL_PROFILES):
                        # Match both "chrome" and "chrome_<thread_id>" dirs
                        if entry == browser or entry.startswith(f"{browser}_"):
                            full = os.path.join(SEL_PROFILES, entry)
                            if not os.path.isdir(full):
                                continue
                            found_any = True
                            try:
                                total_bytes += sum(
                                    os.path.getsize(os.path.join(dp, f))
                                    for dp, dn, fn in os.walk(full)
                                    for f in fn
                                    if not os.path.islink(os.path.join(dp, f))
                                )
                                shutil.rmtree(full)
                                os.makedirs(full, exist_ok=True)
                            except Exception as e:
                                log_event(f"Selenium clear error ({entry}): {e}")
                    # Ensure at least the base dir exists for future scans
                    os.makedirs(os.path.join(SEL_PROFILES, browser), exist_ok=True)
                    if found_any:
                        cleared[browser] = total_bytes
                        log_event(
                            f"Selenium profile cleared: {browser} "
                            f"({total_bytes // 1024} KB freed)")
                    else:
                        cleared[browser] = 0
                        log_event(f"Selenium profile: {browser} already empty.")
                except Exception as e:
                    log_event(f"Selenium clear error ({browser}): {e}")
                    cleared[browser] = -1

            def _show():
                lines = []
                for b, sz in cleared.items():
                    if sz == -1:
                        lines.append(f"{b}: ERROR (see audit log)")
                    elif sz == 0:
                        lines.append(f"{b}: already empty")
                    else:
                        lines.append(f"{b}: {sz // 1024} KB freed")
                messagebox.showinfo(
                    "Profile Data Cleared",
                    "Selenium profile data cleared:\n" + "\n".join(lines) +
                    "\n\nCookies, localStorage, and cache deleted.\n"
                    "Next scan starts with a fresh browser profile.")
            self.after(0, _show)

        threading.Thread(target=_run, name="selenium-clear",
                         daemon=True).start()

    # ── Port Scanner ──────────────────────────────────────────────────────────
    def start_port_scan(self):
        if not self.auth_domains:
            messagebox.showwarning("Authorization",
                                   "Authorize domains first."); return
        host = self.target_host.get().strip()
        if not host:
            messagebox.showwarning("No host", "Enter target host."); return
        try: ip = socket.gethostbyname(host)
        except Exception as e:
            messagebox.showerror("DNS", str(e)); return
        if host not in self.auth_domains and ip not in self.auth_domains:
            messagebox.showwarning("Not authorized",
                                   "Host not in authorized domains."); return
        if self.port_mode.get() == "fixed":
            ports = []
            for p in self.fixed_ports.get().split(","):
                p = p.strip()
                if p.isdigit():
                    ports.append(int(p))
                else:
                    messagebox.showwarning("Ports", "Fixed ports must be numbers.")
                    return
        else:
            s = set()
            while len(s) < self.num_random.get():
                s.add(random.randint(1, 65535))
            ports = list(s)

        _set_port_scan_running(True)
        self._last_port_host  = host
        self._last_open_ports = []
        self.port_log.delete(1.0, tk.END)
        self.port_log.insert(
            tk.END,
            f"Scanning {host} ({ip}) — {len(ports)} ports — "
            f"timeout {float(self.port_timeout.get())}s\n", "info")
        log_event(f"Port scan: {host} ({ip}), {len(ports)} ports.")
        timeout = float(self.port_timeout.get())

        def worker():
            open_ports = []
            # Single executor for the full scan (not recreated per batch)
            with ThreadPoolExecutor(max_workers=50,
                                    thread_name_prefix="port-scan") as ex:
                futs = {ex.submit(self.scan_port, ip, p, timeout): p
                        for p in ports}
                for fut in as_completed(futs):
                    if not PORT_SCAN_RUNNING: break
                    try:
                        res = fut.result()
                    except Exception as e:
                        log_event(f"Port scan error: {e}"); continue
                    if res:
                        open_ports.append(res)
                        self.after(0, lambda r=res: (
                            self.port_log.insert(
                                tk.END, f"✔  Port {r:5d}  OPEN\n", "open"),
                            self.port_log.see(tk.END)))
                    # BUG 15 fix: jitter removed from result-collection loop;
                    # it serialised all result processing. Jitter now lives in scan_port.
            open_ports_sorted = sorted(open_ports)
            summary = (f"\nDone — {len(open_ports_sorted)} open: {open_ports_sorted}"
                       if open_ports_sorted else "\nDone — no open ports found.")
            self.after(0, lambda: self.port_log.insert(
                tk.END, summary + "\n", "info"))
            log_event(f"Port scan done: {open_ports_sorted}")
            # Store for export
            self._last_open_ports = open_ports_sorted
            _set_port_scan_running(False)

        threading.Thread(target=worker, name="port-scan-main",
                         daemon=True).start()

    def scan_port(self, ip, port, timeout=1.0):
        if not PORT_SCAN_RUNNING: return None
        # Small per-probe jitter to avoid thundering-herd against the target
        time.sleep(random.uniform(0.005, 0.02))
        s = None
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(timeout)
            return port if s.connect_ex((ip, port)) == 0 else None
        except Exception:
            return None
        finally:
            if s:
                try: s.close()
                except Exception: pass

    def stop_port_scan(self):
        _set_port_scan_running(False)
        log_event("Port scan stopped.")

    # ── Domain-to-IP  — now concurrent with Events ───────────────────────────
    def load_urls_for_domain_ip(self):
        p = filedialog.askopenfilename(
            title="Open file", filetypes=[("Text", "*.txt"), ("All", "*.*")])
        if not p: return
        with open(p, "r", encoding="utf-8") as f:
            lines = [l.strip() for l in f if l.strip()]
        self.domain_input.delete(1.0, tk.END)
        self.domain_input.insert(tk.END, "\n".join(lines))
        messagebox.showinfo("Loaded", f"Loaded {len(lines)} entries.")

    def _extract_domain(self, raw):
        raw = raw.strip()
        if not raw: return None
        if self.normalize_domains.get():
            if not raw.startswith(("http://", "https://")):
                raw = "http://" + raw
            try:
                host = urlparse(raw).hostname or ""
                host = host.lower()
                # Fix #1: lstrip("www.") strips individual chars, not the
                # substring — use a proper prefix check instead.
                if host.startswith("www."):
                    host = host[4:]
                return host or None
            except Exception: return None
        return raw

    def start_domain_ip_conversion(self):
        text = self.domain_input.get(1.0, tk.END).strip()
        if not text:
            messagebox.showwarning("Empty", "Paste or load domains."); return
        domains = [d for d in
                   [self._extract_domain(l) for l in text.splitlines() if l.strip()]
                   if d]
        if not domains:
            messagebox.showwarning("No domains", "No valid domains found."); return

        _set_domain_ip_running(True)
        _set_domain_ip_paused(False)
        self._failed_domains = []
        self._dns_resolved   = []
        self._dns_failed     = []
        self.domain_log.delete(1.0, tk.END)
        self.dns_stats_label.config(text=f"0 resolved · 0 failed · {len(domains)} total")
        log_event(f"Domain-to-IP: resolving {len(domains)} domains.")
        workers = int(self.domain_ip_workers.get())

        def resolve_one(domain):
            """Called from thread pool."""
            while DOMAIN_IP_PAUSED:
                time.sleep(0.2)
            if not DOMAIN_IP_RUNNING:
                return domain, None, "stopped"
            try:
                ip = socket.gethostbyname(domain)
                return domain, ip, None
            except socket.gaierror as e:
                return domain, None, str(e)

        def worker():
            with ThreadPoolExecutor(max_workers=workers,
                                    thread_name_prefix="dns-resolve") as ex:
                futs = {ex.submit(resolve_one, d): d for d in domains}
                for fut in as_completed(futs):
                    if not DOMAIN_IP_RUNNING: break
                    try:
                        domain, ip, err = fut.result()
                    except Exception as e:
                        log_event(f"Domain-to-IP worker error: {e}"); continue
                    if err == "stopped":
                        continue
                    elif err:
                        line = f"✘  {domain:<45} → FAILED ({err})\n"
                        self._failed_domains.append(domain)
                        self._dns_failed.append(domain)
                        tag = "fail"
                    else:
                        line = f"✔  {domain:<45} → {ip}\n"
                        self._dns_resolved.append((domain, ip))
                        tag = "ok"
                    res_n  = len(self._dns_resolved)
                    fail_n = len(self._dns_failed)
                    self.after(0, lambda l=line, t=tag, r=res_n, f=fail_n: (
                        self.domain_log.insert(tk.END, l, t),
                        self.domain_log.see(tk.END),
                        self.dns_stats_label.config(
                            text=f"{r} resolved · {f} failed · {len(domains)} total")))
            _set_domain_ip_running(False)
            fail_n = len(self._dns_failed)
            res_n  = len(self._dns_resolved)
            self.after(0, lambda: log_event(
                f"Domain-to-IP done. {res_n} resolved, {fail_n} failed."))

        threading.Thread(target=worker, name="domain-ip-main",
                         daemon=True).start()

    def pause_domain_ip(self):
        if DOMAIN_IP_PAUSED:
            _set_domain_ip_paused(False)
            log_event("Domain-to-IP resumed.")
        else:
            _set_domain_ip_paused(True)
            log_event("Domain-to-IP paused.")

    def stop_domain_ip(self):
        _set_domain_ip_running(False)
        _set_domain_ip_paused(False)
        log_event("Domain-to-IP stopped.")

    def retry_failed_resolutions(self):
        if not getattr(self, "_failed_domains", None):
            messagebox.showinfo("Retry", "No failed domains."); return
        self.domain_input.delete(1.0, tk.END)
        self.domain_input.insert(tk.END, "\n".join(self._failed_domains))
        self.start_domain_ip_conversion()

    def clear_domain_ip_results(self):
        self.domain_log.delete(1.0, tk.END)
        self._failed_domains = []
        self._dns_resolved   = []
        self._dns_failed     = []
        self.dns_stats_label.config(text="")

    # ── Port Scanner exports ──────────────────────────────────────────────────
    def export_port_results_txt(self):
        if not self._last_open_ports:
            messagebox.showinfo("Export", "No open ports to export.\n"
                                "Run a port scan first."); return
        ts   = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
        path = os.path.join(EXPORT_DIR, f"port_scan_{ts}.txt")
        os.makedirs(EXPORT_DIR, exist_ok=True)
        host = self._last_port_host or "unknown"
        with open(path, "w", encoding="utf-8") as f:
            f.write(f"# Port scan — {host} — {ts}\n")
            f.write(f"# Open ports: {len(self._last_open_ports)}\n\n")
            for p in self._last_open_ports:
                f.write(f"{p}\n")
        log_event(f"Port results exported (TXT): {path}")
        messagebox.showinfo("Exported",
                            f"Exported {len(self._last_open_ports)} open "
                            f"ports to:\n{path}")

    def export_port_results_json(self):
        if not self._last_open_ports:
            messagebox.showinfo("Export", "No open ports to export.\n"
                                "Run a port scan first."); return
        ts   = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
        host = self._last_port_host or "unknown"
        data = {
            "host":       host,
            "timestamp":  ts,
            "open_ports": self._last_open_ports,
            "count":      len(self._last_open_ports),
        }
        path = save_export(f"port_scan_{host.replace('.', '_')}", data,
                           fmt="json")
        log_event(f"Port results exported (JSON): {path}")
        messagebox.showinfo("Exported",
                            f"Exported {len(self._last_open_ports)} open "
                            f"ports to:\n{path}")

    # ── Domain-to-IP exports ──────────────────────────────────────────────────
    def export_dns_results_txt(self):
        if not self._dns_resolved:
            messagebox.showinfo("Export", "No resolved domains to export.\n"
                                "Run a DNS resolution first."); return
        ts   = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
        path = os.path.join(EXPORT_DIR, f"dns_resolved_{ts}.txt")
        os.makedirs(EXPORT_DIR, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            f.write(f"# DNS resolved — {ts}\n"
                    f"# {len(self._dns_resolved)} resolved\n\n")
            for domain, ip in self._dns_resolved:
                f.write(f"{domain:<45} {ip}\n")
        log_event(f"DNS resolved exported (TXT): {path}")
        messagebox.showinfo("Exported",
                            f"Exported {len(self._dns_resolved)} resolved "
                            f"domains to:\n{path}")

    def export_dns_results_json(self):
        if not self._dns_resolved:
            messagebox.showinfo("Export", "No resolved domains to export.\n"
                                "Run a DNS resolution first."); return
        ts   = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
        data = {
            "timestamp": ts,
            "resolved":  [{"domain": d, "ip": ip}
                          for d, ip in self._dns_resolved],
            "count":     len(self._dns_resolved),
        }
        path = save_export(f"dns_resolved_{ts}", data, fmt="json")
        log_event(f"DNS resolved exported (JSON): {path}")
        messagebox.showinfo("Exported",
                            f"Exported {len(self._dns_resolved)} resolved "
                            f"domains to:\n{path}")

    def export_dns_failed_txt(self):
        if not self._dns_failed:
            messagebox.showinfo("Export", "No failed domains to export."); return
        ts   = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
        path = os.path.join(EXPORT_DIR, f"dns_failed_{ts}.txt")
        os.makedirs(EXPORT_DIR, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            f.write(f"# DNS failed — {ts}\n"
                    f"# {len(self._dns_failed)} failed\n\n")
            for domain in self._dns_failed:
                f.write(f"{domain}\n")
        log_event(f"DNS failed exported (TXT): {path}")
        messagebox.showinfo("Exported",
                            f"Exported {len(self._dns_failed)} failed "
                            f"domains to:\n{path}")

    def on_exit(self):
        if messagebox.askokcancel("Exit", "Exit application?"):
            self._is_closing = True
            self.stop_scan()
            self.stop_port_scan()
            self.stop_domain_ip()
            self._proxy_scrape_stop.set()
            self._proxy_validate_stop.set()
            self.destroy()

# ═══════════════════════════════════════════════════════════════════════════════
def main():
    proxy_manager.load_from_file()
    app = EthicalDorkSuiteApp()
    if not os.path.exists(AUDIT_LOG):
        with open(AUDIT_LOG, "w", encoding="utf-8") as f:
            f.write(f"{datetime.now(UTC).isoformat()}  Audit log created\n")
    log_event("Application started — v5 2026 Edition.")
    app.mainloop()

if __name__ == "__main__":
    main()