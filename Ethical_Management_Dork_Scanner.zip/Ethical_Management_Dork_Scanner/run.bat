@echo off
setlocal EnableDelayedExpansion

echo ============================================================
echo  Ethical Dork Suite — v5 (2026 Edition)
echo ============================================================
echo.

:: Check Python is available
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found. Install Python 3.10+ from https://python.org
    echo         Make sure to check "Add Python to PATH" during installation.
    pause
    exit /b 1
)

:: Show Python version for diagnostics
for /f "tokens=*" %%v in ('python --version 2^>^&1') do echo [INFO] Using %%v

:: Install / upgrade dependencies silently
echo [INFO] Checking dependencies (this may take a moment on first run)...
python -m pip install -q --upgrade pip
python -m pip install -q -r requirements.txt
if errorlevel 1 (
    echo [WARN] Some packages may have failed to install. Attempting to continue...
)

echo [INFO] Launching application...
echo.
python ethical_dork_suite.py
if errorlevel 1 (
    echo.
    echo [ERROR] Application exited with an error. See output above.
)
pause
